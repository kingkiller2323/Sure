import express, { type Express } from "express";
import cors    from "cors";
import router  from "./routes/index.js";
import { startScheduler } from "./lib/scheduler.js";

const app: Express = express();

app.use(cors({ origin: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

// Kick off the KTC scraper schedule (non-blocking — failures are logged)
startScheduler().catch(err => console.error("[Scheduler] startup error:", err));

export default app;
