/**
 * ktcCache.ts — Stale-while-revalidate cache for KTC player values.
 *
 * Single source of truth for:
 *   - The cached player list (in memory + disk)
 *   - The scrape lock (prevents concurrent scrapes)
 *   - Last updated timestamp
 *   - Freshness check (6 hours)
 *   - Background refresh trigger
 *
 * Route behaviour:
 *   Case A — cache fresh:   return data, stale=false, refreshing=false
 *   Case B — cache stale:   return data, stale=true,  refreshing=true  (fires bg refresh)
 *   Case C — cache missing: run scraper now, return result or error
 */

import { existsSync, statSync } from "fs";
import { runKtcScrape, readKtcValues, type KtcPlayer } from "./ktcScraper.js";
import { getKtcValuesPath } from "./paths.js";

// Use centralized path resolution (safe for both ESM dev and CJS production)
const OUT_FILE   = getKtcValuesPath();
const FRESH_MS   = 6 * 60 * 60 * 1000; // 6 hours

// ─── Module-level state ──────────────────────────────────────────────────────

let _scraping        = false;   // scrape lock — never run concurrent scrapes
let _lastUpdatedMs   = 0;       // unix-ms of last successful write

/** Call once at startup to seed _lastUpdatedMs from file mtime if it exists */
export function initCacheTimestamp(): void {
  if (existsSync(OUT_FILE)) {
    try { _lastUpdatedMs = statSync(OUT_FILE).mtimeMs; } catch {}
  }
}

// ─── Freshness ───────────────────────────────────────────────────────────────

export function isFresh(): boolean {
  if (_lastUpdatedMs === 0) return false;
  return (Date.now() - _lastUpdatedMs) < FRESH_MS;
}

export function isStale(): boolean {
  if (_lastUpdatedMs === 0) return true;
  return (Date.now() - _lastUpdatedMs) >= FRESH_MS;
}

export function cacheExists(): boolean {
  return existsSync(OUT_FILE);
}

export function lastUpdatedIso(): string | null {
  return _lastUpdatedMs > 0 ? new Date(_lastUpdatedMs).toISOString() : null;
}

export function isRefreshing(): boolean {
  return _scraping;
}

// ─── Scrape with lock ─────────────────────────────────────────────────────────

/**
 * Run the scraper, guarded by the lock.
 * On success, updates _lastUpdatedMs.
 * Returns the player list (or null on failure).
 */
export async function scrapeWithLock(): Promise<KtcPlayer[] | null> {
  if (_scraping) {
    console.log("[KtcCache] Scrape already in progress — skipping duplicate request");
    return null;
  }
  _scraping = true;
  try {
    const players = await runKtcScrape();
    if (players && players.length > 0) {
      _lastUpdatedMs = Date.now();
    }
    return players;
  } finally {
    _scraping = false;
  }
}

/** Fire-and-forget background refresh (Case B) */
export function triggerBackgroundRefresh(): void {
  if (_scraping) return;
  scrapeWithLock().catch(err =>
    console.error("[KtcCache] Background refresh error:", err)
  );
}

// ─── Route-level handler ──────────────────────────────────────────────────────

export interface KtcCacheResult {
  players:      KtcPlayer[];
  lastUpdated:  string | null;
  stale:        boolean;
  refreshing:   boolean;
  error?:       string;
}

/**
 * Main entry point for GET /api/ktc-values.
 * Implements stale-while-revalidate.
 */
export async function getKtcData(): Promise<KtcCacheResult & { status: number }> {
  // ── Case C: no cache at all ───────────────────────────────────────────────
  if (!cacheExists()) {
    console.log("[KtcCache] No cache — running blocking scrape");
    const players = await scrapeWithLock();
    if (!players || players.length === 0) {
      return {
        players:     [],
        lastUpdated: null,
        stale:       true,
        refreshing:  false,
        error:       "KTC data not yet available — initial scrape failed",
        status:      503,
      };
    }
    return {
      players,
      lastUpdated: lastUpdatedIso(),
      stale:       false,
      refreshing:  false,
      status:      200,
    };
  }

  // Read disk (always — in-memory cache not needed; OS caches the file)
  const players = await readKtcValues();

  if (players.length === 0) {
    // File exists but is empty — treat same as missing
    console.log("[KtcCache] Cache is empty — running blocking scrape");
    const fresh = await scrapeWithLock();
    if (!fresh || fresh.length === 0) {
      return {
        players:     [],
        lastUpdated: lastUpdatedIso(),
        stale:       true,
        refreshing:  false,
        error:       "KTC scrape returned no data",
        status:      503,
      };
    }
    return {
      players:     fresh,
      lastUpdated: lastUpdatedIso(),
      stale:       false,
      refreshing:  false,
      status:      200,
    };
  }

  // ── Case A: fresh ─────────────────────────────────────────────────────────
  if (isFresh()) {
    return {
      players,
      lastUpdated: lastUpdatedIso(),
      stale:       false,
      refreshing:  false,
      status:      200,
    };
  }

  // ── Case B: stale — serve immediately, refresh in background ─────────────
  console.log("[KtcCache] Cache stale — serving stale data, triggering bg refresh");
  triggerBackgroundRefresh();
  return {
    players,
    lastUpdated: lastUpdatedIso(),
    stale:       true,
    refreshing:  _scraping,
    status:      200,
  };
}
