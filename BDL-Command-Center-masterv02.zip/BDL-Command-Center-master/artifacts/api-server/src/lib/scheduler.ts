/**
 * scheduler.ts
 *
 * Manages the KTC scraper cron job.
 * Uses the scrape lock from ktcCache.ts so scrapes never overlap.
 * Runs every 6 hours.  Also triggers an immediate scrape on startup
 * if cache is missing or empty.
 */

import cron                  from "node-cron";
import { initCacheTimestamp, scrapeWithLock, cacheExists } from "./ktcCache.js";
import { readKtcValues }     from "./ktcScraper.js";
import { logDataPaths }      from "./paths.js";

async function runCoverageReport(): Promise<void> {
  try {
    const res = await fetch("http://localhost:8080/api/ktc-coverage", {
      signal: AbortSignal.timeout(60_000),
    });
    if (!res.ok) console.warn(`[Scheduler] Coverage report returned HTTP ${res.status}`);
    // Report is already printed to console inside the route handler
  } catch (err) {
    console.warn("[Scheduler] Coverage auto-run skipped:", err instanceof Error ? err.message : String(err));
  }
}

export async function startScheduler(): Promise<void> {
  // Log resolved data paths at startup
  logDataPaths();

  // Seed the in-memory timestamp from disk
  initCacheTimestamp();

  const empty = !cacheExists() || (await readKtcValues()).length === 0;

  if (empty) {
    console.log("[Scheduler] Cache missing or empty — triggering immediate scrape");
    // Non-blocking: fire and log result; run coverage report after scrape
    scrapeWithLock().then(async players => {
      if (!players) {
        console.warn("[Scheduler] Startup scrape failed — API returns 503 until next attempt");
      } else if (process.env.NODE_ENV === "development") {
        // Small delay so the server is fully ready before we hit the coverage route
        await new Promise(r => setTimeout(r, 2000));
        await runCoverageReport();
      }
    }).catch(err => console.error("[Scheduler] Startup scrape error:", err));
  } else {
    const players = await readKtcValues();
    console.log(`[Scheduler] Cache OK — ${players.length} players loaded from disk`);
    // Run coverage report on startup when cache already exists
    if (process.env.NODE_ENV === "development") {
      await new Promise(r => setTimeout(r, 1500));
      runCoverageReport().catch(() => {});
    }
  }

  // Run every 6 hours: 0:00, 6:00, 12:00, 18:00
  cron.schedule("0 0,6,12,18 * * *", () => {
    console.log("[Scheduler] 6-hour cron — triggering KTC scrape");
    scrapeWithLock().catch(err =>
      console.error("[Scheduler] Cron scrape error:", err)
    );
  });

  console.log("[Scheduler] KTC scraper scheduled (every 6 h at :00)");
}
