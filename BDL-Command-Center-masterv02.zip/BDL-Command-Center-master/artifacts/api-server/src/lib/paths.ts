/**
 * paths.ts — Safe path resolution for ESM dev mode and CJS production bundle.
 *
 * Problem: import.meta.url is undefined in esbuild CJS bundles.
 * Solution: Use process.cwd() + explicit relative path from project root.
 *
 * This works because:
 *   - Dev (tsx): runs from artifacts/api-server, data is at ./data/
 *   - Prod (node dist/index.cjs): runs from artifacts/api-server, data is at ./data/
 *
 * The data directory is always relative to the api-server package root.
 */

import path from "path";
import { existsSync } from "fs";

/**
 * Resolve the data directory path.
 * Returns absolute path to artifacts/api-server/data/
 */
export function getDataDir(): string {
  // In production (CJS bundle), __dirname is the dist folder
  // In dev (ESM), we use process.cwd() which is api-server root
  // Either way, data/ is at the package root level

  // Try multiple strategies in order of preference:

  // Strategy 1: Check if we're in the dist folder (production)
  // The bundle runs as dist/index.cjs, so data is at ../data
  const fromDist = path.resolve(process.cwd(), "data");
  if (existsSync(fromDist)) {
    return fromDist;
  }

  // Strategy 2: Check relative to current working directory
  const fromCwd = path.resolve(process.cwd(), "artifacts/api-server/data");
  if (existsSync(fromCwd)) {
    return fromCwd;
  }

  // Strategy 3: Check if running from monorepo root
  const fromRoot = path.resolve(process.cwd(), "data");
  if (existsSync(fromRoot)) {
    return fromRoot;
  }

  // Fallback: return expected path even if it doesn't exist
  // Let the caller handle missing directory
  return fromDist;
}

/** Resolve path to ktc_values.json */
export function getKtcValuesPath(): string {
  return path.join(getDataDir(), "ktc_values.json");
}

/** Resolve path to ktc_values.tmp.json */
export function getKtcTempPath(): string {
  return path.join(getDataDir(), "ktc_values.tmp.json");
}

/** Resolve path to idp_seed.json */
export function getIdpSeedPath(): string {
  return path.join(getDataDir(), "idp_seed.json");
}

/**
 * Log resolved data paths and file existence at startup.
 * Call this once during server initialization.
 */
export function logDataPaths(): void {
  const dataDir = getDataDir();
  const ktcPath = getKtcValuesPath();
  const idpPath = getIdpSeedPath();

  console.log("[Paths] ─── Data path resolution ───────────────────────────────");
  console.log(`[Paths]   DATA_DIR         : ${dataDir}`);
  console.log(`[Paths]   DATA_DIR exists  : ${existsSync(dataDir)}`);
  console.log(`[Paths]   ktc_values.json  : ${ktcPath}`);
  console.log(`[Paths]   ktc_values exists: ${existsSync(ktcPath)}`);
  console.log(`[Paths]   idp_seed.json    : ${idpPath}`);
  console.log(`[Paths]   idp_seed exists  : ${existsSync(idpPath)}`);
  console.log(`[Paths]   process.cwd()    : ${process.cwd()}`);
  console.log("[Paths] ────────────────────────────────────────────────────────");
}
