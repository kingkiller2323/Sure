/**
 * idpRankings.ts — IDP dynasty ranking provider (backend).
 *
 * Architecture: pluggable seed-file source.
 *   - Currently reads from data/idp_seed.json
 *   - Upgrade path: replace readIdpSeed() with a live scraper / API call
 *     without touching the valuation engine or route contract
 *
 * Values are on the same 0–10 000 dynasty scale as KTC offensive values.
 * Positions: DL / LB / DB only (IDP positions).
 *
 * Output key per record (mirrors frontend idpProvider.ts):
 *   "idp:{normalized-name}-{pos}"
 */

import { readFile }       from "fs/promises";
import { existsSync }     from "fs";
import { getIdpSeedPath } from "./paths.js";

// Use centralized path resolution (safe for both ESM dev and CJS production)
const SEED_FILE = getIdpSeedPath();

export interface IdpPlayer {
  playerName: string;
  position:   "DL" | "LB" | "DB";
  team:       string;
  age:        number;
  value:      number;   // dynasty value 0–10 000
}

const IDP_POSITIONS = new Set(["DL", "LB", "DB"]);

// ─── Name normalisation (mirrors frontend utils/normalize.ts) ─────────────────
export function normIdpName(name: string): string {
  return name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9 ]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

/** Build the key the frontend idpProvider uses: "idp:{norm-name}-{pos}" */
export function idpKey(name: string, pos: string): string {
  return `idp:${normIdpName(name)}-${pos.toLowerCase()}`;
}

// ─── Seed loader ──────────────────────────────────────────────────────────────

interface SeedRecord {
  playerName?: string;
  name?:       string;
  position?:   string;
  team?:       string;
  age?:        number;
  value?:      number;
}

function normaliseSeedRecord(r: SeedRecord): IdpPlayer | null {
  try {
    const name = (r.playerName ?? r.name ?? "").trim();
    const pos  = (r.position ?? "").trim().toUpperCase();
    if (!name || !IDP_POSITIONS.has(pos)) return null;

    const value = Number(r.value ?? 0);
    if (value <= 0) return null;

    return {
      playerName: name,
      position:   pos as "DL" | "LB" | "DB",
      team:       (r.team ?? "").trim(),
      age:        Number(r.age ?? 25),
      value,
    };
  } catch {
    return null;
  }
}

export async function readIdpRankings(): Promise<IdpPlayer[]> {
  if (!existsSync(SEED_FILE)) {
    console.warn("[IDP] Seed file not found:", SEED_FILE);
    return [];
  }
  try {
    const raw     = await readFile(SEED_FILE, "utf8");
    const records = JSON.parse(raw) as SeedRecord[];
    const players = records
      .map(normaliseSeedRecord)
      .filter(Boolean) as IdpPlayer[];

    // Deduplicate by key
    const seen = new Set<string>();
    return players.filter(p => {
      const k = idpKey(p.playerName, p.position);
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  } catch (err) {
    console.error("[IDP] Failed to read seed file:", err instanceof Error ? err.message : String(err));
    return [];
  }
}
