/**
 * ktcScraper.ts
 *
 * Fetches KTC dynasty player values by:
 *   1. Trying known JSON API endpoints first.
 *   2. Falling back to HTML extraction from the dynasty-rankings page,
 *      which embeds a JSON player array directly in the rendered HTML.
 *
 * Safety rules:
 *   - Write to .tmp file first; rename atomically only after a successful
 *     non-empty parse.  The last good file is NEVER overwritten with
 *     empty or invalid data.
 *
 * Output shape per record:
 *   { playerName, position, team, age, value, sfValue }
 */

import { writeFile, rename, readFile } from "fs/promises";
import { existsSync }                   from "fs";
import { getKtcValuesPath, getKtcTempPath } from "./paths.js";

// Use centralized path resolution (safe for both ESM dev and CJS production)
const OUT_FILE  = getKtcValuesPath();
const TMP_FILE  = getKtcTempPath();

export interface KtcPlayer {
  playerName: string;
  position:   string;
  team:       string;
  age:        number;
  value:      number;   // 1QB dynasty value
  sfValue:    number;   // Superflex dynasty value
}

// ─── KTC raw record shape (from embedded page JSON) ───────────────────────────

interface KtcRaw {
  playerName?:      string;
  name?:            string;
  position?:        string;
  team?:            string;
  age?:             number;
  oneQBValues?:     { value?: number; tep?: { value?: number } };
  superflexValues?: { value?: number; tep?: { value?: number } };
  value?:           number;
  sfValue?:         number;
  sf_value?:        number;
}

function normaliseRecord(r: KtcRaw): KtcPlayer | null {
  try {
    const name = (r.playerName ?? r.name ?? "").trim();
    const pos  = (r.position ?? "").trim().toUpperCase();
    if (!name || !pos) return null;

    // Dynasty-specific positions only
    const validPos = ["QB","RB","WR","TE","K","DL","LB","DB"];
    if (!validPos.includes(pos)) return null;

    const value   = r.oneQBValues?.value     ?? r.value   ?? 0;
    const sfValue = r.superflexValues?.value ?? r.sfValue ?? r.sf_value ?? value;

    if (value <= 0 && sfValue <= 0) return null;

    return {
      playerName: name,
      position:   pos,
      team:       (r.team ?? "").trim(),
      age:        Number(r.age ?? 0),
      value:      Number(value),
      sfValue:    Number(sfValue),
    };
  } catch {
    return null;
  }
}

function dedup(records: KtcPlayer[]): KtcPlayer[] {
  const seen = new Set<string>();
  return records.filter(r => {
    const k = `${r.playerName}|${r.position}`;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

// ─── Strategy 1: direct JSON endpoints ───────────────────────────────────────

const JSON_ENDPOINTS = [
  "https://keeptradecut.com/dynasty-rankings/rankings-json",
  "https://keeptradecut.com/api/player-values/dynasty",
  "https://keeptradecut.com/api/players",
];

async function tryJsonEndpoint(url: string): Promise<KtcPlayer[]> {
  console.log(`[KTC] Trying JSON endpoint: ${url}`);
  const res = await fetch(url, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; DynastyCommand/1.0)", Accept: "application/json" },
    signal:  AbortSignal.timeout(15_000),
  });
  console.log(`[KTC]   → HTTP ${res.status} | Content-Type: ${res.headers.get("content-type") ?? "unknown"}`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);

  const ct = res.headers.get("content-type") ?? "";
  if (!ct.includes("json")) throw new Error(`Non-JSON content-type: ${ct}`);

  const body: unknown = await res.json();
  const rows = Array.isArray(body)
    ? body
    : Array.isArray((body as any)?.players) ? (body as any).players
    : Array.isArray((body as any)?.data)    ? (body as any).data
    : [];

  const players = dedup((rows as KtcRaw[]).map(normaliseRecord).filter(Boolean) as KtcPlayer[]);
  console.log(`[KTC]   → Parsed ${players.length} players (JSON endpoint)`);
  if (players.length < 50) throw new Error(`Too few players (${players.length}) — wrong format`);
  return players;
}

// ─── Strategy 2: HTML page extraction ────────────────────────────────────────

const HTML_PAGE = "https://keeptradecut.com/dynasty-rankings";

/**
 * Extract the first complete JSON array from a string by counting brackets.
 * KTC embeds the player array directly in the HTML:
 *   [{"playerName":"Bijan Robinson",...},{"playerName":"Josh Allen",...},...]
 */
function extractJsonArray(html: string, marker: string): unknown[] | null {
  const start = html.indexOf(marker);
  if (start === -1) return null;
  const arrayStart = html.lastIndexOf("[", start);
  if (arrayStart === -1) return null;

  let depth = 0;
  let i = arrayStart;
  while (i < html.length) {
    const ch = html[i];
    if (ch === "[" || ch === "{") depth++;
    else if (ch === "]" || ch === "}") {
      depth--;
      if (depth === 0) {
        const candidate = html.slice(arrayStart, i + 1);
        try {
          return JSON.parse(candidate) as unknown[];
        } catch {
          return null;
        }
      }
    } else if (ch === '"') {
      // Skip string contents
      i++;
      while (i < html.length) {
        if (html[i] === "\\") { i += 2; continue; }
        if (html[i] === '"')  { break; }
        i++;
      }
    }
    i++;
  }
  return null;
}

async function tryHtmlExtraction(): Promise<KtcPlayer[]> {
  console.log(`[KTC] Falling back to HTML extraction: ${HTML_PAGE}`);
  const res = await fetch(HTML_PAGE, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
      "Accept":     "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.5",
    },
    signal: AbortSignal.timeout(30_000),
  });
  console.log(`[KTC]   → HTTP ${res.status} | Content-Type: ${res.headers.get("content-type") ?? "unknown"}`);
  if (!res.ok) throw new Error(`HTML page returned HTTP ${res.status}`);

  const html = await res.text();
  console.log(`[KTC]   → Downloaded ${html.length} bytes of HTML`);

  // KTC embeds a player array whose first object always has "playerName"
  const rows = extractJsonArray(html, '"playerName"');
  if (!rows) throw new Error(`Could not extract JSON array from HTML (marker not found)`);

  console.log(`[KTC]   → Extracted ${rows.length} raw records from HTML`);

  const players = dedup((rows as KtcRaw[]).map(normaliseRecord).filter(Boolean) as KtcPlayer[]);
  console.log(`[KTC]   → Normalised to ${players.length} valid players`);
  if (players.length < 50) throw new Error(`Too few players (${players.length}) after normalisation`);
  return players;
}

// ─── Main scrape entry point ──────────────────────────────────────────────────

/**
 * Run the full scrape.  Tries JSON endpoints first, then HTML extraction.
 * Only writes to disk after a successful non-empty parse.
 * On failure: logs the error; last good file remains untouched.
 */
export async function runKtcScrape(): Promise<KtcPlayer[] | null> {
  console.log("[KTC] ─── Scrape starting ───────────────────────────────────");

  let players: KtcPlayer[] | null = null;
  let lastError = "";

  // Strategy 1: JSON endpoints
  for (const url of JSON_ENDPOINTS) {
    try {
      players = await tryJsonEndpoint(url);
      break;
    } catch (err) {
      lastError = err instanceof Error ? err.message : String(err);
      console.warn(`[KTC]   JSON endpoint failed: ${lastError}`);
    }
  }

  // Strategy 2: HTML extraction
  if (!players) {
    try {
      players = await tryHtmlExtraction();
    } catch (err) {
      lastError = err instanceof Error ? err.message : String(err);
      console.error(`[KTC]   HTML extraction failed: ${lastError}`);
    }
  }

  if (!players || players.length === 0) {
    console.error(`[KTC] ✗ Scrape failed — no players extracted. Last error: ${lastError}`);
    console.log("[KTC] ─── Scrape ended (FAILURE) ───────────────────────────");
    return null;
  }

  // Atomic write: temp → rename
  try {
    await writeFile(TMP_FILE, JSON.stringify(players, null, 2), "utf8");
    await rename(TMP_FILE, OUT_FILE);
    console.log(`[KTC] ✓ Wrote ${players.length} players to ${OUT_FILE}`);
    console.log(`[KTC]   Sample: ${players.slice(0, 3).map(p => `${p.playerName} (${p.position}) val=${p.value} sf=${p.sfValue}`).join(" | ")}`);
  } catch (err) {
    console.error(`[KTC] ✗ Failed to write file: ${err instanceof Error ? err.message : String(err)}`);
    return null;
  }

  console.log("[KTC] ─── Scrape ended (SUCCESS) ──────────────────────────");
  return players;
}

// ─── Cache read ───────────────────────────────────────────────────────────────

export async function readKtcValues(): Promise<KtcPlayer[]> {
  if (!existsSync(OUT_FILE)) return [];
  try {
    const raw = await readFile(OUT_FILE, "utf8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function ktcCacheExists(): boolean {
  return existsSync(OUT_FILE);
}
