import { Router, type IRouter } from "express";
import healthRouter   from "./health.js";
import ktcRouter      from "./ktcValues.js";
import coverageRouter from "./ktcCoverage.js";
import idpRouter      from "./idpRankings.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(ktcRouter);         // GET /api/ktc-values
router.use(coverageRouter);    // GET /api/ktc-coverage  (debug)
router.use(idpRouter);         // GET /api/idp-rankings, GET /api/idp-coverage

export default router;
