/**
 * GET /api/ktc-coverage  (DEBUG — dev only)
 *
 * Fetches Sleeper's full player database, cross-references every active
 * offensive/IDP player against the local KTC marketValues map
 * (using the same normalized name+position key the frontend uses),
 * then returns + logs a full coverage report.
 *
 * Report includes:
 *   - scraped / normalized / map-size counts
 *   - per-position match rates (QB RB WR TE DL LB DB)
 *   - 10 matched sample players
 *   - 10 fallback (unmatched) sample players
 *   - confirmation that IDP is expected-fallback
 */

import { Router } from "express";
import { readKtcValues, type KtcPlayer } from "../lib/ktcScraper.js";

const router = Router();

// ─── Name normalisation (mirrors frontend utils/normalize.ts) ─────────────────
function normName(name: string): string {
  return name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9 ]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function normPos(raw: string): string {
  const map: Record<string, string> = {
    qb:"QB", rb:"RB", wr:"WR", te:"TE",
    dl:"DL", lb:"LB", db:"DB", k:"K",
    de:"DL", dt:"DL", edge:"DL",
    s:"DB",  cb:"DB", fs:"DB", ss:"DB",
    fb:"RB",
  };
  return map[raw.toLowerCase()] ?? raw.toUpperCase();
}

/** Build the same key the frontend uses: "ktc:{norm-name}-{pos}" */
function ktcKey(name: string, pos: string): string {
  return `ktc:${normName(name)}-${pos.toLowerCase()}`;
}

// ─── Sleeper player shape (only fields we need) ───────────────────────────────
interface SleeperPlayerMin {
  first_name?: string;
  last_name?:  string;
  position?:   string;
  fantasy_positions?: string[];
  team?:       string;
  status?:     string;
  age?:        number;
}

const SLEEPER_PLAYERS_URL = "https://api.sleeper.app/v1/players/nfl";

// Positions we report coverage for
const TRACKED_POSITIONS = new Set(["QB","RB","WR","TE","DL","LB","DB"]);
const IDP_POSITIONS     = new Set(["DL","LB","DB"]);
const OFF_POSITIONS     = new Set(["QB","RB","WR","TE"]);

router.get("/ktc-coverage", async (_req, res) => {
  console.log("\n[Coverage] ─── KTC coverage report starting ──────────────────");

  // 1. Load local KTC data
  const ktcPlayers: KtcPlayer[] = await readKtcValues();
  const ktcMap = new Map<string, KtcPlayer>();
  for (const p of ktcPlayers) {
    const k = ktcKey(p.playerName, p.position);
    if (!ktcMap.has(k)) ktcMap.set(k, p);
  }

  console.log(`[Coverage] KTC scraped records : ${ktcPlayers.length}`);
  console.log(`[Coverage] KTC normalised keys : ${ktcMap.size}`);

  // 2. Fetch Sleeper player DB
  let sleeperPlayers: Record<string, SleeperPlayerMin> = {};
  try {
    console.log(`[Coverage] Fetching Sleeper player DB from ${SLEEPER_PLAYERS_URL} …`);
    const r = await fetch(SLEEPER_PLAYERS_URL, {
      headers: { "User-Agent": "DynastyCommand/1.0" },
      signal: AbortSignal.timeout(30_000),
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    sleeperPlayers = await r.json() as Record<string, SleeperPlayerMin>;
    console.log(`[Coverage] Sleeper players fetched: ${Object.keys(sleeperPlayers).length} total`);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`[Coverage] Sleeper fetch failed: ${msg}`);
    res.status(503).json({ error: `Sleeper fetch failed: ${msg}` });
    return;
  }

  // 3. Cross-reference
  type MatchRow = { name: string; pos: string; team: string; age: number; key: string; ktcVal?: number };

  const matched: MatchRow[] = [];
  const fallback: MatchRow[] = [];
  const byPos: Record<string, { matched: number; fallback: number }> = {};

  for (const [, p] of Object.entries(sleeperPlayers)) {
    const rawPos = p.fantasy_positions?.[0] ?? p.position ?? "";
    const pos    = normPos(rawPos);
    if (!TRACKED_POSITIONS.has(pos)) continue;

    // Only active / rostered players (skip free agents with no team for offensive, IDP always included)
    const hasTeam = !!p.team;
    if (OFF_POSITIONS.has(pos) && !hasTeam) continue;  // skip FA offensive players

    const name = `${p.first_name ?? ""} ${p.last_name ?? ""}`.trim();
    if (!name) continue;

    if (!byPos[pos]) byPos[pos] = { matched: 0, fallback: 0 };

    const key    = ktcKey(name, pos);
    const ktcRec = ktcMap.get(key);

    const row: MatchRow = { name, pos, team: p.team ?? "FA", age: p.age ?? 0, key };

    if (ktcRec) {
      row.ktcVal = ktcRec.value;
      matched.push(row);
      byPos[pos].matched++;
    } else {
      fallback.push(row);
      byPos[pos].fallback++;
    }
  }

  // 4. Build report
  const totalMatched  = matched.length;
  const totalFallback = fallback.length;
  const totalTracked  = totalMatched + totalFallback;
  const matchRate     = totalTracked > 0
    ? `${((totalMatched / totalTracked) * 100).toFixed(1)}%`
    : "n/a";

  const posStats = Object.entries(byPos).map(([pos, { matched: m, fallback: f }]) => ({
    pos,
    matched: m,
    fallback: f,
    total: m + f,
    rate: m + f > 0 ? `${((m / (m + f)) * 100).toFixed(1)}%` : "n/a",
    note: IDP_POSITIONS.has(pos) ? "IDP — formula/VORP expected" : "",
  })).sort((a, b) => b.total - a.total);

  const sampleMatched  = matched.slice(0, 10);
  const sampleFallback = fallback.slice(0, 10);

  // 5. Console report
  console.log(`\n[Coverage] ═══ FULL REPORT ═══════════════════════════════════`);
  console.log(`[Coverage]  KTC scraped       : ${ktcPlayers.length}`);
  console.log(`[Coverage]  KTC map keys      : ${ktcMap.size}`);
  console.log(`[Coverage]  Sleeper pool      : ${totalTracked} active players tracked`);
  console.log(`[Coverage]  Matched (KTC)     : ${totalMatched}  (${matchRate})`);
  console.log(`[Coverage]  Fallback (formula): ${totalFallback}`);
  console.log(`[Coverage]`);
  console.log(`[Coverage]  By position:`);
  for (const s of posStats) {
    console.log(
      `[Coverage]    ${s.pos.padEnd(4)}  matched=${String(s.matched).padStart(3)}  ` +
      `fallback=${String(s.fallback).padStart(3)}  total=${String(s.total).padStart(3)}  ` +
      `rate=${s.rate.padStart(6)}  ${s.note}`
    );
  }
  console.log(`[Coverage]`);
  console.log(`[Coverage]  10 matched samples:`);
  for (const p of sampleMatched) {
    console.log(`[Coverage]    ✓ ${p.name} (${p.pos}) ${p.team}  key=${p.key}  val=${p.ktcVal}`);
  }
  console.log(`[Coverage]`);
  console.log(`[Coverage]  10 fallback samples:`);
  for (const p of sampleFallback) {
    console.log(`[Coverage]    ~ ${p.name} (${p.pos}) ${p.team}  key=${p.key}`);
  }
  console.log(`[Coverage] ════════════════════════════════════════════════════\n`);

  // 6. Return JSON
  res.json({
    ktcScraped:    ktcPlayers.length,
    ktcMapKeys:    ktcMap.size,
    sleeperPool:   totalTracked,
    totalMatched,
    totalFallback,
    matchRate,
    byPosition:    posStats,
    sampleMatched,
    sampleFallback,
  });
});

export default router;
