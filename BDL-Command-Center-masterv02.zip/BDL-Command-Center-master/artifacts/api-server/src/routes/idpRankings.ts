/**
 * idpRankings.ts — Express routes for IDP dynasty data.
 *
 * GET /api/idp-rankings
 *   Returns all IDP ranked players from the seed file.
 *   Response: { players: IdpPlayer[], meta: { source, count, lastLoaded } }
 *
 * GET /api/idp-coverage
 *   Debug endpoint: cross-references IDP seed against Sleeper player DB.
 *   Reports match rate by DL / LB / DB.
 */

import { Router }          from "express";
import { readIdpRankings, idpKey, normIdpName, type IdpPlayer } from "../lib/idpRankings.js";

const router = Router();

// ─── GET /api/idp-rankings ────────────────────────────────────────────────────

router.get("/idp-rankings", async (_req, res) => {
  try {
    const players = await readIdpRankings();
    res.json({
      players,
      meta: {
        source:     "idp_seed",
        count:      players.length,
        lastLoaded: new Date().toISOString(),
      },
    });
  } catch (err) {
    res.status(500).json({
      players: [],
      meta:    { source: "idp_seed", count: 0, lastLoaded: null },
      error:   `Failed to load IDP rankings: ${err instanceof Error ? err.message : String(err)}`,
    });
  }
});

// ─── GET /api/idp-coverage ────────────────────────────────────────────────────

interface SleeperPlayerMin {
  first_name?: string;
  last_name?:  string;
  position?:   string;
  fantasy_positions?: string[];
  team?:       string;
  age?:        number;
}

function normPos(raw: string): string {
  const map: Record<string, string> = {
    dl:"DL", lb:"LB", db:"DB",
    de:"DL", dt:"DL", edge:"DL",
    s:"DB",  cb:"DB", fs:"DB", ss:"DB",
  };
  return map[raw.toLowerCase()] ?? raw.toUpperCase();
}

const IDP_POS = new Set(["DL","LB","DB"]);
const SLEEPER_URL = "https://api.sleeper.app/v1/players/nfl";

router.get("/idp-coverage", async (_req, res) => {
  console.log("\n[IdpCoverage] ─── IDP coverage report starting ────────────────");

  // 1. Load IDP seed
  const idpPlayers: IdpPlayer[] = await readIdpRankings();
  const idpMap = new Map<string, IdpPlayer>();
  for (const p of idpPlayers) {
    const k = idpKey(p.playerName, p.position);
    if (!idpMap.has(k)) idpMap.set(k, p);
  }
  console.log(`[IdpCoverage] IDP seed records : ${idpPlayers.length}`);
  console.log(`[IdpCoverage] IDP map keys     : ${idpMap.size}`);

  // 2. Fetch Sleeper player DB
  let sleeperPlayers: Record<string, SleeperPlayerMin> = {};
  try {
    const r = await fetch(SLEEPER_URL, {
      headers: { "User-Agent": "DynastyCommand/1.0" },
      signal: AbortSignal.timeout(30_000),
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    sleeperPlayers = await r.json() as Record<string, SleeperPlayerMin>;
    console.log(`[IdpCoverage] Sleeper players  : ${Object.keys(sleeperPlayers).length} total`);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`[IdpCoverage] Sleeper fetch failed: ${msg}`);
    res.status(503).json({ error: `Sleeper fetch failed: ${msg}` });
    return;
  }

  // 3. Cross-reference IDP positions only
  type Row = { name: string; pos: string; team: string; age: number; key: string; seedVal?: number };
  const matched: Row[]  = [];
  const fallback: Row[] = [];
  const byPos: Record<string, { matched: number; fallback: number }> = {
    DL: { matched: 0, fallback: 0 },
    LB: { matched: 0, fallback: 0 },
    DB: { matched: 0, fallback: 0 },
  };

  for (const [, p] of Object.entries(sleeperPlayers)) {
    const rawPos = p.fantasy_positions?.[0] ?? p.position ?? "";
    const pos    = normPos(rawPos);
    if (!IDP_POS.has(pos)) continue;
    if (!p.team) continue;   // skip retired/FA

    const name = `${p.first_name ?? ""} ${p.last_name ?? ""}`.trim();
    if (!name) continue;

    const key    = `idp:${normIdpName(name)}-${pos.toLowerCase()}`;
    const rec    = idpMap.get(key);
    const row: Row = { name, pos, team: p.team, age: p.age ?? 0, key };

    if (rec) {
      row.seedVal = rec.value;
      matched.push(row);
      (byPos[pos] ??= { matched: 0, fallback: 0 }).matched++;
    } else {
      fallback.push(row);
      (byPos[pos] ??= { matched: 0, fallback: 0 }).fallback++;
    }
  }

  // 4. Build stats
  const totalMatched  = matched.length;
  const totalFallback = fallback.length;
  const totalTracked  = totalMatched + totalFallback;
  const matchRate     = totalTracked > 0
    ? `${((totalMatched / totalTracked) * 100).toFixed(1)}%`
    : "n/a";

  const posStats = Object.entries(byPos).map(([pos, { matched: m, fallback: f }]) => ({
    pos,
    matched: m,
    fallback: f,
    total: m + f,
    rate: m + f > 0 ? `${((m / (m + f)) * 100).toFixed(1)}%` : "n/a",
  }));

  // 5. Log
  console.log(`\n[IdpCoverage] ═══ REPORT ═══════════════════════════════════════`);
  console.log(`[IdpCoverage]  IDP seed        : ${idpPlayers.length} players`);
  console.log(`[IdpCoverage]  IDP map keys    : ${idpMap.size}`);
  console.log(`[IdpCoverage]  Sleeper IDP pool: ${totalTracked} active IDP players tracked`);
  console.log(`[IdpCoverage]  Matched (seed)  : ${totalMatched}  (${matchRate})`);
  console.log(`[IdpCoverage]  Fallback (VORP) : ${totalFallback}`);
  console.log(`[IdpCoverage]`);
  for (const s of posStats) {
    console.log(
      `[IdpCoverage]    ${s.pos.padEnd(4)} matched=${String(s.matched).padStart(3)} ` +
      `fallback=${String(s.fallback).padStart(4)} total=${String(s.total).padStart(4)} ` +
      `rate=${s.rate.padStart(6)}`
    );
  }
  console.log(`[IdpCoverage]`);
  console.log(`[IdpCoverage]  10 matched samples:`);
  for (const p of matched.slice(0, 10)) {
    console.log(`[IdpCoverage]    ✓ ${p.name} (${p.pos}) ${p.team}  val=${p.seedVal}`);
  }
  console.log(`[IdpCoverage]`);
  console.log(`[IdpCoverage]  10 fallback samples (active players not in seed):`);
  for (const p of fallback.slice(0, 10)) {
    console.log(`[IdpCoverage]    ~ ${p.name} (${p.pos}) ${p.team}`);
  }
  console.log(`[IdpCoverage] ══════════════════════════════════════════════════\n`);

  res.json({
    idpSeedPlayers:  idpPlayers.length,
    idpMapKeys:      idpMap.size,
    sleeperIdpPool:  totalTracked,
    totalMatched,
    totalFallback,
    matchRate,
    byPosition:      posStats,
    sampleMatched:   matched.slice(0, 10),
    sampleFallback:  fallback.slice(0, 10),
  });
});

export default router;
