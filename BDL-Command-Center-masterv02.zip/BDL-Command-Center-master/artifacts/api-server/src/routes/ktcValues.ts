/**
 * GET /api/ktc-values
 *
 * Implements stale-while-revalidate:
 *   - Fresh cache  → return immediately, stale=false
 *   - Stale cache  → return immediately, stale=true, background refresh
 *   - No cache     → blocking scrape, then return
 *
 * Response shape:
 * {
 *   "players": [...],
 *   "meta": {
 *     "lastUpdated": "<iso> | null",
 *     "stale":       true | false,
 *     "refreshing":  true | false
 *   }
 * }
 */

import { Router } from "express";
import { getKtcData } from "../lib/ktcCache.js";

const router = Router();

router.get("/ktc-values", async (_req, res) => {
  try {
    const result = await getKtcData();

    const body: Record<string, unknown> = {
      players: result.players,
      meta: {
        lastUpdated: result.lastUpdated,
        stale:       result.stale,
        refreshing:  result.refreshing,
      },
    };

    if (result.error) body.error = result.error;

    res.status(result.status).json(body);
  } catch (err) {
    console.error("[/api/ktc-values]", err);
    res.status(500).json({
      players: [],
      meta: { lastUpdated: null, stale: true, refreshing: false },
      error: "Internal server error",
    });
  }
});

export default router;
