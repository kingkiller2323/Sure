/**
 * App.tsx — UI & state wiring only.
 *
 * No hardcoded player values, pick values, or dynasty rankings live here.
 * All data flows from the service layer:
 *   services/platforms/sleeper.ts   → API adapter
 *   services/consensus.ts           → provider aggregator
 *   services/valuation.ts           → value engine
 *   services/picks.ts               → dynamic pick pool
 *   services/rookies.ts             → dynamic rookie board
 *   services/tradeCalculator.ts     → trade logic
 *   services/manualLeague.ts        → manual league setup
 */

import { useState, useEffect, useCallback } from "react";

import {
  fetchLeague, fetchUsers, fetchRosters, fetchMatchups,
  fetchTransactions, fetchNflState, fetchAllPlayers,
  sleeperTeamName, sleeperPrimaryPosition, sleeperFormatContext,
  type SleeperLeague, type SleeperUser, type SleeperRoster,
  type SleeperMatchup, type SleeperTransaction, type SleeperPlayer,
} from "./services/platforms/sleeper";

import { loadConsensusData, type ConsensusData, type ProviderStatus } from "./services/consensus";
import { buildSleeperIdBridge, convertSleeperPlayers, logBridgeStats, type BridgeStats } from "./services/playerIdentityRegistry";
import { PosTag, InjuryBadge, Card, SectionHeader, ProviderBanner, FallbackTag } from "./components/ui/shared";
import { computePlayerValue, type ValuationContext, type TradeMode } from "./services/valuation";
import { buildPlayerPool, buildPickPool, computeVerdict, type TradeAsset } from "./services/tradeCalculator";
import { loadRookieBoard, filterRookieBoard, type RookieBoard } from "./services/rookies";
import { defaultManualSettings, manualSettingsToFormatContext, type ManualLeagueSettings } from "./services/manualLeague";
import LeagueEntryScreen from "./features/league-import/LeagueEntryScreen";
import RosterTab from "./features/roster/RosterTab";
import StandingsTab from "./features/standings/StandingsTab";
import { CURRENT_ROOKIE_CLASS } from "./config/dataSources";
import { POS_COLORS, TIER_LABELS, valueTier } from "./utils/positions";

const APP_VERSION = "2.0.0";

const NEWS_FEEDS = [
  { name:"Rotowire",    url:"https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fwww.rotowire.com%2Frss%2Fnews.php",                    color:"#22c55e" },
  { name:"ESPN NFL",    url:"https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fwww.espn.com%2Fespn%2Frss%2Fnfl%2Fnews",               color:"#ef4444" },
  { name:"Yahoo Sports",url:"https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fsports.yahoo.com%2Fnfl%2Frss.xml",                     color:"#8b5cf6" },
  { name:"NFL.com",     url:"https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fwww.nfl.com%2Frss%2Frsslanding%3FsearchString%3Dnews", color:"#3b82f6" },
];

// ── League App ─────────────────────────────────────────────────────────────────

interface LeagueAppProps {
  leagueId:      string | null;       // null = manual mode
  initialLeague: SleeperLeague | null;
  manualSettings: ManualLeagueSettings | null;
  onDisconnect:  () => void;
}

function LeagueApp({ leagueId, initialLeague, manualSettings, onDisconnect }: LeagueAppProps) {
  const [tab, setTab]               = useState("roster");
  const [users, setUsers]           = useState<SleeperUser[]>([]);
  const [rosters, setRosters]       = useState<SleeperRoster[]>([]);
  const [players, setPlayers]       = useState<Record<string, SleeperPlayer>>({});
  const [transactions, setTrans]    = useState<SleeperTransaction[]>([]);
  const [matchups, setMatchups]     = useState<SleeperMatchup[]>([]);
  const [selectedTeam, setSelectedTeam] = useState<number | null>(null);
  // myRosterId persisted in localStorage keyed by league:{leagueId}:myRosterId
  const [myRosterId, setMyRosterId] = useState<number | null>(() => {
    if (!leagueId) return null;
    try {
      const stored = localStorage.getItem(`league:${leagueId}:myRosterId`);
      return stored ? Number(stored) : null;
    } catch { return null; }
  });
  const [loading, setLoading]       = useState(true);
  const [playersLoading, setPlayersLoading] = useState(true);
  const [news, setNews]             = useState<{title:string;link:string;pubDate:string;description:string;source:string;color:string}[]>([]);
  const [newsLoading, setNewsLoading] = useState(false);
  const [newsLoaded, setNewsLoaded] = useState(false);
  const [currentWeek, setCurrentWeek] = useState(1);
  const [consensus, setConsensus]   = useState<ConsensusData | null>(null);
  const [rookieBoard, setRookieBoard] = useState<RookieBoard | null>(null);
  const [tradeMode, setTradeMode]   = useState<TradeMode>("balanced");
  const [giveSide, setGiveSide]     = useState<string[]>([]);
  const [getSide, setGetSide]       = useState<string[]>([]);
  const [tradeSubTab, setTradeSubTab] = useState("search");
  const [addingTo, setAddingTo]     = useState<"give"|"get">("give");
  const [tradeSearch, setTradeSearch] = useState("");
  const [tradePosFilter, setTradePosFilter] = useState("ALL");
  const [faSearch, setFaSearch]     = useState("");
  const [faPosFilter, setFaPosFilter] = useState("ALL");
  const [draftNotes, setDraftNotes] = useState<Record<string, string>>(() => {
    try { return JSON.parse(localStorage.getItem("draft_notes") || "{}"); } catch { return {}; }
  });
  const [draftFilter, setDraftFilter] = useState("ALL");
  const [showMore, setShowMore]     = useState(false);

  // Derive format context from loaded league or manual settings
  const formatCtx = (() => {
    if (manualSettings) return manualSettingsToFormatContext(manualSettings);
    if (initialLeague && rosters.length) return sleeperFormatContext(initialLeague, rosters);
    return { superflex:false, tePremium:false, idpEnabled:false, leagueSize:12 };
  })();

  const leagueName  = initialLeague?.name ?? manualSettings?.name ?? "Dynasty Command";
  const leagueSeason = initialLeague?.season ?? String(manualSettings?.season ?? "");

  // Persist myRosterId to localStorage when it changes
  const handleSetMyRosterId = useCallback((id: number) => {
    setMyRosterId(id);
    if (leagueId) {
      try { localStorage.setItem(`league:${leagueId}:myRosterId`, String(id)); } catch {}
    }
  }, [leagueId]);

  // ── Load Sleeper league data ──────────────────────────────────────────────
  useEffect(() => {
    if (!leagueId) { setLoading(false); return; }
    const load = async () => {
      try {
        const [usersData, rostersData] = await Promise.all([
          fetchUsers(leagueId),
          fetchRosters(leagueId),
        ]);
        setUsers(usersData);
        setRosters(rostersData);
        setSelectedTeam(rostersData[0]?.roster_id ?? null);
        try { const t = await fetchTransactions(leagueId, 1); setTrans(t||[]); } catch {}
        try {
          const state = await fetchNflState();
          const week  = state?.week ?? 1;
          setCurrentWeek(week);
          const m = await fetchMatchups(leagueId, week);
          setMatchups(m||[]);
        } catch {}
        setLoading(false);
        // Players is large — load in background
        const pData = await fetchAllPlayers();
        setPlayers(pData);
        setPlayersLoading(false);
      } catch {
        setLoading(false);
        setPlayersLoading(false);
      }
    };
    load();
  }, [leagueId]);

  // ── Load consensus data once format context is known ─────────────────────
  useEffect(() => {
    if (loading) return;
    loadConsensusData(formatCtx, CURRENT_ROOKIE_CLASS).then(setConsensus);
  }, [loading, formatCtx.superflex, formatCtx.tePremium, formatCtx.idpEnabled]);

  // ── Bridge Sleeper IDs to KTC/IDP keys after both are loaded ──────────────
  // Track whether bridge has been applied to prevent re-running
  const [bridgeApplied, setBridgeApplied] = useState(false);
  const [bridgeStats, setBridgeStats] = useState<BridgeStats | null>(null);

  useEffect(() => {
    // Only run once when consensus and players are both ready
    if (bridgeApplied || !consensus || playersLoading || Object.keys(players).length === 0) return;

    // Convert raw Sleeper players to the format expected by the bridge
    const sleeperRecords = convertSleeperPlayers(players);

    // Measure before state
    const sleeperKeysBefore = Array.from(consensus.marketValues.keys()).filter(k => k.startsWith("sleeper:")).length;

    // Build the bridge and get updated consensus
    const { consensus: updatedConsensus, stats } = buildSleeperIdBridge(
      sleeperRecords,
      consensus
    );

    // Measure after state
    const sleeperKeysAfter = Array.from(updatedConsensus.marketValues.keys()).filter(k => k.startsWith("sleeper:")).length;

    // Enhanced logging with before/after comparison
    console.log("[PlayerIdentityRegistry] ═══ Runtime Validation ═══════════════════");
    console.log(`[PlayerIdentityRegistry]   sleeper:{id} keys BEFORE bridge: ${sleeperKeysBefore}`);
    console.log(`[PlayerIdentityRegistry]   sleeper:{id} keys AFTER bridge:  ${sleeperKeysAfter}`);
    console.log(`[PlayerIdentityRegistry]   NEW direct lookups enabled: ${sleeperKeysAfter - sleeperKeysBefore}`);
    logBridgeStats(stats);

    // Store stats for potential UI display
    setBridgeStats(stats);

    // Update consensus with bridged entries and mark as applied
    setConsensus(updatedConsensus);
    setBridgeApplied(true);
  }, [bridgeApplied, playersLoading, Object.keys(players).length > 0, consensus?.hasMarketData]);

  // ── Load rookie board when consensus is ready ─────────────────────────────
  useEffect(() => {
    if (!consensus) return;
    loadRookieBoard(formatCtx, CURRENT_ROOKIE_CLASS).then(setRookieBoard);
  }, [consensus]);

  // ── Load news lazily ──────────────────────────────────────────────────────
  useEffect(() => {
    if (tab !== "news" || newsLoaded) return;
    const loadNews = async () => {
      setNewsLoading(true);
      const all: typeof news = [];
      await Promise.allSettled(NEWS_FEEDS.map(async feed => {
        try {
          const res  = await fetch(feed.url);
          const data = await res.json();
          (data.items||[]).slice(0,15).forEach((item: any) => {
            all.push({ title:item.title, link:item.link, pubDate:item.pubDate,
              description:(item.description||"").replace(/<[^>]+>/g,"").slice(0,200),
              source:feed.name, color:feed.color });
          });
        } catch {}
      }));
      all.sort((a,b) => new Date(b.pubDate).getTime()-new Date(a.pubDate).getTime());
      setNews(all);
      setNewsLoading(false);
      setNewsLoaded(true);
    };
    loadNews();
  }, [tab, newsLoaded]);

  // ── Helpers ───────────────────────────────────────────────────────────────
  const getTeamNameById = useCallback((rosterId: number) => {
    const r = rosters.find(r => r.roster_id === rosterId);
    return r ? sleeperTeamName(r, users) : `Team ${rosterId}`;
  }, [rosters, users]);

  const getPlayer    = useCallback((id: string) => players[id] ?? null, [players]);
  const getPlayerName= useCallback((id: string) => {
    const p = players[id];
    return p ? `${p.first_name} ${p.last_name}` : id;
  }, [players]);
  const getPos       = useCallback((id: string) => sleeperPrimaryPosition(players[id] ?? {first_name:"",last_name:"",position:"?"} as SleeperPlayer), [players]);

  const valuationCtx = useCallback((): ValuationContext => ({
    consensus: consensus ?? {
      marketValues: new Map(), dynastyRanks: new Map(), rookieRanks: new Map(),
      providerStatus: [], hasMarketData: false, hasIdpData: false, hasRankData: false,
    },
    format: formatCtx,
    mode:   tradeMode,
  }), [consensus, formatCtx, tradeMode]);

  const getPlayerValue = useCallback((id: string): { value: number; fallback: boolean } => {
    const p   = players[id];
    if (!p) return { value: 1000, fallback: true };
    const pos = sleeperPrimaryPosition(p);
    const res = computePlayerValue(
      { sleeperId: id, name:`${p.first_name} ${p.last_name}`, position: pos, age: p.age },
      valuationCtx()
    );
    return { value: res.adjustedValue, fallback: res.formulaFallback };
  }, [players, valuationCtx]);

  const allRosteredIds = new Set(rosters.flatMap(r => [
    ...(r.players||[]), ...(r.taxi||[]), ...(r.reserve||[])
  ]));

  const NAV = [
    {id:"roster",    icon:"👥", label:"Roster"},
    {id:"standings", icon:"📊", label:"Standings"},
    {id:"trade",     icon:"⚖️", label:"Trade"},
    {id:"fa",        icon:"🔍", label:"FA"},
    {id:"more",      icon:"⋯",  label:"More"},
  ];
  const MORE_TABS = [
    {id:"news",     icon:"📰", label:"News"},
    {id:"draft",    icon:"📋", label:"Draft Board"},
    {id:"matchups", icon:"📅", label:"Matchups"},
    {id:"txns",     icon:"🔄", label:"Transactions"},
  ];
  const activeLabel = [...NAV, ...MORE_TABS].find(n => n.id === tab)?.label ?? "";

  if (loading) {
    return (
      <div style={{ minHeight:"100vh", background:"#08080f", display:"flex",
        flexDirection:"column", alignItems:"center", justifyContent:"center",
        fontFamily:"'DM Mono',monospace", color:"#8b5cf6", gap:"14px" }}>
        <style>{`@keyframes slide{0%{transform:translateX(-200%)}100%{transform:translateX(700%)}}`}</style>
        <div style={{ fontSize:"36px" }}>👑</div>
        <div style={{ fontSize:"13px", letterSpacing:"0.1em" }}>LOADING LEAGUE</div>
        <div style={{ fontSize:"11px", color:"#374151" }}>{leagueName}</div>
        <div style={{ width:"180px", height:"3px", background:"rgba(139,92,246,0.15)", borderRadius:"2px", overflow:"hidden" }}>
          <div style={{ height:"100%", width:"35%", background:"linear-gradient(90deg,#8b5cf6,#3b82f6)", borderRadius:"2px", animation:"slide 1.2s ease-in-out infinite" }} />
        </div>
      </div>
    );
  }

  // ── ROSTER TAB (extracted, wired with props) ─────────────────────────────────────
  const RosterTabWrapped = () => (
    <RosterTab
      rosters={rosters}
      users={users}
      selectedTeam={selectedTeam}
      myRosterId={myRosterId}
      consensus={consensus}
      playersLoading={playersLoading}
      setSelectedTeam={setSelectedTeam}
      handleSetMyRosterId={handleSetMyRosterId}
      getPlayer={getPlayer}
      getPos={getPos}
      getPlayerName={getPlayerName}
      getPlayerValue={getPlayerValue}
    />
  );

  // ── STANDINGS TAB (extracted, wired with props) ──────────────────────────────────
  const StandingsTabWrapped = () => (
    <StandingsTab
      rosters={rosters}
      users={users}
      initialLeague={initialLeague}
      manualSettings={manualSettings}
      leagueName={leagueName}
      leagueSeason={leagueSeason}
      myRosterId={myRosterId}
      formatCtx={formatCtx}
      setSelectedTeam={setSelectedTeam}
      setTab={setTab}
    />
  );

  // ── MATCHUPS TAB ───────────────────────────────────────────────────────────
  const MatchupsTab = () => {
    const grouped: Record<number, SleeperMatchup[]> = {};
    matchups.forEach(m => { if(!grouped[m.matchup_id]) grouped[m.matchup_id]=[]; grouped[m.matchup_id].push(m); });
    return (
      <div style={{ flex:1, overflowY:"auto", padding:"12px" }}>
        <div style={{ fontSize:"10px",color:"#4b5563",letterSpacing:"0.08em",marginBottom:"10px" }}>WEEK {currentWeek} MATCHUPS</div>
        {Object.values(grouped).length===0 ? (
          <div style={{ textAlign:"center",color:"#374151",padding:"40px 0" }}>
            <div style={{ fontSize:"32px",marginBottom:"8px" }}>📅</div>
            <div style={{ fontSize:"13px" }}>No matchup data available</div>
          </div>
        ) : Object.values(grouped).map((pair,i) => {
          if(pair.length<2) return null;
          const [a,b]=pair;
          const nameA=getTeamNameById(a.roster_id), nameB=getTeamNameById(b.roster_id);
          const ptsA=a.points??0, ptsB=b.points??0;
          const winner=ptsA>ptsB?"a":ptsB>ptsA?"b":null;
          return (
            <Card key={i} style={{ marginBottom:"8px" }}>
              <div style={{ display:"flex",alignItems:"center",gap:"8px" }}>
                <div style={{ flex:1,textAlign:"right" }}>
                  <div style={{ fontSize:"13px",color:winner==="a"?"#22c55e":"#e2e8f0",fontWeight:winner==="a"?"700":"400",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{nameA}</div>
                  <div style={{ fontSize:"18px",fontWeight:"800",color:winner==="a"?"#22c55e":"#e2e8f0" }}>{ptsA.toFixed(1)}</div>
                </div>
                <div style={{ fontSize:"11px",color:"#4b5563",padding:"0 6px",letterSpacing:"0.06em",flexShrink:0 }}>VS</div>
                <div style={{ flex:1,textAlign:"left" }}>
                  <div style={{ fontSize:"13px",color:winner==="b"?"#22c55e":"#e2e8f0",fontWeight:winner==="b"?"700":"400",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{nameB}</div>
                  <div style={{ fontSize:"18px",fontWeight:"800",color:winner==="b"?"#22c55e":"#e2e8f0" }}>{ptsB.toFixed(1)}</div>
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    );
  };

  // ── FREE AGENCY TAB ────────────────────────────────────────────────────────
  const FreeAgencyTab = () => {
    const POSITIONS_FA = ["ALL","QB","RB","WR","TE","DL","LB","DB","K"];
    const ctx = valuationCtx();
    const faPlayers = Object.entries(players)
      .filter(([id, p]) => {
        if (allRosteredIds.has(id)) return false;
        const pos = sleeperPrimaryPosition(p);
        if (!["QB","RB","WR","TE","DL","LB","DB","K"].includes(pos)) return false;
        if (faPosFilter !== "ALL" && pos !== faPosFilter) return false;
        if (faSearch && !`${p.first_name} ${p.last_name}`.toLowerCase().includes(faSearch.toLowerCase())) return false;
        return true;
      })
      .map(([id, p]) => {
        const pos = sleeperPrimaryPosition(p);
        const res = computePlayerValue({ sleeperId:id, name:`${p.first_name} ${p.last_name}`, position:pos, age:p.age }, ctx);
        return { id, p, pos, value:res.adjustedValue, fallback:res.formulaFallback };
      })
      .sort((a,b) => b.value-a.value)
      .slice(0, 100);

    return (
      <div style={{ flex:1,display:"flex",flexDirection:"column",overflow:"hidden" }}>
        <div style={{ padding:"8px 12px",borderBottom:"1px solid rgba(255,255,255,0.05)",flexShrink:0 }}>
          <input value={faSearch} onChange={e=>setFaSearch(e.target.value)} placeholder="Search free agents..."
            style={{ width:"100%",padding:"8px 12px",background:"rgba(255,255,255,0.06)",
              border:"1px solid rgba(255,255,255,0.1)",borderRadius:"7px",color:"#e2e8f0",
              fontSize:"14px",fontFamily:"inherit",boxSizing:"border-box",outline:"none" }} />
        </div>
        <div style={{ padding:"6px 12px",display:"flex",gap:"5px",overflowX:"auto",borderBottom:"1px solid rgba(255,255,255,0.04)",flexShrink:0 }}>
          {POSITIONS_FA.map(pos => (
            <button key={pos} onClick={()=>setFaPosFilter(pos)} style={{
              padding:"3px 9px",borderRadius:"4px",whiteSpace:"nowrap",
              border:faPosFilter===pos?`1px solid ${POS_COLORS[pos]||"#8b5cf6"}`:"1px solid rgba(255,255,255,0.07)",
              background:faPosFilter===pos?`${POS_COLORS[pos]||"#8b5cf6"}18`:"transparent",
              color:faPosFilter===pos?POS_COLORS[pos]||"#c4b5fd":"#4b5563",
              fontSize:"10px",cursor:"pointer",fontFamily:"inherit"
            }}>{pos}</button>
          ))}
        </div>
        {consensus && <ProviderBanner statuses={consensus.providerStatus} />}
        <div style={{ flex:1,overflowY:"auto",padding:"8px 12px" }}>
          {playersLoading ? (
            <div style={{ textAlign:"center",color:"#374151",padding:"40px 0",fontSize:"12px" }}>Loading player pool...</div>
          ) : faPlayers.length===0 ? (
            <div style={{ textAlign:"center",color:"#374151",padding:"40px 0" }}>
              <div style={{ fontSize:"32px",marginBottom:"8px" }}>🔍</div>
              <div style={{ fontSize:"13px" }}>No free agents found</div>
            </div>
          ) : faPlayers.map(({id,p,pos,value,fallback}) => (
            <div key={id} style={{ padding:"9px 10px",borderRadius:"7px",marginBottom:"3px",
              background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.04)",
              display:"flex",justifyContent:"space-between",alignItems:"center",gap:"8px" }}>
              <div style={{ display:"flex",alignItems:"center",gap:"8px",minWidth:0 }}>
                <PosTag pos={pos} small />
                <div style={{ minWidth:0 }}>
                  <div style={{ fontSize:"13px",color:"#e2e8f0",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>
                    {p.first_name} {p.last_name}<InjuryBadge status={p.injury_status} />
                  </div>
                  <div style={{ fontSize:"10px",color:"#4b5563" }}>{p.team||"FA"}{p.age?` · Age ${p.age}`:""}</div>
                </div>
              </div>
              <div style={{ textAlign:"right",flexShrink:0 }}>
                <div style={{ fontSize:"12px",fontWeight:"700",color:"#8b5cf6",display:"flex",alignItems:"center",gap:"3px" }}>
                  {value.toLocaleString()}<FallbackTag show={fallback} />
                </div>
                <div style={{ fontSize:"9px",color:"#374151" }}>{TIER_LABELS[valueTier(value)]}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // ── TRADE CALCULATOR TAB ───────────────────────────────────────────────────
  const TradeCalcTab = () => {
    const POSITIONS_TC = ["ALL","QB","RB","WR","TE","DL","LB","DB","PICK"];
    const ctx = valuationCtx();

    const playerPool = buildPlayerPool(rosters, players, allRosteredIds, getTeamNameById, ctx);
    const pickPool   = buildPickPool(formatCtx, ctx.consensus, tradeMode, CURRENT_ROOKIE_CLASS);
    const fullPool   = [...playerPool, ...pickPool];
    const selected   = new Set([...giveSide, ...getSide]);

    const filtered = fullPool.filter(p => {
      const ms = p.name.toLowerCase().includes(tradeSearch.toLowerCase());
      const mp = tradePosFilter==="ALL" || p.position===tradePosFilter;
      return ms && mp && !selected.has(p.id);
    });

    const getVal = (id: string) => fullPool.find(x => x.id===id)?.value ?? 0;
    const giveTotal = giveSide.reduce((s,id) => s+getVal(id), 0);
    const getTotal  = getSide.reduce((s,id) => s+getVal(id), 0);
    const verdict   = computeVerdict(giveTotal, getTotal);
    const barW      = giveTotal+getTotal > 0 ? Math.round((giveTotal/(giveTotal+getTotal))*100) : 50;

    const SideList = ({ side }: { side:"give"|"get" }) => {
      const isGive=side==="give", list=isGive?giveSide:getSide;
      const total=isGive?giveTotal:getTotal, color=isGive?"#ef4444":"#22c55e";
      const remove=(id:string)=>isGive?setGiveSide(p=>p.filter(x=>x!==id)):setGetSide(p=>p.filter(x=>x!==id));
      return (
        <div style={{ marginBottom:"12px" }}>
          <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"6px" }}>
            <div style={{ fontSize:"10px",color,letterSpacing:"0.1em",fontWeight:"700" }}>{isGive?"📤 YOU GIVE":"📥 YOU GET"}</div>
            <div style={{ fontSize:"15px",fontWeight:"800",color }}>{total.toLocaleString()}</div>
          </div>
          {list.length===0 ? (
            <div style={{ padding:"14px",borderRadius:"8px",textAlign:"center",
              border:`1px dashed ${color}30`,color:"#374151",fontSize:"12px" }}>
              {isGive?"Add players giving up":"Add players receiving"}
            </div>
          ) : list.map(id => {
            const p=fullPool.find(x=>x.id===id); if(!p) return null;
            return (
              <div key={id} style={{ padding:"8px 10px",borderRadius:"7px",
                background:`${color}08`,border:`1px solid ${color}20`,
                marginBottom:"4px",display:"flex",justifyContent:"space-between",alignItems:"center",gap:"8px" }}>
                <div style={{ display:"flex",alignItems:"center",gap:"7px",minWidth:0 }}>
                  <PosTag pos={p.position} small />
                  <div style={{ minWidth:0 }}>
                    <div style={{ fontSize:"12px",color:"#e2e8f0",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{p.name}</div>
                    <div style={{ fontSize:"9px",color:"#4b5563" }}>{p.owner}</div>
                  </div>
                </div>
                <div style={{ display:"flex",alignItems:"center",gap:"8px",flexShrink:0 }}>
                  <span style={{ fontSize:"12px",fontWeight:"700",color,display:"flex",alignItems:"center",gap:"2px" }}>
                    {p.value.toLocaleString()}<FallbackTag show={p.formulaFallback} />
                  </span>
                  <button onClick={()=>remove(id)} style={{ background:`${color}20`,border:`1px solid ${color}35`,
                    color,borderRadius:"4px",width:"22px",height:"22px",cursor:"pointer",
                    fontSize:"14px",fontFamily:"inherit",display:"flex",alignItems:"center",justifyContent:"center" }}>×</button>
                </div>
              </div>
            );
          })}
        </div>
      );
    };

    return (
      <div style={{ flex:1,display:"flex",flexDirection:"column",overflow:"hidden" }}>
        <div style={{ display:"flex",borderBottom:"1px solid rgba(255,255,255,0.06)",flexShrink:0 }}>
          {(["search","build","result"] as const).map(t => (
            <button key={t} onClick={()=>setTradeSubTab(t)} style={{
              flex:1,padding:"10px 4px",
              background:tradeSubTab===t?"rgba(255,255,255,0.03)":"transparent",
              border:"none",borderBottom:tradeSubTab===t?"2px solid #8b5cf6":"2px solid transparent",
              color:tradeSubTab===t?"#c4b5fd":"#4b5563",
              fontSize:"11px",cursor:"pointer",fontFamily:"inherit",letterSpacing:"0.06em",textTransform:"uppercase"
            }}>{t==="search"?"🔍 Search":t==="build"?"⚖️ Build":"📊 Result"}</button>
          ))}
        </div>

        {tradeSubTab==="search" && (
          <div style={{ flex:1,display:"flex",flexDirection:"column",overflow:"hidden" }}>
            <div style={{ display:"flex",flexShrink:0,borderBottom:"1px solid rgba(255,255,255,0.05)" }}>
              {(["give","get"] as const).map(side => (
                <button key={side} onClick={()=>setAddingTo(side)} style={{
                  flex:1,padding:"9px",
                  background:addingTo===side?side==="give"?"rgba(239,68,68,0.1)":"rgba(34,197,94,0.1)":"transparent",
                  border:"none",
                  borderBottom:addingTo===side?`2px solid ${side==="give"?"#ef4444":"#22c55e"}`:"2px solid transparent",
                  color:addingTo===side?side==="give"?"#fca5a5":"#86efac":"#4b5563",
                  fontSize:"10px",cursor:"pointer",fontFamily:"inherit",letterSpacing:"0.08em",textTransform:"uppercase"
                }}>{side==="give"?"📤 Adding to GIVE":"📥 Adding to GET"}</button>
              ))}
            </div>
            <div style={{ padding:"8px 12px",flexShrink:0 }}>
              <input value={tradeSearch} onChange={e=>setTradeSearch(e.target.value)}
                placeholder="Search players & picks..."
                style={{ width:"100%",padding:"8px 12px",background:"rgba(255,255,255,0.06)",
                  border:"1px solid rgba(255,255,255,0.1)",borderRadius:"7px",color:"#e2e8f0",
                  fontSize:"14px",fontFamily:"inherit",boxSizing:"border-box",outline:"none" }} />
            </div>
            <div style={{ padding:"0 12px 6px",display:"flex",gap:"5px",overflowX:"auto",flexShrink:0 }}>
              {POSITIONS_TC.map(pos => (
                <button key={pos} onClick={()=>setTradePosFilter(pos)} style={{
                  padding:"3px 9px",borderRadius:"4px",whiteSpace:"nowrap",
                  border:tradePosFilter===pos?`1px solid ${POS_COLORS[pos]||"#8b5cf6"}`:"1px solid rgba(255,255,255,0.07)",
                  background:tradePosFilter===pos?`${POS_COLORS[pos]||"#8b5cf6"}18`:"transparent",
                  color:tradePosFilter===pos?POS_COLORS[pos]||"#c4b5fd":"#4b5563",
                  fontSize:"10px",cursor:"pointer",fontFamily:"inherit"
                }}>{pos}</button>
              ))}
            </div>
            <div style={{ flex:1,overflowY:"auto",padding:"0 12px 12px" }}>
              {playersLoading && !fullPool.length && <div style={{ textAlign:"center",color:"#374151",padding:"20px 0",fontSize:"11px" }}>Loading player pool...</div>}
              {filtered.slice(0,80).map(player => (
                <div key={player.id} onClick={()=>{ if(addingTo==="give") setGiveSide(p=>[...p,player.id]); else setGetSide(p=>[...p,player.id]); }}
                  style={{ padding:"8px 10px",borderRadius:"7px",cursor:"pointer",
                    display:"flex",justifyContent:"space-between",alignItems:"center",
                    marginBottom:"3px",background:"rgba(255,255,255,0.02)",
                    border:"1px solid rgba(255,255,255,0.04)",gap:"8px",WebkitTapHighlightColor:"transparent" }}>
                  <div style={{ display:"flex",alignItems:"center",gap:"8px",minWidth:0 }}>
                    <PosTag pos={player.position} small />
                    <div style={{ minWidth:0 }}>
                      <div style={{ fontSize:"12px",color:"#e2e8f0",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{player.name}</div>
                      <div style={{ fontSize:"9px",color:"#4b5563" }}>
                        {!player.isPick?`${player.team}${player.age?` · Age ${player.age}`:""} · `:""}
                        {player.owner}
                      </div>
                    </div>
                  </div>
                  <div style={{ textAlign:"right",flexShrink:0 }}>
                    <div style={{ fontSize:"12px",fontWeight:"700",color:"#8b5cf6",display:"flex",alignItems:"center",gap:"2px" }}>
                      {player.value.toLocaleString()}<FallbackTag show={player.formulaFallback} />
                    </div>
                    <div style={{ fontSize:"9px",color:"#374151" }}>{TIER_LABELS[player.tier]}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tradeSubTab==="build" && (
          <div style={{ flex:1,overflowY:"auto",padding:"12px" }}>
            <div style={{ display:"flex",gap:"6px",marginBottom:"12px",alignItems:"center" }}>
              <span style={{ fontSize:"10px",color:"#4b5563" }}>MODE:</span>
              {(["contender","balanced","rebuilder"] as TradeMode[]).map(m => (
                <button key={m} onClick={()=>setTradeMode(m)} style={{
                  padding:"4px 10px",borderRadius:"5px",
                  border:tradeMode===m?"1px solid #8b5cf6":"1px solid rgba(255,255,255,0.08)",
                  background:tradeMode===m?"rgba(139,92,246,0.2)":"transparent",
                  color:tradeMode===m?"#c4b5fd":"#4b5563",
                  fontSize:"10px",cursor:"pointer",fontFamily:"inherit",textTransform:"uppercase",letterSpacing:"0.06em"
                }}>{m}</button>
              ))}
            </div>
            <SideList side="give" />
            <SideList side="get" />
            <button onClick={()=>{setGiveSide([]);setGetSide([]);}} style={{
              width:"100%",padding:"10px",background:"rgba(255,255,255,0.03)",
              border:"1px solid rgba(255,255,255,0.07)",borderRadius:"7px",
              color:"#4b5563",fontSize:"11px",cursor:"pointer",fontFamily:"inherit"
            }}>CLEAR TRADE</button>
          </div>
        )}

        {tradeSubTab==="result" && (
          <div style={{ flex:1,overflowY:"auto",padding:"12px" }}>
            {giveSide.length===0 && getSide.length===0 ? (
              <div style={{ textAlign:"center",color:"#374151",padding:"40px 0" }}>
                <div style={{ fontSize:"40px",marginBottom:"10px" }}>⚖️</div>
                <div style={{ fontSize:"13px" }}>Build a trade first</div>
              </div>
            ) : <>
              <div style={{ background:`${verdict.colour}12`,border:`1px solid ${verdict.colour}30`,
                borderRadius:"14px",padding:"20px",textAlign:"center",marginBottom:"14px" }}>
                <div style={{ fontSize:"36px",marginBottom:"6px" }}>{verdict.emoji}</div>
                <div style={{ fontSize:"28px",fontWeight:"800",color:verdict.colour }}>{verdict.pct}%</div>
                <div style={{ fontSize:"12px",color:verdict.colour,fontWeight:"700",letterSpacing:"0.1em",marginTop:"4px" }}>{verdict.label}</div>
                <div style={{ fontSize:"10px",color:"#4b5563",marginTop:"2px" }}>value received</div>
              </div>
              <div style={{ marginBottom:"14px" }}>
                <div style={{ height:"8px",background:"rgba(255,255,255,0.05)",borderRadius:"4px",overflow:"hidden",display:"flex" }}>
                  <div style={{ width:`${barW}%`,background:"linear-gradient(90deg,#ef4444,#f97316)",transition:"width 0.4s" }} />
                  <div style={{ width:`${100-barW}%`,background:"linear-gradient(90deg,#16a34a,#22c55e)",transition:"width 0.4s" }} />
                </div>
                <div style={{ display:"flex",justifyContent:"space-between",marginTop:"5px",fontSize:"11px" }}>
                  <span style={{ color:"#ef4444" }}>GIVE: {giveTotal.toLocaleString()}</span>
                  <span style={{ color:"#22c55e" }}>GET: {getTotal.toLocaleString()}</span>
                </div>
              </div>
              <Card style={{ display:"flex",justifyContent:"space-between",alignItems:"center" }}>
                <span style={{ fontSize:"11px",color:"#6b7280",letterSpacing:"0.05em" }}>DIFFERENCE</span>
                <span style={{ fontSize:"16px",fontWeight:"700",color:getTotal>=giveTotal?"#22c55e":"#ef4444" }}>
                  {getTotal>=giveTotal?"+":""}{(getTotal-giveTotal).toLocaleString()}
                </span>
              </Card>
            </>}
          </div>
        )}
      </div>
    );
  };

  // ── DRAFT BOARD TAB ────────────────────────────────────────────────────────
  const DraftBoardTab = () => {
    const DRAFT_POSITIONS = ["ALL","QB","RB","WR","DL","LB","DB","TE","K"];
    const players = rookieBoard ? filterRookieBoard(rookieBoard, draftFilter) : [];

    const saveNote = (id: string, note: string) => {
      const updated = { ...draftNotes, [id]: note };
      setDraftNotes(updated);
      try { localStorage.setItem("draft_notes", JSON.stringify(updated)); } catch {}
    };

    return (
      <div style={{ flex:1,overflowY:"auto" }}>
        <div style={{ padding:"8px 12px",borderBottom:"1px solid rgba(255,255,255,0.05)",
          display:"flex",gap:"5px",overflowX:"auto",flexShrink:0 }}>
          {DRAFT_POSITIONS.map(pos => (
            <button key={pos} onClick={()=>setDraftFilter(pos)} style={{
              padding:"3px 9px",borderRadius:"4px",whiteSpace:"nowrap",
              border:draftFilter===pos?`1px solid ${POS_COLORS[pos]||"#8b5cf6"}`:"1px solid rgba(255,255,255,0.07)",
              background:draftFilter===pos?`${POS_COLORS[pos]||"#8b5cf6"}18`:"transparent",
              color:draftFilter===pos?POS_COLORS[pos]||"#c4b5fd":"#4b5563",
              fontSize:"10px",cursor:"pointer",fontFamily:"inherit"
            }}>{pos}</button>
          ))}
        </div>
        <div style={{ padding:"10px 12px" }}>
          <div style={{ fontSize:"10px",color:"#4b5563",letterSpacing:"0.08em",marginBottom:"4px" }}>
            {CURRENT_ROOKIE_CLASS} DYNASTY ROOKIE RANKINGS
          </div>
          {rookieBoard && !rookieBoard.loaded && (
            <div style={{ padding:"10px 12px",marginBottom:"10px",borderRadius:"7px",
              background:"rgba(245,158,11,0.08)",border:"1px solid rgba(245,158,11,0.2)",
              fontSize:"11px",color:"#f59e0b",lineHeight:"1.6" }}>
              ⚠️ Rookie rankings provider not connected.
              Set <code>DATA_SOURCES.fantasyProsRookies.url</code> and <code>.enabled = true</code> in{" "}
              <code>src/config/dataSources.ts</code> to load rankings.
            </div>
          )}
          {players.length === 0 && rookieBoard?.loaded && (
            <div style={{ textAlign:"center",color:"#374151",padding:"40px 0" }}>
              <div style={{ fontSize:"32px",marginBottom:"8px" }}>📋</div>
              <div style={{ fontSize:"13px" }}>No rookies found for this filter</div>
            </div>
          )}
          {players.map((player, idx) => {
            const noteKey = player.playerId;
            const hasNote = draftNotes[noteKey];
            return (
              <div key={player.playerId} style={{ padding:"10px 12px",borderRadius:"8px",
                background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.05)",
                marginBottom:"5px" }}>
                <div style={{ display:"flex",alignItems:"flex-start",gap:"10px" }}>
                  <div style={{ width:"26px",height:"26px",borderRadius:"50%",flexShrink:0,
                    background:player.tier===1?"rgba(139,92,246,0.2)":player.tier===2?"rgba(59,130,246,0.15)":"rgba(255,255,255,0.05)",
                    display:"flex",alignItems:"center",justifyContent:"center",
                    fontSize:"11px",fontWeight:"700",marginTop:"2px",
                    color:player.tier===1?"#c4b5fd":player.tier===2?"#93c5fd":"#4b5563" }}>
                    {player.consensusRank}
                  </div>
                  <div style={{ flex:1,minWidth:0 }}>
                    <div style={{ display:"flex",alignItems:"center",gap:"6px",marginBottom:"2px" }}>
                      <PosTag pos={player.position} small />
                      <span style={{ fontSize:"13px",color:"#e2e8f0",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{player.name}</span>
                    </div>
                    {player.school && <div style={{ fontSize:"10px",color:"#4b5563" }}>{player.school}{player.classYear ? ` · ${player.classYear}` : ""}</div>}
                    {player.note && <div style={{ fontSize:"10px",color:"#6b7280",marginTop:"2px",fontStyle:"italic" }}>{player.note}</div>}
                    {hasNote && (
                      <div style={{ fontSize:"10px",color:"#f59e0b",marginTop:"4px",padding:"4px 8px",
                        background:"rgba(245,158,11,0.08)",borderRadius:"4px",border:"1px solid rgba(245,158,11,0.15)" }}>
                        📝 {hasNote}
                      </div>
                    )}
                    <input placeholder="Add your note..." defaultValue={hasNote || ""}
                      onBlur={e => { const v=e.target.value.trim(); if(v!==(hasNote||"")) saveNote(noteKey,v); }}
                      style={{ marginTop:"6px",width:"100%",padding:"5px 8px",
                        background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.07)",
                        borderRadius:"5px",color:"#94a3b8",fontSize:"11px",
                        fontFamily:"inherit",outline:"none",boxSizing:"border-box" }} />
                  </div>
                  <div style={{ textAlign:"right",flexShrink:0 }}>
                    <div style={{ fontSize:"10px",color:"#4b5563" }}>T{player.tier}</div>
                    <div style={{ fontSize:"9px",color:"#374151" }}>{player.source}</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // ── NEWS TAB ───────────────────────────────────────────────────────────────
  const NewsTab = () => {
    const [newsFilter, setNewsFilter] = useState("All");
    const sources = ["All", ...NEWS_FEEDS.map(f=>f.name)];
    const filtered = newsFilter==="All" ? news : news.filter(n=>n.source===newsFilter);
    return (
      <div style={{ flex:1,display:"flex",flexDirection:"column",overflow:"hidden" }}>
        <div style={{ padding:"6px 12px",display:"flex",gap:"6px",overflowX:"auto",
          borderBottom:"1px solid rgba(255,255,255,0.05)",flexShrink:0,alignItems:"center" }}>
          {sources.map(s => {
            const feed=NEWS_FEEDS.find(f=>f.name===s); const color=feed?.color||"#6b7280"; const active=newsFilter===s;
            return <button key={s} onClick={()=>setNewsFilter(s)} style={{
              padding:"4px 10px",borderRadius:"5px",whiteSpace:"nowrap",
              border:active?`1px solid ${color}`:"1px solid rgba(255,255,255,0.08)",
              background:active?`${color}20`:"transparent",color:active?color:"#4b5563",
              fontSize:"10px",cursor:"pointer",fontFamily:"inherit"
            }}>{s}</button>;
          })}
          <button onClick={()=>{setNewsLoaded(false);setNews([]);}} style={{
            padding:"4px 10px",borderRadius:"5px",border:"1px solid rgba(255,255,255,0.08)",
            background:"transparent",color:"#4b5563",fontSize:"10px",cursor:"pointer",fontFamily:"inherit"
          }}>↺</button>
        </div>
        <div style={{ flex:1,overflowY:"auto",padding:"10px 12px" }}>
          {newsLoading ? (
            <div style={{ textAlign:"center",color:"#4b5563",padding:"40px 0",fontSize:"12px" }}>Loading news feeds...</div>
          ) : filtered.length===0 ? (
            <div style={{ textAlign:"center",color:"#374151",padding:"40px 0" }}>
              <div style={{ fontSize:"32px",marginBottom:"8px" }}>📰</div>
              <div style={{ fontSize:"13px" }}>No news loaded</div>
            </div>
          ) : filtered.map((item,i) => {
            const feed=NEWS_FEEDS.find(f=>f.name===item.source);
            return (
              <a key={i} href={item.link} target="_blank" rel="noopener noreferrer"
                style={{ display:"block",textDecoration:"none",padding:"11px 12px",
                  borderRadius:"9px",background:"rgba(255,255,255,0.02)",
                  border:`1px solid ${feed?.color||"#6b7280"}18`,marginBottom:"7px" }}>
                <div style={{ display:"flex",justifyContent:"space-between",marginBottom:"5px",gap:"8px" }}>
                  <span style={{ fontSize:"9px",padding:"2px 6px",borderRadius:"3px",
                    background:`${feed?.color||"#6b7280"}20`,color:feed?.color||"#6b7280",
                    letterSpacing:"0.05em",fontWeight:"700",flexShrink:0 }}>{item.source}</span>
                  <span style={{ fontSize:"9px",color:"#4b5563" }}>{item.pubDate?new Date(item.pubDate).toLocaleDateString():""}</span>
                </div>
                <div style={{ fontSize:"13px",color:"#e2e8f0",lineHeight:"1.4",marginBottom:"4px" }}>{item.title}</div>
                {item.description && <div style={{ fontSize:"11px",color:"#6b7280",lineHeight:"1.4" }}>{item.description.slice(0,150)}…</div>}
              </a>
            );
          })}
        </div>
      </div>
    );
  };

  // ── TRANSACTIONS TAB ───────────────────────────────────────────────────────
  const TransactionsTab = () => {
    const typeIcon:Record<string,string>={trade:"🔄",waiver:"📋",free_agent:"✍️"};
    const typeColor:Record<string,string>={trade:"#f59e0b",waiver:"#8b5cf6",free_agent:"#22c55e"};
    return (
      <div style={{ flex:1,overflowY:"auto",padding:"12px" }}>
        {transactions.length===0 ? (
          <div style={{ textAlign:"center",color:"#374151",padding:"40px 0" }}>
            <div style={{ fontSize:"32px",marginBottom:"8px" }}>📭</div>
            <div style={{ fontSize:"13px" }}>No transactions yet</div>
          </div>
        ) : transactions.slice(0,60).map((tx,i) => {
          const color=typeColor[tx.type]||"#6b7280", icon=typeIcon[tx.type]||"📝";
          const date=tx.created?new Date(tx.created).toLocaleDateString():"";
          const adds=Object.keys(tx.adds||{}), drops=Object.keys(tx.drops||{});
          return (
            <div key={i} style={{ padding:"10px 12px",borderRadius:"8px",
              background:"rgba(255,255,255,0.02)",border:`1px solid ${color}18`,marginBottom:"5px" }}>
              <div style={{ display:"flex",justifyContent:"space-between",marginBottom:"5px" }}>
                <div style={{ display:"flex",alignItems:"center",gap:"5px" }}>
                  <span>{icon}</span>
                  <span style={{ fontSize:"11px",color,textTransform:"uppercase",letterSpacing:"0.06em",fontWeight:"700" }}>{tx.type?.replace("_"," ")}</span>
                </div>
                <span style={{ fontSize:"10px",color:"#4b5563" }}>{date}</span>
              </div>
              {adds.length>0 && <div style={{ marginBottom:"2px" }}><span style={{ fontSize:"10px",color:"#22c55e" }}>+ </span><span style={{ fontSize:"11px",color:"#94a3b8" }}>{adds.map(id=>getPlayerName(id)).join(", ")}</span></div>}
              {drops.length>0 && <div><span style={{ fontSize:"10px",color:"#ef4444" }}>- </span><span style={{ fontSize:"11px",color:"#94a3b8" }}>{drops.map(id=>getPlayerName(id)).join(", ")}</span></div>}
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div style={{ height:"100dvh",background:"#08080f",color:"#e2e8f0",
      fontFamily:"'DM Mono','Courier New',monospace",
      display:"flex",flexDirection:"column",maxWidth:"600px",margin:"0 auto",overflow:"hidden" }}>

      {/* Header */}
      <div style={{ background:"linear-gradient(135deg,#0f0f1a,#150a2a)",
        borderBottom:"1px solid rgba(139,92,246,0.25)",padding:"11px 14px",flexShrink:0 }}>
        <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between" }}>
          <div style={{ display:"flex",alignItems:"center",gap:"8px" }}>
            <div style={{ width:"26px",height:"26px",borderRadius:"6px",
              background:"linear-gradient(135deg,#8b5cf6,#3b82f6)",
              display:"flex",alignItems:"center",justifyContent:"center",fontSize:"13px" }}>👑</div>
            <div>
              <div style={{ fontSize:"13px",fontWeight:"700",color:"#fff",letterSpacing:"0.04em" }}>{leagueName}</div>
              <div style={{ fontSize:"9px",color:"#4b5563",letterSpacing:"0.08em" }}>
                {leagueSeason} · {manualSettings ? manualSettings.platform : "Sleeper"} · {activeLabel}
              </div>
            </div>
          </div>
          <button onClick={onDisconnect} style={{ padding:"4px 8px",borderRadius:"5px",fontSize:"9px",
            background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",
            color:"#4b5563",cursor:"pointer",fontFamily:"inherit",letterSpacing:"0.04em" }}>← Leagues</button>
        </div>
      </div>

      {/* More menu overlay */}
      {showMore && (
        <>
          <div onClick={()=>setShowMore(false)} style={{ position:"fixed",inset:0,zIndex:99 }} />
          <div style={{ position:"fixed",bottom:"50px",left:"50%",transform:"translateX(-50%)",
            width:"min(600px,100vw)",background:"#0f0f1a",
            borderTop:"1px solid rgba(139,92,246,0.2)",zIndex:100,
            display:"grid",gridTemplateColumns:"1fr 1fr" }}>
            {MORE_TABS.map(item => (
              <button key={item.id} onClick={()=>{setTab(item.id);setShowMore(false);}} style={{
                padding:"14px",background:"transparent",
                border:"none",borderBottom:"1px solid rgba(255,255,255,0.05)",
                color:tab===item.id?"#c4b5fd":"#6b7280",
                fontSize:"11px",cursor:"pointer",fontFamily:"inherit",
                display:"flex",alignItems:"center",gap:"8px",letterSpacing:"0.04em"
              }}><span style={{ fontSize:"18px" }}>{item.icon}</span>{item.label}</button>
            ))}
          </div>
        </>
      )}

      {/* Content */}
      <div style={{ flex:1,display:"flex",flexDirection:"column",overflow:"hidden" }}>
        {tab==="roster"    && <RosterTabWrapped />}
        {tab==="standings" && <StandingsTabWrapped />}
        {tab==="trade"     && <TradeCalcTab />}
        {tab==="fa"        && <FreeAgencyTab />}
        {tab==="news"      && <NewsTab />}
        {tab==="draft"     && <DraftBoardTab />}
        {tab==="matchups"  && <MatchupsTab />}
        {tab==="txns"      && <TransactionsTab />}
      </div>

      {/* Bottom nav */}
      <div style={{ display:"flex",borderTop:"1px solid rgba(255,255,255,0.07)",
        background:"#0a0a14",flexShrink:0,paddingBottom:"env(safe-area-inset-bottom,0px)" }}>
        {NAV.map(item => {
          const isMore=item.id==="more", active=isMore?showMore:tab===item.id;
          return (
            <button key={item.id} onClick={()=>{if(isMore){setShowMore(s=>!s);}else{setTab(item.id);setShowMore(false);}}} style={{
              flex:1,padding:"10px 4px 8px",
              background:active?"rgba(139,92,246,0.1)":"transparent",
              border:"none",borderTop:active?"2px solid #8b5cf6":"2px solid transparent",
              color:active?"#c4b5fd":"#4b5563",
              fontSize:"10px",cursor:"pointer",fontFamily:"inherit",
              display:"flex",flexDirection:"column",alignItems:"center",gap:"2px",letterSpacing:"0.04em"
            }}>
              <span style={{ fontSize:"16px",lineHeight:"1" }}>{item.icon}</span>
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

    </div>
  );
}

// ── Root ───────────────────────────────────────────────────────────────────────

export default function App() {
  const [leagueId,       setLeagueId]       = useState<string | null>(null);
  const [leagueData,     setLeagueData]     = useState<SleeperLeague | null>(null);
  const [manualSettings, setManualSettings] = useState<ManualLeagueSettings | null>(null);

  const handleSleeperLoad = (id: string, data: SleeperLeague) => {
    setLeagueId(id);
    setLeagueData(data);
    setManualSettings(null);
  };

  const handleManualLoad = (settings: ManualLeagueSettings) => {
    setLeagueId(null);
    setLeagueData(null);
    setManualSettings(settings);
  };

  const handleDisconnect = () => {
    setLeagueId(null);
    setLeagueData(null);
    setManualSettings(null);
  };

  if (!leagueId && !manualSettings) {
    return <LeagueEntryScreen onSleeperLoad={handleSleeperLoad} onManualLoad={handleManualLoad} />;
  }

  return (
    <LeagueApp
      leagueId={leagueId}
      initialLeague={leagueData}
      manualSettings={manualSettings}
      onDisconnect={handleDisconnect}
    />
  );
}
