/** Position display colours */
export const POS_COLORS: Record<string, string> = {
  QB:   "#ef4444",
  RB:   "#22c55e",
  WR:   "#3b82f6",
  TE:   "#f59e0b",
  DL:   "#8b5cf6",
  LB:   "#ec4899",
  DB:   "#06b6d4",
  K:    "#f97316",
  DEF:  "#64748b",
  PICK: "#94a3b8",
  FLEX: "#a78bfa",
  IDP:  "#818cf8",
};

/** Offensive skill positions */
export const OFFENSE_POSITIONS = ["QB", "RB", "WR", "TE"] as const;

/** Defensive positions (IDP) */
export const IDP_POSITIONS = ["DL", "LB", "DB"] as const;

/** All value-relevant positions */
export const SKILL_POSITIONS = [...OFFENSE_POSITIONS, ...IDP_POSITIONS, "K"] as const;

/** Pick virtual position */
export const PICK_POSITION = "PICK";

export function isIdpPosition(pos: string): boolean {
  return (IDP_POSITIONS as readonly string[]).includes(pos);
}

export function isOffensePosition(pos: string): boolean {
  return (OFFENSE_POSITIONS as readonly string[]).includes(pos);
}

export function positionGroup(pos: string): "offense" | "idp" | "special" | "pick" | "unknown" {
  if (isOffensePosition(pos)) return "offense";
  if (isIdpPosition(pos)) return "idp";
  if (pos === "K" || pos === "DEF") return "special";
  if (pos === "PICK") return "pick";
  return "unknown";
}

/** Human-readable tier labels */
export const TIER_LABELS: Record<number, string> = {
  1: "Elite",
  2: "Starter",
  3: "Depth",
  4: "Fringe",
};

export function valueTier(value: number): number {
  if (value >= 8000) return 1;
  if (value >= 5000) return 2;
  if (value >= 2500) return 3;
  return 4;
}

/** Relative base importance of each position in a standard dynasty league */
export const POSITION_BASE_IMPORTANCE: Record<string, number> = {
  QB:  1.00,
  RB:  0.94,
  WR:  0.94,
  TE:  0.85,
  DL:  0.84,
  LB:  0.82,
  DB:  0.76,
  K:   0.30,
  DEF: 0.26,
};
