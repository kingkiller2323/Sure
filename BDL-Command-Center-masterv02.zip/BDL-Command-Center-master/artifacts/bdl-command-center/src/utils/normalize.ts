/**
 * normalize.ts
 *
 * Shared normalization helpers used across all data providers so that
 * differently-shaped external sources map to the same internal key.
 */

/** Normalise a player name to a stable lookup key */
export function normalizePlayerName(name: string): string {
  return name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")   // strip diacritics
    .replace(/[^a-z0-9 ]/g, "")        // strip punctuation
    .replace(/\s+/g, " ")
    .trim();
}

/** Build a dedup key that combines normalised name + primary position */
export function playerDedupeKey(name: string, position: string): string {
  return `${normalizePlayerName(name)}|${position.toUpperCase()}`;
}

/** Normalise a position string to a standard value */
export function normalizePosition(raw: string): string {
  const map: Record<string, string> = {
    qb: "QB", rb: "RB", wr: "WR", te: "TE",
    dl: "DL", lb: "LB", db: "DB", k: "K", def: "DEF",
    de: "DL", dt: "DL", edge: "DL",
    s:  "DB", cb: "DB", fs: "DB", ss: "DB",
    fb: "RB",
  };
  return map[raw.toLowerCase()] ?? raw.toUpperCase();
}

/** Strip HTML tags from a string */
export function stripHtml(html: string): string {
  return html.replace(/<[^>]+>/g, "");
}

/** Build a standard pick key, e.g. "2026-1-early" */
export function pickKey(year: number, round: number, bucket: "early" | "mid" | "late"): string {
  return `${year}-${round}-${bucket}`;
}

/** Parse a pick display name like "2026 1.03" into structured parts */
export function parsePickLabel(label: string): { year: number; round: number; slot?: number } | null {
  const m = label.match(/^(\d{4})\s+(\d+)(?:\.(\d+))?/);
  if (!m) return null;
  return { year: Number(m[1]), round: Number(m[2]), slot: m[3] ? Number(m[3]) : undefined };
}
