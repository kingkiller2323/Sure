/**
 * NormalizedLeagueData.ts
 *
 * The single unified format all platform adapters must produce.
 * The analytics engine and valuation layer consume ONLY this shape —
 * they never see platform-specific structures.
 */

// ─── Roster / lineup settings ─────────────────────────────────────────────────

export interface RosterSettings {
  /** Number of starters by position key, e.g. { QB:1, RB:2, WR:3, TE:1 } */
  starterCounts:  Partial<Record<string, number>>;
  /** Total bench slots */
  benchSlots:     number;
  /** Taxi squad slots (dynasty) */
  taxiSlots:      number;
  /** Injured reserve slots */
  irSlots:        number;
  /** Flex positions allowed, e.g. ["RB","WR","TE"] */
  flexPositions:  string[];
  /** Superflex positions allowed, e.g. ["QB","RB","WR","TE"] */
  superflexPositions: string[];
}

// ─── Scoring settings ─────────────────────────────────────────────────────────

export interface ScoringSettings {
  /** True if the league uses superflex or 2-QB format */
  superflex:      boolean;
  /** True if TE receives a reception bonus (rec_te > 0.5) */
  tePremium:      boolean;
  /** True if IDP scoring is enabled */
  idpEnabled:     boolean;
  /** PPR amount (0 = standard, 0.5 = half, 1 = full) */
  ppr:            number;
  /** All raw scoring multipliers keyed by stat name */
  rawScoring:     Record<string, number>;
  /**
   * IDP scoring sub-settings.
   * Only populated when idpEnabled = true.
   */
  idpScoring?: {
    tacklePoints:   number;
    sackPoints:     number;
    intPoints:      number;
    passDefPoints:  number;
    tdPoints:       number;
  };
}

// ─── League settings ───────────────────────────────────────────────────────────

export interface LeagueSettings {
  leagueId:     string;
  platformId:   string;   // "sleeper" | "yahoo" | "espn" | "manual"
  name:         string;
  season:       string;
  leagueSize:   number;
  playoffTeams: number;
  type:         "dynasty" | "keeper" | "redraft";
  rosterSettings:  RosterSettings;
  scoringSettings: ScoringSettings;
}

// ─── Player record ─────────────────────────────────────────────────────────────

export interface NormalizedPlayer {
  /** Canonical ID — "sleeper:<id>" or "<platform>:<id>" */
  playerId:     string;
  name:         string;
  firstName:    string;
  lastName:     string;
  position:     string;
  team:         string;
  age:          number;
  injuryStatus?: string;
  status?:      string;
}

// ─── Roster / team record ──────────────────────────────────────────────────────

export interface NormalizedRoster {
  rosterId:    number;
  teamName:    string;
  ownerName:   string;
  ownerId:     string;
  wins:        number;
  losses:      number;
  ties:        number;
  pointsFor:   number;
  /** All player IDs on this roster (starters + bench) */
  playerIds:   string[];
  /** Player IDs currently starting */
  starterIds:  string[];
  /** Taxi squad player IDs */
  taxiIds:     string[];
  /** IR player IDs */
  irIds:       string[];
}

// ─── Pick record ───────────────────────────────────────────────────────────────

export interface NormalizedDraftPick {
  pickKey:     string;   // e.g. "2027_1_mid"
  year:        number;
  round:       number;
  bucket:      "early" | "mid" | "late" | "fixed";
  ownerRosterId:    number;
  originalRosterId: number;
  season?:     string;
}

// ─── Root object ───────────────────────────────────────────────────────────────

export interface NormalizedLeagueData {
  leagueSettings: LeagueSettings;
  rosterSettings: RosterSettings;
  scoringSettings: ScoringSettings;
  teams:           NormalizedRoster[];
  rosters:         NormalizedRoster[];
  draftPicks:      NormalizedDraftPick[];
  /** All players keyed by canonical playerId */
  players:         Record<string, NormalizedPlayer>;
  /** ISO timestamp of when this data was fetched */
  fetchedAt:       string;
}
