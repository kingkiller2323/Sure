/**
 * LeagueEntryScreen.tsx — League entry/selection screen
 * Extracted from App.tsx (no behavior changes)
 */

import React, { useState } from "react";
import { Card, SectionHeader } from "../../components/ui/shared";
import { fetchLeague, type SleeperLeague } from "../../services/platforms/sleeper";
import { type ManualLeagueSettings } from "../../services/manualLeague";
import ManualSetupScreen from "../manual-league/ManualSetupScreen";

const APP_VERSION = "2.0.0";

export interface LeagueEntryScreenProps {
  onSleeperLoad: (id: string, data: SleeperLeague) => void;
  onManualLoad:  (settings: ManualLeagueSettings) => void;
}

export default function LeagueEntryScreen({
  onSleeperLoad,
  onManualLoad,
}: LeagueEntryScreenProps) {
  const [input, setInput]   = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr]       = useState("");
  const [mode, setMode]     = useState<"sleeper"|"manual">("sleeper");
  const [recentLeagues, setRecentLeagues] = useState<{id:string;name:string;platform:string}[]>(() => {
    try { return JSON.parse(localStorage.getItem("recent_leagues") || "[]"); } catch { return []; }
  });

  const trySleeperLoad = async (id: string) => {
    const leagueId = id.trim().replace(/\s/g,"");
    if (!leagueId) { setErr("Please enter a league ID"); return; }
    setLoading(true); setErr("");
    try {
      const league = await fetchLeague(leagueId);
      if (!league?.league_id) throw new Error("League not found");
      const updated = [{ id: leagueId, name: league.name, platform:"Sleeper" },
        ...recentLeagues.filter(l => l.id !== leagueId)].slice(0, 5);
      try { localStorage.setItem("recent_leagues", JSON.stringify(updated)); } catch {}
      setRecentLeagues(updated);
      onSleeperLoad(leagueId, league);
    } catch {
      setErr("Couldn't find that league. Check the ID and try again.");
    }
    setLoading(false);
  };

  return (
    <div style={{ minHeight:"100vh", background:"#08080f", display:"flex",
      flexDirection:"column", fontFamily:"'DM Mono','Courier New',monospace" }}>

      {/* Header */}
      <div style={{ background:"linear-gradient(135deg,#0f0f1a,#150a2a)",
        borderBottom:"1px solid rgba(139,92,246,0.25)", padding:"24px 20px 20px" }}>
        <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"8px" }}>
          <div style={{ width:"36px", height:"36px", borderRadius:"9px",
            background:"linear-gradient(135deg,#8b5cf6,#3b82f6)",
            display:"flex", alignItems:"center", justifyContent:"center", fontSize:"18px" }}>👑</div>
          <div>
            <div style={{ fontSize:"18px", fontWeight:"700", color:"#fff", letterSpacing:"0.05em" }}>Dynasty Command</div>
            <div style={{ fontSize:"10px", color:"#4b5563", letterSpacing:"0.1em" }}>THE FANTASY FOOTBALL COMMAND CENTER</div>
          </div>
        </div>
        <div style={{ fontSize:"12px", color:"#6b7280", lineHeight:"1.6", marginTop:"8px" }}>
          Connect any dynasty league — Sleeper import or manual setup for any platform.
        </div>
      </div>

      {/* Mode tabs */}
      <div style={{ display:"flex", borderBottom:"1px solid rgba(255,255,255,0.07)", background:"#0a0a14" }}>
        {([["sleeper","💤 Sleeper Import"],["manual","✏️ Manual Setup"]] as const).map(([m, label]) => (
          <button key={m} onClick={() => setMode(m)} style={{
            flex:1, padding:"12px 8px",
            background: mode===m ? "rgba(139,92,246,0.08)" : "transparent",
            border:"none", borderBottom: mode===m ? "2px solid #8b5cf6" : "2px solid transparent",
            color: mode===m ? "#c4b5fd" : "#4b5563",
            fontSize:"11px", cursor:"pointer", fontFamily:"inherit", letterSpacing:"0.06em"
          }}>{label}</button>
        ))}
      </div>

      {mode === "manual" ? (
        <ManualSetupScreen onLoad={onManualLoad} />
      ) : (
        <div style={{ flex:1, overflowY:"auto", padding:"20px" }}>
          <Card style={{ marginBottom:"16px", border:"1px solid rgba(139,92,246,0.25)" }}>
            <div style={{ display:"flex", alignItems:"center", gap:"8px", marginBottom:"12px" }}>
              <div style={{ width:"28px", height:"28px", borderRadius:"6px",
                background:"rgba(139,92,246,0.15)", display:"flex",
                alignItems:"center", justifyContent:"center", fontSize:"14px" }}>💤</div>
              <div>
                <div style={{ fontSize:"13px", color:"#fff", fontWeight:"600" }}>Sleeper</div>
                <div style={{ fontSize:"10px", color:"#4b5563" }}>Paste your league ID below</div>
              </div>
            </div>
            <input value={input} onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && trySleeperLoad(input)}
              placeholder="e.g. 1313709679045541888"
              style={{ width:"100%", padding:"10px 12px",
                background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)",
                borderRadius:"8px", color:"#e2e8f0", fontSize:"14px",
                fontFamily:"inherit", boxSizing:"border-box", outline:"none", marginBottom:"8px" }} />
            <div style={{ fontSize:"10px", color:"#4b5563", marginBottom:"12px", lineHeight:"1.6" }}>
              📍 Find your league ID: Sleeper app → Your league → Settings → scroll to bottom
            </div>
            {err && <div style={{ fontSize:"11px", color:"#ef4444", marginBottom:"10px",
              padding:"8px 10px", background:"rgba(239,68,68,0.08)",
              borderRadius:"6px", border:"1px solid rgba(239,68,68,0.2)" }}>{err}</div>}
            <button onClick={() => trySleeperLoad(input)} disabled={loading} style={{
              width:"100%", padding:"12px",
              background: loading ? "rgba(139,92,246,0.1)" : "linear-gradient(135deg,#8b5cf6,#6366f1)",
              border:"none", borderRadius:"8px", color: loading ? "#6b7280" : "#fff",
              fontSize:"13px", cursor: loading ? "default" : "pointer",
              fontFamily:"inherit", fontWeight:"600", letterSpacing:"0.04em"
            }}>{loading ? "Connecting to Sleeper..." : "Connect League →"}</button>
          </Card>

          {recentLeagues.length > 0 && (
            <div style={{ marginBottom:"16px" }}>
              <SectionHeader label="RECENT LEAGUES" />
              {recentLeagues.map(l => (
                <div key={l.id} onClick={() => trySleeperLoad(l.id)} style={{
                  padding:"10px 12px", borderRadius:"8px", cursor:"pointer",
                  background:"rgba(255,255,255,0.02)", border:"1px solid rgba(255,255,255,0.06)",
                  marginBottom:"4px", display:"flex", justifyContent:"space-between", alignItems:"center"
                }}>
                  <div>
                    <div style={{ fontSize:"12px", color:"#e2e8f0" }}>{l.name}</div>
                    <div style={{ fontSize:"10px", color:"#4b5563" }}>{l.platform} · {l.id}</div>
                  </div>
                  <span style={{ color:"#8b5cf6", fontSize:"16px" }}>→</span>
                </div>
              ))}
            </div>
          )}

          <Card>
            <SectionHeader label="MORE PLATFORMS COMING SOON" color="#4b5563" />
            {[
              { name:"ESPN Fantasy",  icon:"🏈", status:"Q2 2026" },
              { name:"Yahoo Fantasy", icon:"🟣", status:"Q2 2026" },
              { name:"NFL.com",       icon:"🏟️", status:"Q3 2026" },
              { name:"CBS Sports",    icon:"📺", status:"Q3 2026" },
              { name:"Fantrax",       icon:"⚡", status:"Q4 2026" },
              { name:"MFL",           icon:"🔢", status:"Q4 2026" },
            ].map(p => (
              <div key={p.name} style={{ display:"flex", justifyContent:"space-between",
                alignItems:"center", padding:"7px 0", borderBottom:"1px solid rgba(255,255,255,0.04)" }}>
                <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
                  <span>{p.icon}</span>
                  <span style={{ fontSize:"12px", color:"#6b7280" }}>{p.name}</span>
                </div>
                <span style={{ fontSize:"10px", color:"#374151", padding:"2px 6px",
                  background:"rgba(255,255,255,0.04)", borderRadius:"4px" }}>{p.status}</span>
              </div>
            ))}
          </Card>
          <div style={{ textAlign:"center", marginTop:"20px", fontSize:"10px", color:"#1f2937" }}>
            Dynasty Command v{APP_VERSION} · Built for serious managers
          </div>
        </div>
      )}
    </div>
  );
}
