/**
 * RosterTab.tsx — Team roster display tab
 * Extracted from App.tsx (no behavior changes)
 */

import React from "react";
import type { SleeperRoster, SleeperUser, SleeperPlayer } from "../../services/platforms/sleeper";
import type { ConsensusData } from "../../services/consensus";
import { sleeperTeamName } from "../../services/platforms/sleeper";
import { PosTag, InjuryBadge, Card, SectionHeader, ProviderBanner, FallbackTag } from "../../components/ui/shared";

export interface RosterTabProps {
  rosters:           SleeperRoster[];
  users:             SleeperUser[];
  selectedTeam:      number | null;
  myRosterId:        number | null;
  consensus:         ConsensusData | null;
  playersLoading:    boolean;
  setSelectedTeam:   (id: number) => void;
  handleSetMyRosterId: (id: number) => void;
  getPlayer:         (id: string) => SleeperPlayer | undefined;
  getPos:            (id: string) => string;
  getPlayerName:     (id: string) => string;
  getPlayerValue:    (id: string) => { value: number; fallback: boolean };
}

export default function RosterTab({
  rosters,
  users,
  selectedTeam,
  myRosterId,
  consensus,
  playersLoading,
  setSelectedTeam,
  handleSetMyRosterId,
  getPlayer,
  getPos,
  getPlayerName,
  getPlayerValue,
}: RosterTabProps) {
  const roster = rosters.find(r => r.roster_id === selectedTeam);
  if (!roster) {
    return (
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: "#374151" }}>
        Select a team above to view roster
      </div>
    );
  }

  const user       = users.find(u => u.user_id === roster.owner_id);
  const teamName   = sleeperTeamName(roster, users);
  const starterIds = (roster.starters||[]).filter((id: string) => id && id !== "0");
  const taxiIds    = roster.taxi ?? [];
  const irIds      = roster.reserve ?? [];
  const benchIds   = (roster.players||[]).filter((id: string) =>
    !starterIds.includes(id) && !taxiIds.includes(id) && !irIds.includes(id)
  );
  const wins = roster.settings?.wins  ?? 0;
  const losses = roster.settings?.losses ?? 0;
  const pts  = ((roster.settings?.fpts??0)+(roster.settings?.fpts_decimal??0)/100).toFixed(1);

  const Row = ({ id, highlight=false }: { id:string; highlight?:boolean }) => {
    const p   = getPlayer(id);
    const pos = getPos(id);
    const { value, fallback } = getPlayerValue(id);
    return (
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between",
        padding:"8px 10px", borderRadius:"7px", marginBottom:"3px",
        background: highlight?"rgba(255,255,255,0.04)":"rgba(255,255,255,0.015)",
        border:`1px solid ${highlight?"rgba(255,255,255,0.07)":"rgba(255,255,255,0.025)"}`,
        gap:"8px" }}>
        <div style={{ display:"flex", alignItems:"center", gap:"8px", minWidth:0 }}>
          <PosTag pos={pos} small />
          <div style={{ minWidth:0 }}>
            <div style={{ fontSize:"13px", color:highlight?"#f1f5f9":"#94a3b8",
              overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
              {getPlayerName(id)}<InjuryBadge status={p?.injury_status} />
            </div>
            <div style={{ fontSize:"10px", color:"#4b5563" }}>
              {p?.team||"FA"}{p?.age ? ` · Age ${p.age}` : ""}
            </div>
          </div>
        </div>
        <div style={{ fontSize:"11px", color:"#4b5563", flexShrink:0, display:"flex", alignItems:"center" }}>
          {playersLoading ? "…" : value.toLocaleString()}
          <FallbackTag show={!playersLoading && fallback} />
        </div>
      </div>
    );
  };

  return (
    <div style={{ flex:1, overflowY:"auto" }}>
      <div style={{ padding:"8px 10px", borderBottom:"1px solid rgba(255,255,255,0.05)",
        display:"flex", gap:"5px", overflowX:"auto", flexShrink:0 }}>
        {rosters.map(r => {
          const u = users.find(u => u.user_id === r.owner_id);
          const nm = u?.metadata?.team_name || u?.display_name || `T${r.roster_id}`;
          const active = r.roster_id === selectedTeam;
          const isMe   = r.roster_id === myRosterId;
          return (
            <button key={r.roster_id} onClick={() => setSelectedTeam(r.roster_id)} style={{
              padding:"5px 10px", borderRadius:"6px", whiteSpace:"nowrap",
              border: active?"1px solid #8b5cf6":"1px solid rgba(255,255,255,0.07)",
              background: active?"rgba(139,92,246,0.2)":"rgba(255,255,255,0.02)",
              color: active?"#c4b5fd":isMe?"#f59e0b":"#6b7280",
              fontSize:"10px", cursor:"pointer", fontFamily:"inherit"
            }}>{isMe?"👑 ":""}{nm.length>13?nm.slice(0,13)+"…":nm}</button>
          );
        })}
      </div>
      {consensus && <ProviderBanner statuses={consensus.providerStatus} />}
      <div style={{ padding:"12px" }}>
        <Card style={{ marginBottom:"12px", background:"linear-gradient(135deg,rgba(139,92,246,0.08),rgba(59,130,246,0.04))", border:"1px solid rgba(139,92,246,0.2)" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
            <div>
              <div style={{ fontSize:"16px", fontWeight:"700", color:"#fff" }}>{teamName}</div>
              <div style={{ fontSize:"11px", color:"#6b7280", marginTop:"2px" }}>{user?.display_name} · Sleeper</div>
            </div>
            <div style={{ textAlign:"right" }}>
              <div style={{ fontSize:"20px", fontWeight:"800", color:"#22c55e" }}>{wins}-{losses}</div>
              <div style={{ fontSize:"10px", color:"#4b5563" }}>{pts} pts</div>
            </div>
          </div>
          {/* Set as my team button */}
          {myRosterId !== roster.roster_id && (
            <button
              onClick={() => handleSetMyRosterId(roster.roster_id)}
              style={{
                marginTop: "10px",
                padding: "6px 10px",
                borderRadius: "6px",
                background: "rgba(245,158,11,0.1)",
                border: "1px solid rgba(245,158,11,0.3)",
                color: "#f59e0b",
                fontSize: "10px",
                cursor: "pointer",
                fontFamily: "inherit",
                fontWeight: "600",
                letterSpacing: "0.04em",
              }}
            >
              👑 Set as my team
            </button>
          )}
        </Card>
        {starterIds.length>0 && <>
          <SectionHeader label="⚡ STARTERS" count={starterIds.length} color="#8b5cf6" />
          {starterIds.map((id: string) => <Row key={id} id={id} highlight />)}
        </>}
        {benchIds.length>0 && <div style={{ marginTop:"12px" }}>
          <SectionHeader label="📋 BENCH" count={benchIds.length} />
          {benchIds.map((id: string) => <Row key={id} id={id} />)}
        </div>}
        {taxiIds.length>0 && <div style={{ marginTop:"12px" }}>
          <SectionHeader label="🚕 TAXI SQUAD" count={`${taxiIds.length}/5`} color="#f59e0b" />
          {taxiIds.map((id: string) => <Row key={id} id={id} />)}
        </div>}
        {irIds.length>0 && <div style={{ marginTop:"12px" }}>
          <SectionHeader label="🏥 INJURED RESERVE" count={irIds.length} color="#ef4444" />
          {irIds.map((id: string) => <Row key={id} id={id} />)}
        </div>}
      </div>
    </div>
  );
}
