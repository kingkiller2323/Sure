/**
 * ManualSetupScreen.tsx — Manual league setup screen
 * Extracted from App.tsx (no behavior changes)
 */

import React, { useState } from "react";
import { Card, SectionHeader } from "../../components/ui/shared";
import { defaultManualSettings, type ManualLeagueSettings } from "../../services/manualLeague";

export interface ManualSetupScreenProps {
  onLoad: (settings: ManualLeagueSettings) => void;
}

export default function ManualSetupScreen({ onLoad }: ManualSetupScreenProps) {
  const [s, setS] = useState<ManualLeagueSettings>(defaultManualSettings());

  const set = (patch: Partial<ManualLeagueSettings>) => setS(prev => ({ ...prev, ...patch }));

  const Row = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center",
      padding:"9px 0", borderBottom:"1px solid rgba(255,255,255,0.04)" }}>
      <span style={{ fontSize:"12px", color:"#94a3b8" }}>{label}</span>
      {children}
    </div>
  );

  const Tog = ({ on, toggle }: { on: boolean; toggle: () => void }) => (
    <button onClick={toggle} style={{
      width:"40px", height:"22px", borderRadius:"11px", border:"none", cursor:"pointer",
      background: on ? "#8b5cf6" : "rgba(255,255,255,0.08)",
      position:"relative", transition:"background 0.2s"
    }}>
      <span style={{ position:"absolute", top:"3px", left: on?"19px":"3px",
        width:"16px", height:"16px", borderRadius:"50%", background:"#fff",
        transition:"left 0.2s", display:"block" }} />
    </button>
  );

  const Num = ({ val, onChange, min=1, max=32 }: { val:number; onChange:(n:number)=>void; min?:number; max?:number }) => (
    <div style={{ display:"flex", alignItems:"center", gap:"6px" }}>
      <button onClick={() => onChange(Math.max(min, val-1))} style={{ width:"24px", height:"24px",
        borderRadius:"4px", border:"1px solid rgba(255,255,255,0.1)", background:"rgba(255,255,255,0.05)",
        color:"#94a3b8", cursor:"pointer", fontFamily:"inherit", fontSize:"14px" }}>-</button>
      <span style={{ fontSize:"13px", color:"#e2e8f0", minWidth:"20px", textAlign:"center" }}>{val}</span>
      <button onClick={() => onChange(Math.min(max, val+1))} style={{ width:"24px", height:"24px",
        borderRadius:"4px", border:"1px solid rgba(255,255,255,0.1)", background:"rgba(255,255,255,0.05)",
        color:"#94a3b8", cursor:"pointer", fontFamily:"inherit", fontSize:"14px" }}>+</button>
    </div>
  );

  return (
    <div style={{ flex:1, overflowY:"auto", padding:"16px 20px" }}>
      <div style={{ fontSize:"11px", color:"#4b5563", letterSpacing:"0.08em", marginBottom:"14px" }}>
        MANUAL LEAGUE SETUP
      </div>

      <Card style={{ marginBottom:"12px" }}>
        <div style={{ marginBottom:"8px" }}>
          <div style={{ fontSize:"10px", color:"#4b5563", marginBottom:"4px" }}>LEAGUE NAME</div>
          <input value={s.name} onChange={e => set({ name: e.target.value })}
            style={{ width:"100%", padding:"8px 10px",
              background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.1)",
              borderRadius:"6px", color:"#e2e8f0", fontSize:"13px",
              fontFamily:"inherit", outline:"none", boxSizing:"border-box" }} />
        </div>
        <div>
          <div style={{ fontSize:"10px", color:"#4b5563", marginBottom:"4px" }}>PLATFORM</div>
          <div style={{ display:"flex", gap:"5px", flexWrap:"wrap" }}>
            {["ESPN","Yahoo","NFL","Fantrax","MFL","Other"].map(p => (
              <button key={p} onClick={() => set({ platform: p })} style={{
                padding:"4px 10px", borderRadius:"5px",
                border: s.platform===p ? "1px solid #8b5cf6" : "1px solid rgba(255,255,255,0.08)",
                background: s.platform===p ? "rgba(139,92,246,0.2)" : "transparent",
                color: s.platform===p ? "#c4b5fd" : "#4b5563",
                fontSize:"10px", cursor:"pointer", fontFamily:"inherit"
              }}>{p}</button>
            ))}
          </div>
        </div>
      </Card>

      <Card style={{ marginBottom:"12px" }}>
        <SectionHeader label="LEAGUE SETTINGS" color="#4b5563" />
        <Row label="Teams">
          <Num val={s.leagueSize} onChange={n => set({ leagueSize: n })} min={4} max={32} />
        </Row>
        <Row label="Playoff Teams">
          <Num val={s.playoffTeams} onChange={n => set({ playoffTeams: n })} min={2} max={16} />
        </Row>
        <Row label="Taxi Slots">
          <Num val={s.taxiSlots} onChange={n => set({ taxiSlots: n })} min={0} max={10} />
        </Row>
        <Row label="IR Slots">
          <Num val={s.irSlots} onChange={n => set({ irSlots: n })} min={0} max={10} />
        </Row>
      </Card>

      <Card style={{ marginBottom:"16px" }}>
        <SectionHeader label="SCORING FORMAT" color="#4b5563" />
        <Row label="Superflex (2-QB)">
          <Tog on={s.superflex} toggle={() => set({ superflex: !s.superflex })} />
        </Row>
        <Row label="TE Premium">
          <Tog on={s.tePremium} toggle={() => set({ tePremium: !s.tePremium })} />
        </Row>
        <Row label="IDP Scoring">
          <Tog on={s.idpEnabled} toggle={() => set({ idpEnabled: !s.idpEnabled })} />
        </Row>
      </Card>

      <button onClick={() => onLoad(s)} style={{
        width:"100%", padding:"12px",
        background:"linear-gradient(135deg,#8b5cf6,#6366f1)",
        border:"none", borderRadius:"8px", color:"#fff",
        fontSize:"13px", cursor:"pointer", fontFamily:"inherit",
        fontWeight:"600", letterSpacing:"0.04em"
      }}>Continue with Manual Setup →</button>
    </div>
  );
}
