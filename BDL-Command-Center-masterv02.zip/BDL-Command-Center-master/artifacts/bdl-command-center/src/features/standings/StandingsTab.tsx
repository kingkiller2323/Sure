/**
 * StandingsTab.tsx — League standings display tab
 * Extracted from App.tsx (no behavior changes)
 */

import React from "react";
import type { SleeperRoster, SleeperUser, SleeperLeague } from "../../services/platforms/sleeper";
import type { ManualLeagueSettings } from "../../services/manualLeague";
import type { FormatContext } from "../../services/providers/types";
import { sleeperTeamName } from "../../services/platforms/sleeper";
import { Card, SectionHeader } from "../../components/ui/shared";

export interface StandingsTabProps {
  rosters:        SleeperRoster[];
  users:          SleeperUser[];
  initialLeague:  SleeperLeague | null;
  manualSettings: ManualLeagueSettings | null;
  leagueName:     string;
  leagueSeason:   string;
  myRosterId:     number | null;
  formatCtx:      FormatContext;
  setSelectedTeam: (id: number) => void;
  setTab:         (tab: string) => void;
}

export default function StandingsTab({
  rosters,
  users,
  initialLeague,
  manualSettings,
  leagueName,
  leagueSeason,
  myRosterId,
  formatCtx,
  setSelectedTeam,
  setTab,
}: StandingsTabProps) {
  const sorted = [...rosters].sort((a,b) => {
    const aw=a.settings?.wins??0, bw=b.settings?.wins??0;
    if(bw!==aw) return bw-aw;
    return ((b.settings?.fpts??0)+(b.settings?.fpts_decimal??0)/100)-((a.settings?.fpts??0)+(a.settings?.fpts_decimal??0)/100);
  });
  const playoffSpots = initialLeague?.settings?.playoff_teams ?? manualSettings?.playoffTeams ?? 6;
  const medals = ["🥇","🥈","🥉"];

  return (
    <div style={{ flex:1, overflowY:"auto", padding:"12px" }}>
      <div style={{ fontSize:"10px", color:"#4b5563", letterSpacing:"0.08em", marginBottom:"10px" }}>
        {leagueName} · {leagueSeason} · Top {playoffSpots} make playoffs
      </div>
      {sorted.map((roster, idx) => {
        const teamName=sleeperTeamName(roster,users), user=users.find(u=>u.user_id===roster.owner_id);
        const wins=roster.settings?.wins??0, losses=roster.settings?.losses??0;
        const pts=((roster.settings?.fpts??0)+(roster.settings?.fpts_decimal??0)/100).toFixed(1);
        const isMe=roster.roster_id===myRosterId, playoff=idx<playoffSpots;
        return (
          <div key={roster.roster_id} onClick={()=>{setSelectedTeam(roster.roster_id);setTab("roster");}}
            style={{ padding:"11px 13px", borderRadius:"10px", cursor:"pointer",
              background:isMe?"rgba(139,92,246,0.1)":"rgba(255,255,255,0.02)",
              border:isMe?"1px solid rgba(139,92,246,0.3)":`1px solid ${playoff?"rgba(34,197,94,0.08)":"rgba(255,255,255,0.04)"}`,
              marginBottom:"5px", display:"flex", alignItems:"center", gap:"10px" }}>
            <div style={{ width:"26px",height:"26px",borderRadius:"50%",flexShrink:0,
              background:idx<3?"rgba(255,215,0,0.1)":"rgba(255,255,255,0.04)",
              display:"flex",alignItems:"center",justifyContent:"center",
              fontSize:idx<3?"14px":"11px",color:"#4b5563",fontWeight:"700" }}>
              {idx<3?medals[idx]:idx+1}
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontSize:"13px",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",
                color:isMe?"#c4b5fd":"#e2e8f0",fontWeight:isMe?"700":"400" }}>{isMe?"👑 ":""}{teamName}</div>
              <div style={{ fontSize:"10px", color:"#4b5563" }}>{user?.display_name}</div>
            </div>
            <div style={{ textAlign:"right", flexShrink:0 }}>
              <div style={{ fontSize:"14px",fontWeight:"700",color:playoff?"#22c55e":"#6b7280" }}>{wins}-{losses}</div>
              <div style={{ fontSize:"10px", color:"#4b5563" }}>{pts} pts</div>
            </div>
            {playoff && <div style={{ fontSize:"9px",padding:"2px 5px",borderRadius:"3px",
              background:"rgba(34,197,94,0.1)",color:"#22c55e",letterSpacing:"0.05em",flexShrink:0 }}>PO</div>}
          </div>
        );
      })}
      <Card style={{ marginTop:"14px" }}>
        <SectionHeader label="LEAGUE SETTINGS" color="#4b5563" />
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"6px" }}>
          {[
            ["Format", initialLeague?.settings?.type===2?"Dynasty":initialLeague?.settings?.type===1?"Keeper":"Redraft"],
            ["Teams", rosters.length],
            ["Playoff Teams", playoffSpots],
            ["Season", leagueSeason],
            ["Superflex", formatCtx.superflex?"Yes":"No"],
            ["TE Premium", formatCtx.tePremium?"Yes":"No"],
          ].map(([k,v]) => (
            <div key={String(k)} style={{ padding:"7px 9px",background:"rgba(255,255,255,0.02)",
              borderRadius:"6px",border:"1px solid rgba(255,255,255,0.04)" }}>
              <div style={{ fontSize:"9px",color:"#4b5563",letterSpacing:"0.06em" }}>{k}</div>
              <div style={{ fontSize:"12px",color:"#e2e8f0",marginTop:"2px",fontWeight:"600" }}>{v}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
