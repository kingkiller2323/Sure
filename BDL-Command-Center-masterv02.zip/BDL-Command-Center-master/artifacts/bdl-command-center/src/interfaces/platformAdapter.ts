/**
 * platformAdapter.ts — Strict adapter contract.
 *
 * Every platform adapter MUST implement this interface.
 * The UI layer has ZERO platform-specific logic — all parsing,
 * auth, and fetch rules live inside adapter implementations.
 *
 * Access mode guide:
 *   "leagueId"    → public data, user provides a league ID string
 *   "oauth"       → adapter handles OAuth flow with external platform
 *   "session"     → private leagues via session token / cookies
 *   "unsupported" → platform cannot be supported (no reliable API)
 */

import type { NormalizedLeagueData } from "../types/NormalizedLeagueData";

export type AccessMode = "leagueId" | "oauth" | "session" | "unsupported";

export interface PlatformAdapter {
  /** Stable identifier for this platform */
  readonly platformId: string;

  /** Human-readable name */
  readonly displayName: string;

  /** Whether this adapter is fully implemented, planned, scaffolded, or unsupported */
  readonly status: "working" | "planned" | "scaffolded" | "unsupported";

  /** How the user grants access */
  getAccessMode(): AccessMode;

  /** True if league data can be fetched with only a leagueId (no auth) */
  canFetchPubliclyByLeagueId(): boolean;

  /** True if this adapter requires an external OAuth flow */
  requiresExternalAuth(): boolean;

  /** True if this adapter requires session cookies / tokens */
  requiresSessionCookies(): boolean;

  /**
   * Fetch raw league settings and return them normalised.
   * @param leagueId - the league identifier provided by the user
   * @param authToken - optional OAuth / session token
   */
  fetchLeagueSettings(
    leagueId: string,
    authToken?: string
  ): Promise<NormalizedLeagueData["leagueSettings"]>;

  /**
   * Fetch all rosters for the league.
   */
  fetchLeagueRosters(
    leagueId: string,
    authToken?: string
  ): Promise<NormalizedLeagueData["rosters"]>;

  /**
   * Fetch all draft picks owned by each team.
   */
  fetchLeaguePicks(
    leagueId: string,
    authToken?: string
  ): Promise<NormalizedLeagueData["draftPicks"]>;

  /**
   * Fetch the full player pool for this platform.
   */
  fetchPlayers(
    leagueId: string,
    authToken?: string
  ): Promise<NormalizedLeagueData["players"]>;

  /**
   * Run a full import: fetch everything and return a complete
   * NormalizedLeagueData object ready for the analytics engine.
   */
  normalizeLeagueData(
    leagueId: string,
    authToken?: string
  ): Promise<NormalizedLeagueData>;
}

/** Minimal descriptor used by the platform registry for UI display */
export interface PlatformDescriptor {
  platformId:   string;
  displayName:  string;
  icon:         string;
  status:       "working" | "planned" | "scaffolded" | "unsupported";
  accessMode:   AccessMode;
  description:  string;
}
