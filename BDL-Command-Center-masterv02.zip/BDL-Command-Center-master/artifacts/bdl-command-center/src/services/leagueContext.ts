/**
 * leagueContext.ts — League-context valuation engine.
 *
 * The app does NOT use one fixed ranking list.
 * Base values are starting points. Final values are recalculated per league.
 *
 * Required utilities (all exported):
 *   getPositionalDemand()
 *   getReplacementLevel()
 *   getScarcityMultiplier()
 *   getScoringMultiplier()
 *   calculateLeagueAdjustedValue()
 *
 * Formula:
 *   leagueAdjustedValue = baseValue × scarcity × scoring × age × rosterDepth
 *
 * IDP uses VORP replacement logic derived from each league's actual scoring settings.
 * Never hardcode IDP values — they come from league context.
 */

import type { NormalizedLeagueData, ScoringSettings, RosterSettings } from "../types/NormalizedLeagueData";
import type { FormatContext } from "./providers/types";
import { isIdpPosition } from "../utils/positions";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface LeagueContext {
  /** Derived from NormalizedLeagueData */
  leagueSize:       number;
  rosterSettings:   RosterSettings;
  scoringSettings:  ScoringSettings;
  /** Starter count per position (from rosterSettings.starterCounts) */
  starterCounts:    Partial<Record<string, number>>;
  /** Total starters in the league (leagueSize × starters-per-roster) */
  totalStarterSlots: Partial<Record<string, number>>;
  /** Replacement level value per position (VORP baseline) */
  replacementLevels: Partial<Record<string, number>>;
  /** Scarcity multiplier per position */
  scarcityMultipliers: Partial<Record<string, number>>;
  /** Scoring multiplier per position */
  scoringMultipliers: Partial<Record<string, number>>;
}

// ─── Positional demand ────────────────────────────────────────────────────────

/**
 * How many times a position is demanded across all rosters in the league.
 * Includes flex/superflex contributions at 0.5 weight each.
 *
 * QB ↑ in superflex/2QB.  RB/WR/TE ↑ or ↓ based on flex structure.
 * IDP positions scale with IDP lineup demand.
 */
export function getPositionalDemand(
  pos: string,
  leagueSize: number,
  rs: RosterSettings,
  ss: ScoringSettings
): number {
  const starters = rs.starterCounts[pos] ?? 0;
  let demand = starters * leagueSize;

  // Flex positions contribute fractionally based on how many positions compete
  const flexCount = rs.flexPositions.length || 1;
  const sfCount   = rs.superflexPositions.length || 1;

  if (rs.flexPositions.includes(pos)) {
    demand += ((rs.starterCounts["FLEX"] ?? 0) / flexCount) * leagueSize;
  }
  if (rs.superflexPositions.includes(pos)) {
    demand += ((rs.starterCounts["SUPER_FLEX"] ?? 0) / sfCount) * leagueSize;
  }

  // IDP demand — if IDP is disabled, demand for IDP positions = 0
  if (isIdpPosition(pos) && !ss.idpEnabled) return 0;

  return demand;
}

// ─── Replacement level (VORP) ─────────────────────────────────────────────────

/**
 * The replacement level is the value of the best freely-available player
 * at a position — i.e. the (demand+1)th best player.
 *
 * In dynasty, "freely available" = unrostered on waiver wire.
 * We approximate replacement level as a percentage of baseMax for each position.
 *
 * IDP: replacement level is derived from the league's actual IDP scoring.
 * A player worth 0 combined stat points in this league scores ≈ 0 value.
 */
export function getReplacementLevel(
  pos: string,
  demand: number,
  ss: ScoringSettings
): number {
  // For IDP, derive replacement level from scoring weights
  if (isIdpPosition(pos) && ss.idpEnabled && ss.idpScoring) {
    const idp = ss.idpScoring;
    // Typical per-game stat line for a replacement-level IDP starter
    const repStats: Record<string, Record<string, number>> = {
      DL: { tackles: 3.5, sacks: 0.3, ints: 0.05, passDefd: 0.2, tds: 0.02 },
      LB: { tackles: 6.0, sacks: 0.2, ints: 0.1,  passDefd: 0.3, tds: 0.04 },
      DB: { tackles: 4.5, sacks: 0.05,ints: 0.25, passDefd: 0.6, tds: 0.04 },
    };
    const stats = repStats[pos] ?? repStats.DB;
    const perGame =
      stats.tackles  * idp.tacklePoints +
      stats.sacks    * idp.sackPoints   +
      stats.ints     * idp.intPoints    +
      stats.passDefd * idp.passDefPoints +
      stats.tds      * idp.tdPoints;
    // Annualise (17 game season) and scale to 0–10000 dynasty value
    return Math.round((perGame * 17 * 4.2));
  }

  // Offensive replacement levels: approximated from demand rank
  // These are proportional baselines — actual values come from market data
  const BASE: Record<string, number> = {
    QB:  4200, RB: 2800, WR: 2600, TE: 2200, K: 800, DEF: 600
  };
  const base = BASE[pos] ?? 1500;
  // Higher demand = more players needed = lower replacement threshold
  const demandFactor = Math.max(0.5, 1 - (demand / 250) * 0.4);
  return Math.round(base * demandFactor);
}

// ─── Scarcity multiplier ──────────────────────────────────────────────────────

/**
 * Scarcity = demand / available pool.
 * High demand + small pool → multiplier > 1.
 * Low demand + deep pool → multiplier < 1.
 *
 * Approximate position pool sizes (NFL starters + depth):
 *   QB: 32, RB: 64, WR: 96, TE: 32, DL: 96, LB: 64, DB: 64
 */
const POOL_SIZE: Record<string, number> = {
  QB: 32, RB: 64, WR: 96, TE: 32,
  DL: 96, LB: 64, DB: 64,
  K:  32, DEF: 32,
};

export function getScarcityMultiplier(pos: string, demand: number): number {
  const pool  = POOL_SIZE[pos] ?? 50;
  const ratio = demand / pool;

  if (ratio >= 1.0) return 1.25;
  if (ratio >= 0.8) return 1.15;
  if (ratio >= 0.6) return 1.05;
  if (ratio >= 0.4) return 1.00;
  if (ratio >= 0.2) return 0.92;
  return 0.85;
}

// ─── Scoring multiplier ───────────────────────────────────────────────────────

/**
 * Adjusts base value based on how this league's scoring settings
 * amplify or reduce a position's production.
 *
 * Rules:
 *   QB ↑ in superflex/2QB, ↓ in 1QB
 *   TE ↑ with TE premium
 *   RB/WR change based on PPR + flex demand
 *   IDP positions scale with their scoring weights vs. typical weights
 */
export function getScoringMultiplier(pos: string, ss: ScoringSettings): number {
  let m = 1.0;

  switch (pos) {
    case "QB":
      m = ss.superflex ? 1.35 : 0.95;
      break;
    case "TE":
      m = ss.tePremium ? 1.22 : 0.98;
      break;
    case "RB":
      m = 0.95 + (ss.ppr * 0.08);
      break;
    case "WR":
      m = 0.92 + (ss.ppr * 0.10);
      break;
    case "DL":
    case "LB":
    case "DB":
      if (!ss.idpEnabled) {
        m = 0.05; // IDP players are near-worthless in non-IDP leagues
      } else if (ss.idpScoring) {
        // Normalise against a "typical" IDP scoring weight
        const typicalSack = 2, typicalTackle = 1;
        m = 0.85 + (ss.idpScoring.sackPoints / typicalSack) * 0.08
                 + (ss.idpScoring.tacklePoints / typicalTackle) * 0.07;
        m = Math.max(0.7, Math.min(1.3, m));
      }
      break;
  }

  return m;
}

// ─── Main calculation ─────────────────────────────────────────────────────────

export interface LeagueAdjustedInput {
  baseValue:    number;
  position:     string;
  age:          number;
  /** Depth: 0 = elite starter, 0.5 = mid-bench, 1 = taxi/fringe */
  rosterDepth?: number;
}

/**
 * Calculate the league-adjusted value for a single player.
 *
 * leagueAdjustedValue = baseValue × scarcity × scoring × age × rosterDepth
 *
 * Same player pool rerankd automatically per league — no separate files.
 */
export function calculateLeagueAdjustedValue(
  input: LeagueAdjustedInput,
  ctx: LeagueContext
): number {
  const { baseValue, position, age, rosterDepth = 0 } = input;

  const scarcity = ctx.scarcityMultipliers[position]  ?? 1.0;
  const scoring  = ctx.scoringMultipliers[position]   ?? 1.0;
  const ageMult  = ageCurve(age, position);
  const depthMult = 1 - rosterDepth * 0.12;

  return Math.round(
    Math.max(100, baseValue * scarcity * scoring * ageMult * depthMult)
  );
}

function ageCurve(age: number, pos: string): number {
  if (pos === "K" || pos === "DEF") return 1.0;
  switch (pos) {
    case "QB":
      if (age <= 23) return 1.08; if (age <= 26) return 1.05;
      if (age <= 30) return 1.00; if (age <= 33) return 0.94; return 0.86;
    case "RB":
      if (age <= 21) return 1.10; if (age <= 23) return 1.08;
      if (age <= 25) return 1.00; if (age <= 26) return 0.93;
      if (age <= 27) return 0.84; if (age <= 28) return 0.72; return 0.58;
    case "WR":
      if (age <= 22) return 1.10; if (age <= 24) return 1.07;
      if (age <= 27) return 1.00; if (age <= 29) return 0.94;
      if (age <= 31) return 0.86; return 0.75;
    case "TE":
      if (age <= 23) return 1.08; if (age <= 26) return 1.04;
      if (age <= 29) return 1.00; if (age <= 31) return 0.93; return 0.84;
    case "DL":
      if (age <= 23) return 1.06; if (age <= 26) return 1.03;
      if (age <= 29) return 1.00; if (age <= 31) return 0.93; return 0.84;
    case "LB":
      if (age <= 23) return 1.05; if (age <= 26) return 1.02;
      if (age <= 29) return 1.00; if (age <= 31) return 0.93; return 0.82;
    case "DB":
      if (age <= 23) return 1.05; if (age <= 26) return 1.02;
      if (age <= 29) return 1.00; if (age <= 31) return 0.93; return 0.85;
    default:
      if (age <= 24) return 1.05; if (age <= 28) return 1.00; return 0.88;
  }
}

// ─── Context factory ──────────────────────────────────────────────────────────

/**
 * Build a LeagueContext from NormalizedLeagueData.
 * Call once per league import — context is stable until league settings change.
 */
export function buildLeagueContext(data: NormalizedLeagueData): LeagueContext {
  const { leagueSettings, rosterSettings, scoringSettings } = data;
  const leagueSize = leagueSettings.leagueSize;
  const sc         = rosterSettings.starterCounts;

  const positions = [
    "QB","RB","WR","TE","DL","LB","DB","K","DEF",
    "FLEX","SUPER_FLEX","IDP_FLEX"
  ];

  const totalStarterSlots: Partial<Record<string, number>> = {};
  const replacementLevels: Partial<Record<string, number>> = {};
  const scarcityMultipliers: Partial<Record<string, number>> = {};
  const scoringMultipliers: Partial<Record<string, number>>  = {};

  for (const pos of positions) {
    if (pos === "FLEX" || pos === "SUPER_FLEX" || pos === "IDP_FLEX") continue;
    const demand  = getPositionalDemand(pos, leagueSize, rosterSettings, scoringSettings);
    totalStarterSlots[pos] = demand;
    replacementLevels[pos] = getReplacementLevel(pos, demand, scoringSettings);
    scarcityMultipliers[pos] = getScarcityMultiplier(pos, demand);
    scoringMultipliers[pos]  = getScoringMultiplier(pos, scoringSettings);
  }

  return {
    leagueSize,
    rosterSettings,
    scoringSettings,
    starterCounts:      sc,
    totalStarterSlots,
    replacementLevels,
    scarcityMultipliers,
    scoringMultipliers,
  };
}

/** Convert LeagueContext to the FormatContext used by the valuation engine */
export function leagueContextToFormatContext(ctx: LeagueContext): FormatContext {
  const ss = ctx.scoringSettings;
  const rs = ctx.rosterSettings;
  return {
    superflex:          ss.superflex,
    tePremium:          ss.tePremium,
    idpEnabled:         ss.idpEnabled,
    leagueSize:         ctx.leagueSize,
    starterCounts:      ctx.starterCounts,
    ppr:                ss.ppr,
    passTdPoints:       (ss.rawScoring as Record<string, number>)?.["pass_td"] ?? undefined,
    benchSlots:         rs.benchSlots,
    flexPositions:      rs.flexPositions,
    superflexPositions: rs.superflexPositions,
    idpScoring:         ss.idpScoring,
  };
}
