/**
 * tradeCalculator.ts — Trade calculator logic.
 *
 * Builds the full player + pick pool for the trade UI and computes
 * trade verdicts. All value lookups go through the valuation engine —
 * no hardcoded numbers here.
 */

import { computePlayerValue, playerValue } from "./valuation";
import { generatePickPool }                from "./picks";
import type { ConsensusData }              from "./consensus";
import type { FormatContext, PickValue }   from "./providers/types";
import type { TradeMode, ValuationContext } from "./valuation";
import { POS_COLORS, valueTier, TIER_LABELS } from "../utils/positions";

// ─── Shared types ─────────────────────────────────────────────────────────────

export interface SleeperRoster {
  roster_id: number;
  owner_id: string;
  players: string[];
  starters: string[];
  taxi?: string[];
  reserve?: string[];
  settings?: { wins: number; losses: number; fpts: number; fpts_decimal: number };
}

export interface SleeperPlayer {
  first_name: string;
  last_name: string;
  position: string;
  fantasy_positions?: string[];
  team?: string;
  age?: number;
  injury_status?: string;
  status?: string;
}

export interface TradeAsset {
  id: string;              // sleeperId or pickKey
  name: string;
  position: string;
  age: number;
  team: string;
  owner: string;           // team display name
  value: number;           // adjusted value for current mode
  tier: number;
  isPick: boolean;
  formulaFallback: boolean;
}

export interface TradeVerdict {
  giveTotal: number;
  getTotal: number;
  pct: number;             // % of combined value that is on the GET side
  label: string;
  colour: string;
  emoji: string;
}

// ─── Pool builders ────────────────────────────────────────────────────────────

export function buildPlayerPool(
  rosters: SleeperRoster[],
  players: Record<string, SleeperPlayer>,
  allRosteredIds: Set<string>,
  getTeamName: (rosterId: number) => string,
  ctx: ValuationContext
): TradeAsset[] {
  const assets: TradeAsset[] = [];

  for (const id of allRosteredIds) {
    const p = players[id];
    if (!p) continue;
    const pos = p.fantasy_positions?.[0] ?? p.position ?? "?";
    const age = p.age ?? 25;

    const result = computePlayerValue(
      { sleeperId: id, name: `${p.first_name} ${p.last_name}`, position: pos, age },
      ctx
    );

    const roster = rosters.find(
      (r) =>
        (r.players ?? []).includes(id) ||
        (r.taxi ?? []).includes(id)
    );
    const owner = roster ? getTeamName(roster.roster_id) : "FA";

    assets.push({
      id,
      name: `${p.first_name} ${p.last_name}`,
      position: pos,
      age,
      team: p.team ?? "FA",
      owner,
      value: result.adjustedValue,
      tier: valueTier(result.adjustedValue),
      isPick: false,
      formulaFallback: result.formulaFallback,
    });
  }

  return assets.sort((a, b) => b.value - a.value);
}

export function buildPickPool(
  fmt: FormatContext,
  consensus: ConsensusData,
  mode: TradeMode,
  currentYear: number
): TradeAsset[] {
  const picks = generatePickPool(fmt, consensus, currentYear);
  return picks.map((pick) => {
    const val = applyModeToPickValue(pick.marketValue, pick.yearOffset, mode);
    return {
      id:              pick.pickKey,
      name:            pick.displayName,
      position:        "PICK",
      age:             0,
      team:            "PICK",
      owner:           "–",
      value:           val,
      tier:            valueTier(val),
      isPick:          true,
      formulaFallback: pick.source === "derived",
    };
  });
}

function applyModeToPickValue(
  baseValue: number,
  yearOffset: number,
  mode: TradeMode
): number {
  if (mode === "balanced") return baseValue;
  if (mode === "contender") {
    // Contenders de-value picks, especially distant ones
    const discount = 1 - yearOffset * 0.05;
    return Math.round(baseValue * 0.85 * discount);
  }
  if (mode === "rebuilder") {
    // Rebuilders value picks more
    const premium = 1 + yearOffset * 0.03;
    return Math.round(baseValue * 1.15 * premium);
  }
  return baseValue;
}

// ─── Verdict ─────────────────────────────────────────────────────────────────

export function computeVerdict(giveTotal: number, getTotal: number): TradeVerdict {
  const total = giveTotal + getTotal;
  const pct   = total > 0 ? Math.round((getTotal / total) * 100) : 50;

  let label: string, colour: string, emoji: string;

  if (pct >= 48 && pct <= 52)    { label = "EVEN TRADE";      colour = "#22c55e"; emoji = "⚖️"; }
  else if (pct >= 44 && pct < 48){ label = "SLIGHT OVERPAY";  colour = "#f59e0b"; emoji = "😐"; }
  else if (pct > 52 && pct <= 56){ label = "SLIGHT WIN";       colour = "#86efac"; emoji = "👍"; }
  else if (pct >= 38 && pct < 44){ label = "OVERPAYING";       colour = "#f97316"; emoji = "⚠️"; }
  else if (pct > 56 && pct <= 62){ label = "GOOD WIN";         colour = "#4ade80"; emoji = "✅"; }
  else if (pct < 38)              { label = "MAJOR OVERPAY";   colour = "#ef4444"; emoji = "🚨"; }
  else                            { label = "STRONG WIN";       colour = "#16a34a"; emoji = "🔥"; }

  return { giveTotal, getTotal, pct, label, colour, emoji };
}
