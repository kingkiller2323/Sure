/**
 * valuation.ts — Dynasty player valuation engine  (v3 — retuned)
 *
 * ═══════════════════════════════════════════════════════════════════════
 * BLEND MODEL
 * ═══════════════════════════════════════════════════════════════════════
 *
 * OFFENSE — position-aware source/VORP weights:
 *   QB  1QB : 80% KTC  / 20% VORP
 *   QB  SF  : 70% KTC  / 30% VORP
 *   RB      : 60% KTC  / 40% VORP
 *   WR      : 75% KTC  / 25% VORP
 *   TE  std : 70% KTC  / 30% VORP
 *   TE  prem: 65% KTC  / 35% VORP
 *
 * IDP — ranker signal is additive, VORP dominates:
 *   DL : 35% ranker / 65% VORP
 *   LB : 30% ranker / 70% VORP
 *   DB : 25% ranker / 75% VORP
 *
 * Graceful fallback: when source is missing → 100% VORP (no crash).
 *
 * ═══════════════════════════════════════════════════════════════════════
 * FINAL VALUE FORMULA
 * ═══════════════════════════════════════════════════════════════════════
 *
 *   blendedBase            = sourceWeight × source + vorpWeight × vorp
 *
 *   combinedNonAgeMultiplier =
 *     clamp(
 *       1 + consensusAdj + scoringAdj + scarcityAdj + rosterNeedAdj + modeAdj,
 *       MIN_MULT = 0.82,
 *       MAX_MULT = 1.22
 *     )
 *
 *   finalValue =
 *     blendedBase
 *     × combinedNonAgeMultiplier
 *     × ageCurveModifier            ← position-specific, capped nudge
 *     × idpDisabledMultiplier        ← structural: ~0.05 in non-IDP leagues
 *
 * Individual adjustment caps:
 *   consensusAdj   ±6%     (dynasty rank fine-tune)
 *   scoringAdj     ±15%    (format effects: SF, TE prem, PPR, IDP intensity)
 *   scarcityAdj    ±18%    (replacement-rank-derived positional scarcity)
 *   rosterNeedAdj  ±5%     (team roster balance)
 *   modeAdj        ±7%     (contender / rebuilder)
 *
 * ═══════════════════════════════════════════════════════════════════════
 */

import type { ConsensusData }  from "./consensus";
import type { FormatContext }  from "./providers/types";
import { isIdpPosition, POSITION_BASE_IMPORTANCE } from "../utils/positions";
import { normalizePlayerName } from "../utils/normalize";

// ─── Constants ────────────────────────────────────────────────────────────────
const MIN_MULT = 0.82;
const MAX_MULT = 1.22;

export type TradeMode = "contender" | "balanced" | "rebuilder";

export interface ValuationInput {
  sleeperId: string;
  name:      string;
  position:  string;
  team?:     string;
  age?:      number;
  ownerRosterPositions?: string[];
}

export interface ValuationContext {
  consensus:      ConsensusData;
  format:         FormatContext;
  mode:           TradeMode;
  rosterBalance?: Partial<Record<string, number>>;
}

// ─── VORP formula base ─────────────────────────────────────────────────────────
// "Average dynasty player value" for each position — blend anchor when source missing.
// Scale: 0–10 000 (mirrors KTC/IDP seed).
const FORMULA_POSITION_BASE: Record<string, number> = {
  QB: 6200, RB: 5800, WR: 5800, TE: 5200,
  DL: 5200, LB: 5000, DB: 4600,
  K: 1800,  DEF: 1500,
};

function vorpBase(position: string): number {
  const base       = FORMULA_POSITION_BASE[position] ?? 2000;
  const importance = POSITION_BASE_IMPORTANCE[position] ?? 0.5;
  return base * importance;
}

// ═══════════════════════════════════════════════════════════════════════════════
// STEP 1 — Position-specific age curves  (capped, nudge-not-bomb)
// ═══════════════════════════════════════════════════════════════════════════════

function ageCurveModifier(age: number, pos: string): number {
  if (pos === "K" || pos === "DEF") return 1.0;

  switch (pos) {
    case "QB":
      if (age <= 23) return 1.08;
      if (age <= 26) return 1.05;
      if (age <= 30) return 1.00;
      if (age <= 33) return 0.94;
      return 0.86;

    case "RB":
      if (age <= 21) return 1.10;
      if (age <= 23) return 1.08;
      if (age <= 25) return 1.00;
      if (age <= 26) return 0.93;
      if (age <= 27) return 0.84;
      if (age <= 28) return 0.72;
      return 0.58;

    case "WR":
      if (age <= 22) return 1.10;
      if (age <= 24) return 1.07;
      if (age <= 27) return 1.00;
      if (age <= 29) return 0.94;
      if (age <= 31) return 0.86;
      return 0.75;

    case "TE":
      if (age <= 23) return 1.08;
      if (age <= 26) return 1.04;
      if (age <= 29) return 1.00;
      if (age <= 31) return 0.93;
      return 0.84;

    case "DL":
      if (age <= 23) return 1.06;
      if (age <= 26) return 1.03;
      if (age <= 29) return 1.00;
      if (age <= 31) return 0.93;
      return 0.84;

    case "LB":
      if (age <= 23) return 1.05;
      if (age <= 26) return 1.02;
      if (age <= 29) return 1.00;
      if (age <= 31) return 0.93;
      return 0.82;

    case "DB":
      if (age <= 23) return 1.05;
      if (age <= 26) return 1.02;
      if (age <= 29) return 1.00;
      if (age <= 31) return 0.93;
      return 0.85;

    default:
      if (age <= 24) return 1.05;
      if (age <= 28) return 1.00;
      return 0.88;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// STEP 3 — Position-aware blend functions  (exported for testing / debug)
// ═══════════════════════════════════════════════════════════════════════════════

export interface BlendDetail {
  sourceType:   "ktc" | "idp_ranker" | "vorp_only";
  sourceValue:  number | null;
  vorpValue:    number;
  blendedBase:  number;
  sourceWeight: number;
  vorpWeight:   number;
}

/**
 * Offense blend — position and format aware.
 *   QB 1QB 80/20  QB SF 70/30  RB 60/40  WR 75/25  TE 70/30  TE-prem 65/35
 */
export function blendOffenseValue(
  sourceValue: number | null,
  vorp:        number,
  position:    string,
  fmt:         Pick<FormatContext, "superflex" | "tePremium">
): BlendDetail {
  if (!sourceValue || sourceValue <= 0) {
    return {
      sourceType: "vorp_only", sourceValue: null, vorpValue: vorp,
      blendedBase: Math.round(vorp), sourceWeight: 0, vorpWeight: 1,
    };
  }

  let sw: number;
  switch (position) {
    case "QB": sw = fmt.superflex ? 0.70 : 0.80; break;
    case "RB": sw = 0.60; break;
    case "WR": sw = 0.75; break;
    case "TE": sw = fmt.tePremium ? 0.65 : 0.70; break;
    default:   sw = 0.70;
  }
  const vw = 1 - sw;

  return {
    sourceType:   "ktc",
    sourceValue,
    vorpValue:    vorp,
    blendedBase:  Math.round(sw * sourceValue + vw * vorp),
    sourceWeight: sw,
    vorpWeight:   vw,
  };
}

/**
 * IDP blend — VORP-dominant (ranker is directional signal).
 *   DL 35/65   LB 30/70   DB 25/75
 */
export function blendIdpValue(
  sourceValue: number | null,
  vorp:        number,
  position:    string
): BlendDetail {
  if (!sourceValue || sourceValue <= 0) {
    return {
      sourceType: "vorp_only", sourceValue: null, vorpValue: vorp,
      blendedBase: Math.round(vorp), sourceWeight: 0, vorpWeight: 1,
    };
  }

  let sw: number;
  switch (position) {
    case "DL": sw = 0.35; break;
    case "LB": sw = 0.30; break;
    case "DB": sw = 0.25; break;
    default:   sw = 0.30;
  }
  const vw = 1 - sw;

  return {
    sourceType:   "idp_ranker",
    sourceValue,
    vorpValue:    vorp,
    blendedBase:  Math.round(sw * sourceValue + vw * vorp),
    sourceWeight: sw,
    vorpWeight:   vw,
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// STEP 2 — Post-blend adjustments  (each individually capped)
// ═══════════════════════════════════════════════════════════════════════════════

// ── 2a. Consensus rank adjustment  cap ±6% ────────────────────────────────────
function consensusAdj(rank: number | undefined, formulaFallback: boolean): number {
  let adj = 0;
  if (rank === undefined) {
    adj = 0;
  } else if (rank <= 12)  { adj =  0.06; }
  else if (rank <= 36)   { adj =  0.04; }
  else if (rank <= 72)   { adj =  0.02; }
  else if (rank <= 144)  { adj =  0.00; }
  else if (rank <= 240)  { adj = -0.02; }
  else                   { adj = -0.05; }

  // When no market source, rank nudges a bit more to compensate
  return formulaFallback ? adj * 1.4 : adj;
}

// ── 2b. Scoring / format adjustment  cap ±15% ─────────────────────────────────
// ── STEP 4 — Derived from league scoring settings, not hardcoded ──────────────
/**
 * Translates league scoring settings into bounded positional scoring adjustments.
 *
 * Uses actual ScoringSettings fields when available (ppr, passTdPoints, idpScoring).
 * Falls back to binary flag interpretation (superflex, tePremium, idpEnabled)
 * when detailed settings are not provided.
 *
 * Does NOT apply the IDP-disabled structural penalty here — that is applied
 * separately as idpDisabledMult (outside the clamped pipeline) because it
 * is a structural league-format factor, not a scoring tuning parameter.
 */
function scoringAdj(pos: string, fmt: FormatContext): number {
  let adj = 0;

  if (pos === "QB") {
    // Superflex effect on QB value
    adj += fmt.superflex ? 0.12 : 0;
    // Passing TD value: baseline 4pt. 6pt ≈ +5%, 4pt = 0%, <4pt = negative
    const ptd = fmt.passTdPoints ?? (fmt.superflex ? 6 : 4);
    adj += Math.max(-0.04, Math.min(0.06, (ptd - 4) * 0.025));
  }

  if (pos === "TE") {
    adj += fmt.tePremium ? 0.12 : 0;
    // PPR benefit: full PPR = 0 extra, 0.5 = -2%, 0 PPR = -4%
    const ppr = fmt.ppr ?? 1;
    adj += (ppr - 1) * 0.04;
  }

  if (pos === "RB") {
    // RBs benefit from reception volume (PPR and bonus receptions)
    const ppr = fmt.ppr ?? 1;
    adj += (ppr - 0.5) * 0.08;  // full PPR = +4%, half = 0%, standard = -4%
  }

  if (pos === "WR") {
    const ppr = fmt.ppr ?? 1;
    adj += (ppr - 0.5) * 0.06;  // full PPR = +3%, half = 0%, standard = -3%
  }

  if (isIdpPosition(pos) && fmt.idpEnabled) {
    // Base IDP enabled bonus (position is actually playable in this league)
    adj += 0.06;

    if (fmt.idpScoring) {
      const { tacklePoints, sackPoints, intPoints } = fmt.idpScoring;
      // Reference baselines: tackle=1.0, sack=2.0, int=3.0
      const tackleRel = tacklePoints / 1.0;
      const sackRel   = sackPoints   / 2.0;
      const intRel    = intPoints    / 3.0;

      if (pos === "DL") {
        // DL benefits from sack-heavy scoring
        adj += Math.max(-0.05, Math.min(0.07, (sackRel - 1) * 0.09));
        adj += Math.max(-0.03, Math.min(0.04, (tackleRel - 1) * 0.03));
      }
      if (pos === "LB") {
        // LB benefits from tackle-heavy scoring
        adj += Math.max(-0.05, Math.min(0.07, (tackleRel - 1) * 0.08));
        adj += Math.max(-0.02, Math.min(0.03, (sackRel - 1) * 0.03));
      }
      if (pos === "DB") {
        // DB benefits from int and pass-def scoring
        adj += Math.max(-0.04, Math.min(0.06, (intRel    - 1) * 0.07));
        adj += Math.max(-0.03, Math.min(0.04, (tackleRel - 1) * 0.04));
      }
    }
  }

  return Math.max(-0.15, Math.min(0.15, adj));
}

// ── 2c. Scarcity adjustment  cap ±18% ─────────────────────────────────────────
// ── STEP 5 — Replacement-rank style scarcity ──────────────────────────────────
/**
 * Derives positional scarcity from actual roster demand:
 *   replacementRank ≈ teams × (directStarters + flexShare×0.55 + benchFrac×0.20)
 *
 * Then compares to NFL talent pool size to get the scarcity ratio.
 * IDP positions → 0 scarcity when IDP is disabled (no demand).
 */
function scarcityAdj(pos: string, fmt: FormatContext): number {
  if (isIdpPosition(pos) && !fmt.idpEnabled) return 0;

  const teams  = fmt.leagueSize;
  const sc     = fmt.starterCounts ?? {};
  const bench  = fmt.benchSlots   ?? 6;
  const flex   = fmt.flexPositions   ?? ["RB", "WR", "TE"];
  const sflex  = fmt.superflexPositions ?? (fmt.superflex ? ["QB", "RB", "WR", "TE"] : []);

  const directStarters = (sc[pos] ?? 0);

  const flexSlots  = sc["FLEX"]       ?? sc["FLX"] ?? (flex.length  > 0 ? 1 : 0);
  const sflexSlots = sc["SUPER_FLEX"] ?? sc["SF"]  ?? (sflex.length > 0 ? 1 : 0);

  const flexShare  = flex.includes(pos)
    ? (flexSlots  / Math.max(1, flex.length))  * 0.55
    : 0;
  const sflexShare = sflex.includes(pos)
    ? (sflexSlots / Math.max(1, sflex.length)) * 0.55
    : 0;

  // Bench carry: estimate how much of the bench is devoted to this position
  const totalDirectStart = Math.max(1,
    Object.values(sc as Record<string, number>).reduce((s, v) => s + (v ?? 0), 0)
  );
  const posFrac    = directStarters / totalDirectStart;
  const benchCarry = bench * posFrac * 0.20;

  const replacementRank = teams * (directStarters + flexShare + sflexShare + benchCarry);

  // NFL talent pool (dynasty-relevant players per position)
  const POOL: Record<string, number> = {
    QB: 36, RB: 80, WR: 120, TE: 36,
    DL: 100, LB: 80, DB: 100,
    K: 36, DEF: 36,
  };
  const pool  = POOL[pos] ?? 60;
  const ratio = replacementRank / pool;

  let adj = 0;
  if      (ratio >= 0.80) adj =  0.15;
  else if (ratio >= 0.65) adj =  0.10;
  else if (ratio >= 0.50) adj =  0.05;
  else if (ratio >= 0.35) adj =  0.00;
  else if (ratio >= 0.20) adj = -0.05;
  else                    adj = -0.12;

  return Math.max(-0.18, Math.min(0.18, adj));
}

// ── 2d. Roster-need adjustment  cap ±5% ───────────────────────────────────────
// ── STEP 6 ────────────────────────────────────────────────────────────────────
function rosterNeedAdj(
  position: string,
  balance: Partial<Record<string, number>> | undefined
): number {
  if (!balance) return 0;
  const b = balance[position] ?? 0;
  return Math.max(-0.05, Math.min(0.05, b * -0.025));
}

// ── 2e. Trade-mode adjustment  cap ±7% ────────────────────────────────────────
function modeAdj(age: number, position: string, mode: TradeMode): number {
  if (mode === "balanced") return 0;
  const isPick  = position === "PICK";
  const isYoung = age > 0 && age <= 24;
  const isVet   = age >= 29;

  if (mode === "contender") {
    if (isVet)   return  0.07;
    if (isPick)  return -0.07;
    if (isYoung) return -0.04;
  }
  if (mode === "rebuilder") {
    if (isYoung || isPick) return  0.07;
    if (isVet)             return -0.07;
  }
  return 0;
}

// ═══════════════════════════════════════════════════════════════════════════════
// ValuationResult
// ═══════════════════════════════════════════════════════════════════════════════

export interface ValuationResult {
  adjustedValue:         number;
  baseMarketValue:       number;
  formulaFallback:       boolean;
  blend:                 BlendDetail;
  combinedNonAgeMult:    number;    // after clamping [0.82, 1.22]
  idpDisabledMult:       number;    // 1.0 normally; ~0.05 for IDP in non-IDP leagues
  adjustments: {
    consensus:  number;
    scoring:    number;
    scarcity:   number;
    rosterNeed: number;
    mode:       number;
    ageCurve:   number;
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// Main entry point
// ═══════════════════════════════════════════════════════════════════════════════

export function computePlayerValue(
  player: ValuationInput,
  ctx:    ValuationContext
): ValuationResult {
  const { consensus, format: fmt, mode, rosterBalance } = ctx;
  const pos = player.position;
  const age = player.age ?? 25;

  // ── 1. Lookup + position-aware blend ─────────────────────────────────────
  let blend: BlendDetail;

  if (isIdpPosition(pos)) {
    const pid = `sleeper:${player.sleeperId}`;
    let idpRecord = consensus.marketValues.get(pid) ?? null;
    if (!idpRecord && player.name) {
      const k = `idp:${normalizePlayerName(player.name)}-${pos.toLowerCase()}`;
      idpRecord = consensus.marketValues.get(k) ?? null;
    }
    blend = blendIdpValue(idpRecord?.marketValue ?? null, vorpBase(pos), pos);

  } else {
    const pid = `sleeper:${player.sleeperId}`;
    let mvRecord = consensus.marketValues.get(pid) ?? null;
    if (!mvRecord && player.name) {
      const k = `ktc:${normalizePlayerName(player.name)}-${pos.toLowerCase()}`;
      mvRecord = consensus.marketValues.get(k) ?? null;
    }
    const ktcVal = mvRecord
      ? (fmt.superflex && mvRecord.sfValue !== undefined ? mvRecord.sfValue : mvRecord.marketValue)
      : null;
    blend = blendOffenseValue(ktcVal, vorpBase(pos), pos, fmt);
  }

  const baseMarketValue = blend.blendedBase;
  const formulaFallback = blend.sourceType === "vorp_only";

  // ── 2. Dynasty rank lookup ────────────────────────────────────────────────
  const pid     = `sleeper:${player.sleeperId}`;
  const ktcLKey = `ktc:${normalizePlayerName(player.name)}-${pos.toLowerCase()}`;
  const idpLKey = `idp:${normalizePlayerName(player.name)}-${pos.toLowerCase()}`;
  const dynRank = (
    consensus.dynastyRanks.get(pid) ??
    consensus.dynastyRanks.get(ktcLKey) ??
    consensus.dynastyRanks.get(idpLKey)
  )?.consensusRank;

  // ── 3. Compute each capped adjustment ────────────────────────────────────
  const cAdj  = consensusAdj(dynRank, formulaFallback);
  const sAdj  = isIdpPosition(pos) && !fmt.idpEnabled ? 0 : scoringAdj(pos, fmt);
  const scAdj = scarcityAdj(pos, fmt);
  const rnAdj = rosterNeedAdj(pos, rosterBalance);
  const mAdj  = modeAdj(age, pos, mode);

  // ── 4. Clamp combined non-age multiplier [0.82, 1.22] ────────────────────
  const rawMult = 1 + cAdj + sAdj + scAdj + rnAdj + mAdj;
  const combinedNonAgeMult = Math.max(MIN_MULT, Math.min(MAX_MULT, rawMult));

  // ── 5. Age curve (position-specific, capped nudge) ────────────────────────
  const ageCurve = ageCurveModifier(age, pos);

  // ── 6. IDP disabled structural multiplier (outside clamped pipeline) ──────
  // IDP players are near-worthless in non-IDP leagues — structural, not tuning.
  const idpDisabledMult = isIdpPosition(pos) && !fmt.idpEnabled ? 0.05 : 1.0;

  // ── 7. Final value ─────────────────────────────────────────────────────────
  const adjustedValue = Math.round(
    baseMarketValue * combinedNonAgeMult * ageCurve * idpDisabledMult
  );

  return {
    adjustedValue:      Math.max(100, adjustedValue),
    baseMarketValue:    Math.round(baseMarketValue),
    formulaFallback,
    blend,
    combinedNonAgeMult,
    idpDisabledMult,
    adjustments: {
      consensus:  cAdj,
      scoring:    sAdj,
      scarcity:   scAdj,
      rosterNeed: rnAdj,
      mode:       mAdj,
      ageCurve,
    },
  };
}

/** Convenience wrapper — returns final adjusted value only */
export function playerValue(
  sleeperId: string,
  name:      string,
  position:  string,
  age:       number | undefined,
  ctx:       ValuationContext
): number {
  return computePlayerValue({ sleeperId, name, position, age }, ctx).adjustedValue;
}
