/**
 * picks.ts — Dynamic pick value system.
 *
 * Pick values are derived from a formula rather than hardcoded tables.
 * When an external pick value feed is connected in dataSources.ts, that
 * feed's output wins and overrides the formula. Until then, the formula
 * produces sensible defaults.
 *
 * Formula:
 *   pickValue =
 *     classStrengthMultiplier
 *     * roundBaseValue
 *     * bucketModifier
 *     * yearDiscount
 *     * formatModifier
 *
 * All constants are defined here and can be tuned without touching the UI.
 */

import { CURRENT_ROOKIE_CLASS } from "../config/dataSources";
import type { FormatContext, PickValue } from "./providers/types";
import type { ConsensusData }  from "./consensus";

// ─── Tuning constants ─────────────────────────────────────────────────────────

/** Nominal value of the 1.01 in a "standard" rookie class */
const FIRST_OVERALL_BASE = 9500;

/** Round multipliers (relative to a 1st-round pick baseline of 1.0) */
const ROUND_MULTIPLIER: Record<number, number> = {
  1: 1.000,
  2: 0.430,
  3: 0.240,
  4: 0.115,
  5: 0.085,
};

/** Slot-within-round bucket modifiers */
const BUCKET_MODIFIER: Record<string, number> = {
  early: 1.12,
  mid:   0.98,
  late:  0.84,
  fixed: 0.98,   // for picks specified without a slot
};

/** Per-year discount: future picks are worth less */
const YEAR_DISCOUNT_RATE = 0.82; // each extra year discounts by 18 %

/** Optional league format boosts */
function formatModifier(fmt: FormatContext): number {
  let m = 1.0;
  if (fmt.superflex) m *= 1.06;   // SF leagues value QB picks more
  if (fmt.leagueSize >= 14) m *= 1.04;
  return m;
}

// ─── Class strength ───────────────────────────────────────────────────────────
/**
 * Adjusts pick values based on how many top-tier rookies the consensus
 * data suggests are in this class.
 * Returns a multiplier in [0.80, 1.20].
 */
function classStrengthMultiplier(
  classYear: number,
  consensus: ConsensusData
): number {
  const topRookies = [...consensus.rookieRanks.values()].filter(
    (r) => r.classYear === classYear
  );
  const tier1Count = topRookies.filter((r) => r.tier === 1).length;
  const tier2Count = topRookies.filter((r) => r.tier === 2).length;

  // If provider isn't loaded we have no class data — return neutral
  if (topRookies.length === 0) return 1.0;

  const score = tier1Count * 3 + tier2Count;
  if (score >= 12) return 1.20;
  if (score >= 8)  return 1.12;
  if (score >= 5)  return 1.05;
  if (score >= 3)  return 1.00;
  if (score >= 1)  return 0.92;
  return 0.80;
}

// ─── Generator ───────────────────────────────────────────────────────────────

export interface PickSpec {
  year: number;
  round: number;
  bucket: "early" | "mid" | "late" | "fixed";
}

/** Build the canonical pick display name */
function displayName(spec: PickSpec): string {
  const suffix = spec.bucket === "fixed" ? "" : ` (${cap(spec.bucket)})`;
  const ordinal = ["1st","2nd","3rd","4th","5th"][spec.round - 1] ?? `${spec.round}th`;
  return `${spec.year} ${ordinal}${suffix}`;
}

function cap(s: string) { return s.charAt(0).toUpperCase() + s.slice(1); }

/**
 * Derive the value of a single pick.
 *
 * classStrength: pass the consensusData so the engine can detect class depth.
 * If consensusData is unavailable, pass null for a neutral class multiplier.
 */
export function computePickValue(
  spec: PickSpec,
  fmt: FormatContext,
  consensus: ConsensusData | null,
  currentYear: number = CURRENT_ROOKIE_CLASS
): PickValue {
  const yearOffset = spec.year - currentYear;
  const strength   = consensus
    ? classStrengthMultiplier(spec.year, consensus)
    : 1.0;

  const rawValue =
    strength
    * (FIRST_OVERALL_BASE * (ROUND_MULTIPLIER[spec.round] ?? 0.05))
    * (BUCKET_MODIFIER[spec.bucket] ?? 0.98)
    * Math.pow(YEAR_DISCOUNT_RATE, yearOffset)
    * formatModifier(fmt);

  const marketValue = Math.round(Math.max(100, rawValue));

  return {
    pickKey:     `${spec.year}_${spec.round}_${spec.bucket}`,
    displayName: displayName(spec),
    round:       spec.round,
    yearOffset,
    bucket:      spec.bucket,
    marketValue,
    source:      "derived",
  };
}

/**
 * Generate the full pick pool used in the trade calculator.
 * Covers years currentYear through currentYear+2, rounds 1–4.
 */
export function generatePickPool(
  fmt: FormatContext,
  consensus: ConsensusData | null,
  currentYear: number = CURRENT_ROOKIE_CLASS
): PickValue[] {
  const specs: PickSpec[] = [];
  const buckets: Array<"early" | "mid" | "late"> = ["early", "mid", "late"];

  for (let yOff = 0; yOff <= 2; yOff++) {
    const year = currentYear + yOff;
    for (let round = 1; round <= 4; round++) {
      for (const bucket of buckets) {
        specs.push({ year, round, bucket });
      }
    }
  }
  // Add a 5th round for current year only
  for (const bucket of buckets) {
    specs.push({ year: currentYear, round: 5, bucket });
  }

  return specs.map((s) => computePickValue(s, fmt, consensus, currentYear));
}
