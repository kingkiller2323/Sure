/**
 * playerMetadataProvider.ts
 *
 * Supplemental player metadata (name, team, age, injury status).
 * When using Sleeper import, Sleeper's /players/nfl fills this role.
 * This provider is for manual leagues or cross-source enrichment.
 *
 * TO CONNECT: Set DATA_SOURCES.playerMetadata.url and .enabled = true.
 */

import DATA_SOURCES from "../../config/dataSources";
import { normalizePosition, normalizePlayerName } from "../../utils/normalize";
import type { PlayerMetadata, ProviderResult } from "./types";

function makePlayerId(raw: Record<string, unknown>): string {
  const sid = raw.sleeperId ?? raw.player_id ?? raw.id;
  if (sid) return `sleeper:${sid}`;
  const name = String(raw.name ?? raw.playerName ?? "").trim();
  const pos  = normalizePosition(String(raw.position ?? raw.pos ?? ""));
  return `meta:${normalizePlayerName(name)}-${pos.toLowerCase()}`;
}

function normaliseRow(raw: Record<string, unknown>): PlayerMetadata | null {
  try {
    const name = String(raw.name ?? raw.playerName ?? "").trim();
    const pos  = normalizePosition(String(raw.position ?? raw.pos ?? ""));
    if (!name || !pos) return null;

    return {
      playerId:     makePlayerId(raw),
      name,
      position:     pos,
      team:         raw.team ? String(raw.team) : undefined,
      age:          raw.age !== undefined ? Number(raw.age) : undefined,
      injuryStatus: raw.injuryStatus ?? raw.injury_status
                      ? String(raw.injuryStatus ?? raw.injury_status) : undefined,
      status:       raw.status ? String(raw.status) : undefined,
    };
  } catch {
    return null;
  }
}

export async function getPlayerMetadata(): Promise<ProviderResult<PlayerMetadata>> {
  const cfg = DATA_SOURCES.playerMetadata;

  if (!cfg.enabled || !cfg.url) {
    return {
      data:   [],
      source: "PlayerMetadata",
      loaded: false,
      error:
        "Player metadata provider not configured (optional — Sleeper import provides metadata automatically).",
    };
  }

  try {
    const res = await fetch(cfg.url, { headers: cfg.headers ?? {} });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const raw: unknown[] = await res.json();

    const data: PlayerMetadata[] = [];
    const seen = new Set<string>();

    for (const row of raw) {
      const item = normaliseRow(row as Record<string, unknown>);
      if (!item || seen.has(item.playerId)) continue;
      seen.add(item.playerId);
      data.push(item);
    }

    return { data, source: "PlayerMetadata", loaded: true };
  } catch (err: unknown) {
    return {
      data:   [],
      source: "PlayerMetadata",
      loaded: false,
      error: `Player metadata fetch failed: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}

/**
 * Convert a raw Sleeper /players/nfl record into a PlayerMetadata record.
 * playerId = "sleeper:<sleeperId>" for exact cross-source matching.
 */
export function sleeperPlayerToMetadata(
  sleeperId: string,
  p: Record<string, unknown>
): PlayerMetadata {
  const pos = normalizePosition(
    String((p.fantasy_positions as string[])?.[0] ?? p.position ?? "")
  );
  return {
    playerId:     `sleeper:${sleeperId}`,
    name:         `${p.first_name ?? ""} ${p.last_name ?? ""}`.trim(),
    position:     pos,
    team:         p.team ? String(p.team) : undefined,
    age:          p.age !== undefined ? Number(p.age) : undefined,
    injuryStatus: p.injury_status ? String(p.injury_status) : undefined,
    status:       p.status ? String(p.status) : undefined,
  };
}
