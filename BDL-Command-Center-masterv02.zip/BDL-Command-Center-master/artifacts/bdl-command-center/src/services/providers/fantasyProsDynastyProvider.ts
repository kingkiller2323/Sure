/**
 * fantasyProsDynastyProvider.ts — FantasyPros Dynasty ECR provider.
 *
 * TO CONNECT A LIVE SOURCE:
 *   1. Set DATA_SOURCES.fantasyProsDynasty.url to your FP dynasty JSON export.
 *   2. Set DATA_SOURCES.fantasyProsDynasty.enabled = true
 *
 * Expected input row shape:
 *   { sleeperId?, playerName, position, team?, rank, tier? }
 *
 * Do NOT embed FantasyPros HTML scraping here — only JSON normalisation.
 */

import DATA_SOURCES from "../../config/dataSources";
import { normalizePosition, normalizePlayerName } from "../../utils/normalize";
import type { DynastyConsensusRank, FormatContext, ProviderResult } from "./types";

function makePlayerId(raw: Record<string, unknown>): string {
  const sid = raw.sleeperId ?? raw.player_id ?? raw.id;
  if (sid) return `sleeper:${sid}`;
  const name = String(raw.playerName ?? raw.name ?? "").trim();
  const pos  = normalizePosition(String(raw.position ?? raw.pos ?? ""));
  return `fp:${normalizePlayerName(name)}-${pos.toLowerCase()}`;
}

function normaliseRow(
  raw: Record<string, unknown>,
  idx: number
): DynastyConsensusRank | null {
  try {
    const name = String(raw.playerName ?? raw.name ?? "").trim();
    const pos  = normalizePosition(String(raw.position ?? raw.pos ?? ""));
    const rank = Number(raw.rank ?? raw.ecr ?? raw.consensusRank ?? idx + 1);
    const tier = Number(raw.tier ?? Math.ceil(rank / 12));

    if (!name || !pos) return null;

    return {
      playerId:     makePlayerId(raw),
      name,
      position:     pos,
      team:         raw.team ? String(raw.team) : undefined,
      consensusRank: rank,
      tier,
      source:       "fantasypros_dynasty",
    };
  } catch {
    return null;
  }
}

export async function getConsensusDynastyRanks(
  _ctx: FormatContext
): Promise<ProviderResult<DynastyConsensusRank>> {
  const cfg = DATA_SOURCES.fantasyProsDynasty;

  if (!cfg.enabled || !cfg.url) {
    return {
      data:   [],
      source: "fantasypros_dynasty",
      loaded: false,
      error:
        "FantasyPros Dynasty provider not configured. " +
        "Set DATA_SOURCES.fantasyProsDynasty.url and .enabled = true.",
    };
  }

  try {
    const res  = await fetch(cfg.url, { headers: cfg.headers ?? {} });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const raw: unknown[] = await res.json();

    const data: DynastyConsensusRank[] = [];
    const seen = new Set<string>();

    raw.forEach((row, i) => {
      const item = normaliseRow(row as Record<string, unknown>, i);
      if (!item || seen.has(item.playerId)) return;
      seen.add(item.playerId);
      data.push(item);
    });

    return { data, source: "fantasypros_dynasty", loaded: true };
  } catch (err: unknown) {
    return {
      data:   [],
      source: "fantasypros_dynasty",
      loaded: false,
      error: `FantasyPros Dynasty fetch failed: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}
