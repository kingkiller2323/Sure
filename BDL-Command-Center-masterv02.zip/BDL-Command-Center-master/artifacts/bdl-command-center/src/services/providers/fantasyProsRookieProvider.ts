/**
 * fantasyProsRookieProvider.ts — FantasyPros Dynasty Rookie ECR provider.
 *
 * TO CONNECT A LIVE SOURCE:
 *   1. Set DATA_SOURCES.fantasyProsRookies.url to your FP rookie JSON export.
 *   2. Set DATA_SOURCES.fantasyProsRookies.enabled = true
 *
 * Expected input row shape:
 *   { sleeperId?, playerName, position, school?, classYear?, rank, tier?, note? }
 *
 * playerId format: "rookie:<classYear>:<normalized-name>-<pos>"
 *
 * Deduplication: keeps the first (highest-ranked) occurrence of each player.
 * Do NOT embed FantasyPros page scraping here — only JSON normalisation.
 */

import DATA_SOURCES, { CURRENT_ROOKIE_CLASS } from "../../config/dataSources";
import { normalizePosition, normalizePlayerName } from "../../utils/normalize";
import type { FormatContext, ProviderResult, RookieConsensusRank } from "./types";

function makePlayerId(raw: Record<string, unknown>, classYear: number): string {
  const sid = raw.sleeperId ?? raw.player_id;
  if (sid) return `sleeper:${sid}`;
  const name = String(raw.playerName ?? raw.name ?? "").trim();
  const pos  = normalizePosition(String(raw.position ?? raw.pos ?? ""));
  return `rookie:${classYear}:${normalizePlayerName(name)}-${pos.toLowerCase()}`;
}

function normaliseRow(
  raw: Record<string, unknown>,
  idx: number,
  classYear: number
): RookieConsensusRank | null {
  try {
    const name   = String(raw.playerName ?? raw.name ?? "").trim();
    const pos    = normalizePosition(String(raw.position ?? raw.pos ?? ""));
    const school = raw.school ?? raw.college;
    const year   = Number(raw.classYear ?? raw.class ?? raw.year ?? classYear);
    const rank   = Number(raw.rank ?? raw.ecr ?? idx + 1);
    const tier   = Number(raw.tier ?? Math.ceil(rank / 5));
    const note   = raw.note ? String(raw.note) : undefined;

    if (!name || !pos) return null;

    return {
      playerId:     makePlayerId(raw, year),
      name,
      position:     pos,
      school:       school ? String(school) : undefined,
      classYear:    year,
      consensusRank: rank,
      tier,
      note,
      source:       "fantasypros_rookie",
    };
  } catch {
    return null;
  }
}

export async function getConsensusRookieRanks(
  classYear: number = CURRENT_ROOKIE_CLASS,
  _ctx: FormatContext
): Promise<ProviderResult<RookieConsensusRank>> {
  const cfg = DATA_SOURCES.fantasyProsRookies;

  if (!cfg.enabled || !cfg.url) {
    return {
      data:   [],
      source: "fantasypros_rookie",
      loaded: false,
      error:
        "FantasyPros Rookie provider not configured. " +
        "Set DATA_SOURCES.fantasyProsRookies.url and .enabled = true.",
    };
  }

  try {
    const res  = await fetch(cfg.url, { headers: cfg.headers ?? {} });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const raw: unknown[] = await res.json();

    const data: RookieConsensusRank[] = [];
    const seen = new Set<string>();

    raw.forEach((row, i) => {
      const item = normaliseRow(row as Record<string, unknown>, i, classYear);
      if (!item) return;
      // Dedupe by playerId — first occurrence wins (highest rank)
      if (seen.has(item.playerId)) return;
      seen.add(item.playerId);
      data.push(item);
    });

    return { data, source: "fantasypros_rookie", loaded: true };
  } catch (err: unknown) {
    return {
      data:   [],
      source: "fantasypros_rookie",
      loaded: false,
      error: `FantasyPros Rookie fetch failed: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}
