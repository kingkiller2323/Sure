/**
 * Canonical normalized shapes for all provider outputs.
 * Every external source maps into one of these before touching app logic.
 */

export interface ProviderResult<T> {
  data: T[];
  source: string;
  loaded: boolean;
  error?: string;
}

/**
 * Player market value (KTC-style or IDP-style).
 * playerId format: "sleeper:<sleeperId>" when origin is Sleeper,
 *                  or a normalized key like "ktc:bijan-robinson-rb".
 */
export interface PlayerMarketValue {
  playerId: string;
  name: string;
  position: string;
  team: string;
  age: number;
  marketValue: number;
  sfValue?: number;          // superflex-adjusted, if available
  source: string;            // e.g. "ktc" | "idp_trade_calculator"
  format: string;            // e.g. "dynasty_sf" | "dynasty_1qb" | "idp"
  scoringModel?: string;     // IDP-specific e.g. "big3" | "big6"
}

/**
 * Dynasty consensus ranking (FantasyPros-style).
 */
export interface DynastyConsensusRank {
  playerId: string;
  name: string;
  position: string;
  team?: string;
  consensusRank: number;
  tier: number;
  source: string;            // e.g. "fantasypros_dynasty"
}

/**
 * Rookie consensus ranking.
 * playerId format: "rookie:<classYear>:<normalized-name-pos>"
 */
export interface RookieConsensusRank {
  playerId: string;
  name: string;
  position: string;
  school?: string;
  classYear: number;
  consensusRank: number;
  tier: number;
  note?: string;
  source: string;            // e.g. "fantasypros_rookie"
}

/**
 * Pick value record.
 * pickKey format: "<year>_<round>_<bucket>"  e.g. "2027_1_mid"
 */
export interface PickValue {
  pickKey: string;
  displayName: string;       // e.g. "2027 1st (Mid)"
  round: number;
  yearOffset: number;        // 0 = current year, 1 = next, ...
  bucket: "early" | "mid" | "late" | "fixed";
  marketValue: number;
  source: string;            // e.g. "derived"
}

/** Player metadata record */
export interface PlayerMetadata {
  playerId: string;
  name: string;
  position: string;
  team?: string;
  age?: number;
  injuryStatus?: string;
  status?: string;
}

/**
 * Format / scoring context passed to providers and the valuation engine.
 *
 * Core fields (always present — set from basic league flags):
 *   superflex, tePremium, idpEnabled, leagueSize, starterCounts
 *
 * Extended scoring fields (optional — populated when full ScoringSettings
 * and RosterSettings are available, e.g. after Sleeper import).
 * The valuation engine uses them for richer derivations when present
 * and degrades gracefully to flag-based estimates when absent.
 */
export interface FormatContext {
  // ─── Core flags (always required) ────────────────────────────────────────
  superflex:    boolean;
  tePremium:    boolean;
  idpEnabled:   boolean;
  leagueSize:   number;
  starterCounts?: Partial<Record<string, number>>;

  // ─── Extended scoring (optional, from ScoringSettings) ───────────────────
  /** PPR amount: 0 = standard, 0.5 = half-PPR, 1 = full PPR */
  ppr?: number;
  /** Passing TD point value (e.g. 4 or 6) — from rawScoring.pass_td */
  passTdPoints?: number;

  // ─── Extended roster structure (optional, from RosterSettings) ────────────
  /** Total bench slots (for scarcity / replacement-rank calculation) */
  benchSlots?: number;
  /** Positions eligible for FLEX slot */
  flexPositions?: string[];
  /** Positions eligible for SUPER_FLEX slot */
  superflexPositions?: string[];

  // ─── IDP scoring detail (optional, when idpEnabled = true) ───────────────
  idpScoring?: {
    tacklePoints:  number;
    sackPoints:    number;
    intPoints:     number;
    passDefPoints: number;
    tdPoints:      number;
  };
}
