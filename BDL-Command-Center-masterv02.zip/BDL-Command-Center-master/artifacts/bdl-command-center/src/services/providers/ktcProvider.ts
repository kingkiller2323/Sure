/**
 * ktcProvider.ts — KTC market value provider.
 *
 * Fetches from GET /api/ktc-values (backend, served via Vite proxy).
 * The frontend never calls KTC directly — all scraping stays server-side.
 *
 * Response shape: { players: KtcApiRecord[], meta: { lastUpdated, stale, refreshing } }
 *
 * playerId strategy:
 *   Primary key:   "ktc:<normalized-name>-<pos>"
 *   Secondary key: stored in a parallel map keyed by "<normalized-name>|<pos>"
 *   → valuation.ts can look up by name+position when sleeper-ID lookup misses.
 *
 * IDP positions are excluded — IDP values come from the VORP engine only.
 */

import { normalizePosition, normalizePlayerName } from "../../utils/normalize";
import type { FormatContext, PlayerMarketValue, ProviderResult } from "./types";

export interface KtcApiRecord {
  playerName: string;
  position:   string;
  team:       string;
  age:        number;
  value:      number;
  sfValue:    number;
}

interface KtcApiResponse {
  players?:  KtcApiRecord[];
  data?:     KtcApiRecord[];     // legacy shape support
  meta?: {
    lastUpdated: string | null;
    stale:       boolean;
    refreshing:  boolean;
  };
  error?: string;
}

function apiUrl(): string {
  const base =
    typeof import.meta !== "undefined"
      ? ((import.meta as any).env?.VITE_API_BASE ?? "")
      : "";
  return `${base}/api/ktc-values`;
}

/** IDP positions — excluded from KTC feed; handled by VORP engine */
const IDP_POSITIONS = new Set(["DL","LB","DB"]);

function normaliseRecord(raw: KtcApiRecord, ctx: FormatContext): PlayerMarketValue | null {
  try {
    const name = raw.playerName?.trim();
    const pos  = normalizePosition(raw.position ?? "");
    if (!name || !pos) return null;
    if (IDP_POSITIONS.has(pos)) return null;   // IDP → VORP only

    const baseValue = ctx.superflex && raw.sfValue > 0 ? raw.sfValue : raw.value;
    if (baseValue <= 0) return null;

    return {
      playerId:    `ktc:${normalizePlayerName(name)}-${pos.toLowerCase()}`,
      name,
      position:    pos,
      team:        raw.team ?? "",
      age:         raw.age ?? 0,
      marketValue: raw.value,
      sfValue:     raw.sfValue > 0 ? raw.sfValue : undefined,
      source:      "ktc",
      format:      ctx.superflex ? "dynasty_sf" : "dynasty_1qb",
    };
  } catch {
    return null;
  }
}

export async function getMarketPlayerValues(
  ctx: FormatContext
): Promise<ProviderResult<PlayerMarketValue>> {
  try {
    const res = await fetch(apiUrl(), { signal: AbortSignal.timeout(15_000) });

    if (!res.ok) {
      return {
        data:   [],
        source: "ktc",
        loaded: false,
        error:  `Backend returned HTTP ${res.status}`,
      };
    }

    const json: KtcApiResponse = await res.json();
    // Support both new shape (players) and legacy shape (data)
    const records: KtcApiRecord[] = json.players ?? json.data ?? [];

    if (records.length === 0) {
      return {
        data:   [],
        source: "ktc",
        loaded: false,
        error:  json.error ?? "KTC data not yet available — scrape pending",
      };
    }

    const players: PlayerMarketValue[] = [];
    const seen = new Set<string>();

    for (const raw of records) {
      const item = normaliseRecord(raw, ctx);
      if (!item || seen.has(item.playerId)) continue;
      seen.add(item.playerId);
      players.push(item);
    }

    return { data: players, source: "ktc", loaded: true };
  } catch (err: unknown) {
    return {
      data:   [],
      source: "ktc",
      loaded: false,
      error:  `KTC provider fetch failed: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}
