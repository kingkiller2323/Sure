/**
 * idpProvider.ts — IDP dynasty ranking provider (frontend).
 *
 * Fetches from GET /api/idp-rankings (backend seed, served via Vite proxy).
 * The frontend never reads the seed file directly.
 *
 * Player key format: "idp:{normalized-name}-{pos}"
 *   e.g. "idp:micah parsons-lb"
 *
 * This key is what valuation.ts uses for the IDP secondary lookup.
 */

import { normalizePlayerName } from "../../utils/normalize";
import type { FormatContext, PlayerMarketValue, ProviderResult } from "./types";

interface IdpApiRecord {
  playerName: string;
  position:   string;
  team:       string;
  age:        number;
  value:      number;
}

interface IdpApiResponse {
  players?: IdpApiRecord[];
  meta?:    { source: string; count: number; lastLoaded: string | null };
  error?:   string;
}

function apiUrl(): string {
  const base =
    typeof import.meta !== "undefined"
      ? ((import.meta as any).env?.VITE_API_BASE ?? "")
      : "";
  return `${base}/api/idp-rankings`;
}

const IDP_POSITIONS = new Set(["DL", "LB", "DB"]);

function normaliseRecord(raw: IdpApiRecord): PlayerMarketValue | null {
  try {
    const name = raw.playerName?.trim();
    const pos  = (raw.position ?? "").trim().toUpperCase();
    if (!name || !IDP_POSITIONS.has(pos)) return null;
    if (raw.value <= 0) return null;

    return {
      playerId:    `idp:${normalizePlayerName(name)}-${pos.toLowerCase()}`,
      name,
      position:    pos,
      team:        raw.team ?? "",
      age:         raw.age ?? 0,
      marketValue: raw.value,
      source:      "idp_seed",
      format:      "idp",
    };
  } catch {
    return null;
  }
}

export async function getIdpPlayerValues(
  _ctx: FormatContext
): Promise<ProviderResult<PlayerMarketValue>> {
  try {
    const res = await fetch(apiUrl(), { signal: AbortSignal.timeout(10_000) });
    if (!res.ok) {
      return {
        data: [], source: "idp_seed", loaded: false,
        error: `Backend returned HTTP ${res.status}`,
      };
    }

    const json: IdpApiResponse = await res.json();
    const records = json.players ?? [];

    if (records.length === 0) {
      return {
        data: [], source: "idp_seed", loaded: false,
        error: json.error ?? "IDP seed returned no players",
      };
    }

    const players: PlayerMarketValue[] = [];
    const seen = new Set<string>();
    for (const raw of records) {
      const item = normaliseRecord(raw);
      if (!item || seen.has(item.playerId)) continue;
      seen.add(item.playerId);
      players.push(item);
    }

    return { data: players, source: "idp_seed", loaded: true };
  } catch (err: unknown) {
    return {
      data: [], source: "idp_seed", loaded: false,
      error: `IDP provider fetch failed: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}
