/**
 * consensus.ts
 *
 * Aggregates all provider results into a single ConsensusData lookup map.
 *
 * Sources aggregated:
 *   - KTC market values  (offensive: QB/RB/WR/TE)     key: "ktc:{name}-{pos}"
 *   - IDP seed rankings  (defensive: DL/LB/DB)         key: "idp:{name}-{pos}"
 *   - FantasyPros dynasty consensus ranks               key: varies by source
 *   - FantasyPros rookie consensus ranks
 *
 * IDP market values now come from the IDP seed (backend).
 * IDP VORP adjustments continue to be applied in valuation.ts.
 */

import { getMarketPlayerValues }    from "./providers/ktcProvider";
import { getIdpPlayerValues }       from "./providers/idpProvider";
import { getConsensusDynastyRanks } from "./providers/fantasyProsDynastyProvider";
import { getConsensusRookieRanks }  from "./providers/fantasyProsRookieProvider";
import { CURRENT_ROOKIE_CLASS }     from "../config/dataSources";
import type {
  DynastyConsensusRank,
  FormatContext,
  PlayerMarketValue,
  ProviderResult,
  RookieConsensusRank,
} from "./providers/types";

export interface ProviderStatus {
  name:   string;
  loaded: boolean;
  error?: string;
}

export interface ConsensusData {
  /** playerId → market value
   *  Offensive: "ktc:{name}-{pos}" entries (KTC)
   *  Defensive: "idp:{name}-{pos}" entries (IDP seed) */
  marketValues:    Map<string, PlayerMarketValue>;
  /** playerId → dynasty consensus rank */
  dynastyRanks:    Map<string, DynastyConsensusRank>;
  /** playerId → rookie consensus rank */
  rookieRanks:     Map<string, RookieConsensusRank>;
  providerStatus:  ProviderStatus[];
  hasMarketData:   boolean;    // KTC loaded successfully
  hasIdpData:      boolean;    // IDP seed loaded successfully
  hasRankData:     boolean;
}

let _cache: ConsensusData | null = null;
let _cacheKey = "";

function cacheKey(ctx: FormatContext, classYear: number): string {
  return JSON.stringify(ctx) + "|" + classYear;
}

export function invalidateConsensusCache(): void {
  _cache    = null;
  _cacheKey = "";
}

export async function loadConsensusData(
  ctx: FormatContext,
  classYear: number = CURRENT_ROOKIE_CLASS
): Promise<ConsensusData> {
  const key = cacheKey(ctx, classYear);
  if (_cache && _cacheKey === key) return _cache;

  function unwrap<T>(s: PromiseSettledResult<ProviderResult<T>>): ProviderResult<T> {
    return s.status === "fulfilled"
      ? s.value
      : { data: [], source: "unknown", loaded: false,
          error: String((s as PromiseRejectedResult).reason) };
  }

  const [ktcS, idpS, dynS, rkS] = await Promise.allSettled([
    getMarketPlayerValues(ctx),   // offensive KTC values
    getIdpPlayerValues(ctx),      // IDP seed values
    getConsensusDynastyRanks(ctx),
    getConsensusRookieRanks(classYear, ctx),
  ]);

  const ktc = unwrap(ktcS);
  const idp = unwrap(idpS);
  const dyn = unwrap(dynS);
  const rk  = unwrap(rkS);

  const marketValues = new Map<string, PlayerMarketValue>();
  const dynastyRanks = new Map<string, DynastyConsensusRank>();
  const rookieRanks  = new Map<string, RookieConsensusRank>();

  // KTC offensive values  (key: "ktc:{name}-{pos}")
  for (const item of ktc.data) {
    if (!marketValues.has(item.playerId)) marketValues.set(item.playerId, item);
  }

  // IDP seed values  (key: "idp:{name}-{pos}")
  for (const item of idp.data) {
    if (!marketValues.has(item.playerId)) marketValues.set(item.playerId, item);
  }

  for (const item of dyn.data) dynastyRanks.set(item.playerId, item);
  for (const item of rk.data)  rookieRanks.set(item.playerId, item);

  const data: ConsensusData = {
    marketValues,
    dynastyRanks,
    rookieRanks,
    providerStatus: [
      { name: ktc.source, loaded: ktc.loaded, error: ktc.error },
      { name: idp.source, loaded: idp.loaded, error: idp.error },
      { name: dyn.source, loaded: dyn.loaded, error: dyn.error },
      { name: rk.source,  loaded: rk.loaded,  error: rk.error  },
    ],
    hasMarketData: ktc.loaded,
    hasIdpData:    idp.loaded,
    hasRankData:   dyn.loaded || rk.loaded,
  };

  _cache    = data;
  _cacheKey = key;
  return data;
}
