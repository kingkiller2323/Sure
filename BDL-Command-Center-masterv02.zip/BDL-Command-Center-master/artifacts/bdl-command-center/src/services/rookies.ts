/**
 * rookies.ts — Rookie board data service.
 *
 * Fetches rookie consensus data from the configured provider,
 * deduplicates by canonical playerId (first/highest-ranked occurrence wins),
 * and returns a clean sorted list ready for the Draft Board tab.
 *
 * When the provider is not yet connected, returns an empty list with a
 * clear ProviderStatus so the UI can show an actionable empty state.
 */

import { getConsensusRookieRanks } from "./providers/fantasyProsRookieProvider";
import { CURRENT_ROOKIE_CLASS }    from "../config/dataSources";
import type { FormatContext, RookieConsensusRank } from "./providers/types";

export interface RookieBoard {
  players: RookieConsensusRank[];
  classYear: number;
  loaded: boolean;
  source: string;
  error?: string;
}

/**
 * Load the rookie board for the given class year.
 * Deduplication is handled inside the provider — this layer only adds
 * sorting and a clean return shape.
 */
export async function loadRookieBoard(
  fmt: FormatContext,
  classYear: number = CURRENT_ROOKIE_CLASS
): Promise<RookieBoard> {
  const result = await getConsensusRookieRanks(classYear, fmt);

  const players = [...result.data].sort(
    (a, b) => a.consensusRank - b.consensusRank
  );

  return {
    players,
    classYear,
    loaded: result.loaded,
    source: result.source,
    error:  result.error,
  };
}

/**
 * Filter a rookie board by position.
 * Pass "ALL" to return every player.
 */
export function filterRookieBoard(
  board: RookieBoard,
  positionFilter: string
): RookieConsensusRank[] {
  if (positionFilter === "ALL") return board.players;
  return board.players.filter((p) => p.position === positionFilter);
}
