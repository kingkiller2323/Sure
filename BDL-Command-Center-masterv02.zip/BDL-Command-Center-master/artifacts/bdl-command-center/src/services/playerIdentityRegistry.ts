/**
 * playerIdentityRegistry.ts — Bridges Sleeper player IDs to existing KTC/IDP market values.
 *
 * Problem:
 *   valuation.ts first tries `sleeper:{id}` lookup, which always misses because
 *   consensus.marketValues only contains `ktc:{name}-{pos}` and `idp:{name}-{pos}` keys.
 *
 * Solution:
 *   After BOTH Sleeper players AND consensus data are loaded, build a bridge:
 *   - For each Sleeper player, compute normalized name + position
 *   - Check if a matching `ktc:{name}-{pos}` or `idp:{name}-{pos}` key exists
 *   - If found, inject a `sleeper:{id}` entry pointing to the same market value
 *
 * This allows primary lookups to succeed without changing valuation.ts logic.
 *
 * IMPORTANT:
 *   - Uses ONLY normalizePlayerName and normalizePosition from utils/normalize.ts
 *   - Does NOT add new normalization functions
 *   - Does NOT change existing key formats
 *   - Does NOT change valuation.ts
 */

import { normalizePlayerName, normalizePosition } from "../utils/normalize";
import type { ConsensusData, ProviderStatus } from "./consensus";
import type { PlayerMarketValue } from "./providers/types";

/** Minimal player record from Sleeper */
export interface SleeperPlayerRecord {
  id: string;
  firstName: string;
  lastName: string;
  position: string;
  team?: string;
  age?: number;
}

/** Statistics from the bridge operation */
export interface BridgeStats {
  sleeperPlayersProcessed: number;
  ktcMatches: number;
  idpMatches: number;
  duplicateSkipped: number;
  noMatch: number;
  exampleMatches: { sleeperId: string; name: string; matchedKey: string }[];
}

/**
 * Determine if a position is IDP.
 */
function isIdpPosition(pos: string): boolean {
  return ["DL", "LB", "DB"].includes(pos.toUpperCase());
}

/**
 * Build the bridge from Sleeper IDs to existing market value entries.
 *
 * @param sleeperPlayers - Map of Sleeper player ID to player data
 * @param consensus - The consensus data containing marketValues map
 * @returns Updated consensus data with injected sleeper:{id} keys, plus stats
 */
export function buildSleeperIdBridge(
  sleeperPlayers: Record<string, SleeperPlayerRecord>,
  consensus: ConsensusData
): { consensus: ConsensusData; stats: BridgeStats } {
  const stats: BridgeStats = {
    sleeperPlayersProcessed: 0,
    ktcMatches: 0,
    idpMatches: 0,
    duplicateSkipped: 0,
    noMatch: 0,
    exampleMatches: [],
  };

  // Create a new map that includes all existing entries
  const updatedMarketValues = new Map<string, PlayerMarketValue>(consensus.marketValues);

  for (const [sleeperId, player] of Object.entries(sleeperPlayers)) {
    stats.sleeperPlayersProcessed++;

    const sleeperKey = `sleeper:${sleeperId}`;

    // Skip if sleeper:{id} already exists (duplicate prevention)
    if (updatedMarketValues.has(sleeperKey)) {
      stats.duplicateSkipped++;
      continue;
    }

    const name = `${player.firstName} ${player.lastName}`.trim();
    if (!name) continue;

    const normalizedName = normalizePlayerName(name);
    const normalizedPos = normalizePosition(player.position);

    // Skip positions we don't value
    if (!["QB", "RB", "WR", "TE", "DL", "LB", "DB", "K"].includes(normalizedPos)) {
      continue;
    }

    // Try to find a matching entry
    let matchedKey: string | null = null;
    let matchedValue: PlayerMarketValue | null = null;

    if (isIdpPosition(normalizedPos)) {
      // Try IDP key first for defensive positions
      const idpKey = `idp:${normalizedName}-${normalizedPos.toLowerCase()}`;
      const idpMatch = consensus.marketValues.get(idpKey);
      if (idpMatch) {
        matchedKey = idpKey;
        matchedValue = idpMatch;
        stats.idpMatches++;
      }
    } else {
      // Try KTC key for offensive positions
      const ktcKey = `ktc:${normalizedName}-${normalizedPos.toLowerCase()}`;
      const ktcMatch = consensus.marketValues.get(ktcKey);
      if (ktcMatch) {
        matchedKey = ktcKey;
        matchedValue = ktcMatch;
        stats.ktcMatches++;
      }
    }

    if (matchedValue && matchedKey) {
      // Inject sleeper:{id} entry with the same market value data
      // but update the playerId to be the sleeper key
      updatedMarketValues.set(sleeperKey, {
        ...matchedValue,
        playerId: sleeperKey,
      });

      // Capture example matches (first 5)
      if (stats.exampleMatches.length < 5) {
        stats.exampleMatches.push({
          sleeperId,
          name,
          matchedKey,
        });
      }
    } else {
      stats.noMatch++;
    }
  }

  // Return updated consensus with injected entries
  return {
    consensus: {
      ...consensus,
      marketValues: updatedMarketValues,
    },
    stats,
  };
}

/**
 * Convert raw Sleeper player data to SleeperPlayerRecord format.
 * This is the expected shape from fetchAllPlayers().
 */
export function convertSleeperPlayers(
  rawPlayers: Record<string, {
    first_name?: string;
    last_name?: string;
    position?: string;
    fantasy_positions?: string[];
    team?: string;
    age?: number;
  }>
): Record<string, SleeperPlayerRecord> {
  const result: Record<string, SleeperPlayerRecord> = {};

  for (const [id, p] of Object.entries(rawPlayers)) {
    const pos = normalizePosition(p.fantasy_positions?.[0] ?? p.position ?? "");
    if (!pos) continue;

    result[id] = {
      id,
      firstName: p.first_name ?? "",
      lastName: p.last_name ?? "",
      position: pos,
      team: p.team,
      age: p.age,
    };
  }

  return result;
}

/**
 * Log bridge statistics to console.
 */
export function logBridgeStats(stats: BridgeStats): void {
  console.log("[PlayerIdentityRegistry] ─── Bridge Statistics ─────────────────────");
  console.log(`[PlayerIdentityRegistry]   Sleeper players processed: ${stats.sleeperPlayersProcessed}`);
  console.log(`[PlayerIdentityRegistry]   KTC matches (offensive): ${stats.ktcMatches}`);
  console.log(`[PlayerIdentityRegistry]   IDP matches (defensive): ${stats.idpMatches}`);
  console.log(`[PlayerIdentityRegistry]   Duplicates skipped: ${stats.duplicateSkipped}`);
  console.log(`[PlayerIdentityRegistry]   No match (formula fallback): ${stats.noMatch}`);
  console.log(`[PlayerIdentityRegistry]   Total bridged entries: ${stats.ktcMatches + stats.idpMatches}`);

  if (stats.exampleMatches.length > 0) {
    console.log(`[PlayerIdentityRegistry]   Example matches:`);
    for (const ex of stats.exampleMatches) {
      console.log(`[PlayerIdentityRegistry]     sleeper:${ex.sleeperId} → ${ex.matchedKey} (${ex.name})`);
    }
  }
  console.log("[PlayerIdentityRegistry] ────────────────────────────────────────────");
}
