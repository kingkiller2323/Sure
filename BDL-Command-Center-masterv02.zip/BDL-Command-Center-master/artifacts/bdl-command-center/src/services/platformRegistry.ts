/**
 * platformRegistry.ts
 *
 * Single source of truth for all platform adapters.
 * The UI selects adapters dynamically via this registry.
 * Zero platform-specific logic lives in UI code.
 *
 * To add a new platform:
 *   1. Create /services/platforms/<name>.ts implementing PlatformAdapter.
 *   2. Import and register it here.
 *   3. Done — the UI picks it up automatically.
 */

import type { PlatformAdapter, PlatformDescriptor } from "../interfaces/platformAdapter";
import { sleeperAdapter } from "./platforms/sleeper";
import { yahooAdapter }   from "./platforms/yahoo";
import { espnAdapter }    from "./platforms/espn";
import { nflAdapter }     from "./platforms/nfl";
import { manualAdapter }  from "./platforms/manual";

// ─── Registry ─────────────────────────────────────────────────────────────────

const REGISTRY = new Map<string, PlatformAdapter>([
  ["sleeper", sleeperAdapter],
  ["yahoo",   yahooAdapter],
  ["espn",    espnAdapter],
  ["nfl",     nflAdapter],
  ["manual",  manualAdapter],
]);

/** Look up a platform adapter by its platformId */
export function getAdapter(platformId: string): PlatformAdapter | null {
  return REGISTRY.get(platformId) ?? null;
}

/** All registered adapters */
export function getAllAdapters(): PlatformAdapter[] {
  return [...REGISTRY.values()];
}

// ─── Descriptors (for UI rendering — no logic) ────────────────────────────────

const DESCRIPTORS: PlatformDescriptor[] = [
  {
    platformId:  "sleeper",
    displayName: "Sleeper",
    icon:        "💤",
    status:      "working",
    accessMode:  "leagueId",
    description: "Paste your league ID. No account needed.",
  },
  {
    platformId:  "yahoo",
    displayName: "Yahoo Fantasy",
    icon:        "🟣",
    status:      "scaffolded",
    accessMode:  "oauth",
    description: "Requires Yahoo OAuth. Coming soon.",
  },
  {
    platformId:  "espn",
    displayName: "ESPN Fantasy",
    icon:        "🏈",
    status:      "scaffolded",
    accessMode:  "leagueId",
    description: "Public leagues via league ID. Private via session cookies. Coming soon.",
  },
  {
    platformId:  "nfl",
    displayName: "NFL Fantasy",
    icon:        "🏟️",
    status:      "unsupported",
    accessMode:  "unsupported",
    description: "No reliable API available. Export to Sleeper or use manual entry.",
  },
  {
    platformId:  "manual",
    displayName: "Manual Entry",
    icon:        "✏️",
    status:      "working",
    accessMode:  "leagueId",
    description: "Fallback only — enter league settings manually.",
  },
];

/** All platform descriptors — safe to pass directly to UI components */
export function getPlatformDescriptors(): PlatformDescriptor[] {
  return DESCRIPTORS;
}

export function getDescriptor(platformId: string): PlatformDescriptor | null {
  return DESCRIPTORS.find(d => d.platformId === platformId) ?? null;
}

/** Only adapters the user can actually use today */
export function getWorkingAdapters(): PlatformDescriptor[] {
  return DESCRIPTORS.filter(d => d.status === "working");
}

/** Scaffolded adapters (visible but not yet functional) */
export function getScaffoldedAdapters(): PlatformDescriptor[] {
  return DESCRIPTORS.filter(d => d.status === "scaffolded");
}

/** Unsupported adapters */
export function getUnsupportedAdapters(): PlatformDescriptor[] {
  return DESCRIPTORS.filter(d => d.status === "unsupported");
}
