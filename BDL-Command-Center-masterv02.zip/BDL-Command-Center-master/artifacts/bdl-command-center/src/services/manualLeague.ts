/**
 * manualLeague.ts — backward-compat re-export shim.
 * Real implementation lives in platforms/manual.ts.
 * App.tsx imports from here; do not delete this file.
 */

export type {
  ManualLeagueForm as ManualLeagueSettings,
} from "./platforms/manual";

export {
  defaultManualForm as defaultManualSettings,
  saveManualForm,
  loadManualForm,
} from "./platforms/manual";

import type { ManualLeagueForm } from "./platforms/manual";
import { formToNormalizedData }  from "./platforms/manual";
import type { FormatContext }    from "./providers/types";

/** Convert manual settings to FormatContext used by the valuation engine */
export function manualSettingsToFormatContext(f: ManualLeagueForm): FormatContext {
  return {
    superflex:          f.superflex,
    tePremium:          f.tePremium,
    idpEnabled:         f.idpEnabled,
    leagueSize:         f.leagueSize,
    starterCounts:      f.starterCounts,
    ppr:                1,                                // manual leagues default full-PPR
    passTdPoints:       f.superflex ? 6 : 4,             // superflex leagues tend toward 6pt
    benchSlots:         6,
    flexPositions:      ["RB", "WR", "TE"],
    superflexPositions: f.superflex ? ["QB", "RB", "WR", "TE"] : [],
  };
}
