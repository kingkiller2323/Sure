/**
 * nfl.ts — NFL.com Fantasy platform adapter.
 *
 * STATUS: UNSUPPORTED
 *
 * NFL.com does not expose a reliable public or documented API for fantasy
 * league data. Their internal APIs change frequently and cannot be depended
 * on for a production integration.
 *
 * This file exists to fulfil the adapter registry contract and to surface
 * a clear, actionable error when the user selects NFL.
 *
 * If a reliable NFL Fantasy API becomes available in the future, implement
 * this adapter without touching any other file.
 */

import type { PlatformAdapter }     from "../../interfaces/platformAdapter";
import type { NormalizedLeagueData, LeagueSettings, NormalizedRoster, NormalizedDraftPick, NormalizedPlayer } from "../../types/NormalizedLeagueData";

const UNSUPPORTED = () =>
  Promise.reject(new Error(
    "NFL Fantasy is not supported — no reliable API exists. " +
    "Export your league to Sleeper or use manual entry."
  ));

export class NflAdapter implements PlatformAdapter {
  readonly platformId  = "nfl";
  readonly displayName = "NFL Fantasy";
  readonly status      = "unsupported" as const;

  getAccessMode()              { return "unsupported" as const; }
  canFetchPubliclyByLeagueId() { return false; }
  requiresExternalAuth()       { return false; }
  requiresSessionCookies()     { return false; }

  fetchLeagueSettings(): Promise<LeagueSettings>                              { return UNSUPPORTED(); }
  fetchLeagueRosters(): Promise<NormalizedRoster[]>                            { return UNSUPPORTED(); }
  fetchLeaguePicks(): Promise<NormalizedDraftPick[]>                            { return UNSUPPORTED(); }
  fetchPlayers(): Promise<Record<string, NormalizedPlayer>>                    { return UNSUPPORTED(); }
  normalizeLeagueData(): Promise<NormalizedLeagueData>                          { return UNSUPPORTED(); }
}

export const nflAdapter = new NflAdapter();
