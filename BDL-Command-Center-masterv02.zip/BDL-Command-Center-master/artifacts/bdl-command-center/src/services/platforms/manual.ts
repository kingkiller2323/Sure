/**
 * manual.ts — Manual entry adapter (fallback only).
 *
 * STATUS: WORKING (as a fallback path only)
 *
 * This adapter is the last resort when no platform import is possible.
 * It is NEVER the primary workflow. It converts a user-filled form into
 * NormalizedLeagueData so the analytics engine sees the same shape.
 *
 * Manual entry does NOT support:
 *   - Player universe import (user must add players individually)
 *   - Automatic roster sync
 *   - Pick tracking
 *
 * These limitations are intentional — manual entry is for edge cases only.
 */

import type { PlatformAdapter }     from "../../interfaces/platformAdapter";
import type { NormalizedLeagueData, LeagueSettings, NormalizedRoster, NormalizedDraftPick, NormalizedPlayer, RosterSettings, ScoringSettings } from "../../types/NormalizedLeagueData";

// ─── Manual league form types (public API) ─────────────────────────────────────

export interface ManualLeagueForm {
  name:         string;
  platform:     string;
  season:       number;
  leagueSize:   number;
  superflex:    boolean;
  tePremium:    boolean;
  idpEnabled:   boolean;
  playoffTeams: number;
  taxiSlots:    number;
  irSlots:      number;
  starterCounts: Partial<Record<string, number>>;
}

export function defaultManualForm(): ManualLeagueForm {
  return {
    name:          "My League",
    platform:      "Other",
    season:        new Date().getFullYear(),
    leagueSize:    12,
    superflex:     false,
    tePremium:     false,
    idpEnabled:    false,
    playoffTeams:  6,
    taxiSlots:     3,
    irSlots:       1,
    starterCounts: { QB:1, RB:2, WR:3, TE:1, FLEX:1 },
  };
}

export function formToNormalizedData(form: ManualLeagueForm): NormalizedLeagueData {
  const rosterSettings: RosterSettings = {
    starterCounts:      form.starterCounts,
    benchSlots:         6,
    taxiSlots:          form.taxiSlots,
    irSlots:            form.irSlots,
    flexPositions:      ["RB","WR","TE"],
    superflexPositions: form.superflex ? ["QB","RB","WR","TE"] : [],
  };

  const scoringSettings: ScoringSettings = {
    superflex:  form.superflex,
    tePremium:  form.tePremium,
    idpEnabled: form.idpEnabled,
    ppr:        1,
    rawScoring: {
      rec:    1,
      rec_te: form.tePremium ? 1.5 : 1,
    },
  };

  const settings: LeagueSettings = {
    leagueId:     `manual:${Date.now()}`,
    platformId:   "manual",
    name:         form.name,
    season:       String(form.season),
    leagueSize:   form.leagueSize,
    playoffTeams: form.playoffTeams,
    type:         "dynasty",
    rosterSettings,
    scoringSettings,
  };

  return {
    leagueSettings:  settings,
    rosterSettings,
    scoringSettings,
    teams:      [],
    rosters:    [],
    draftPicks: [],
    players:    {},
    fetchedAt:  new Date().toISOString(),
  };
}

/** Persist/load form from localStorage — no user accounts involved */
const STORAGE_KEY = "manual_league_form";
export function saveManualForm(f: ManualLeagueForm): void {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(f)); } catch {}
}
export function loadManualForm(): ManualLeagueForm | null {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "null"); } catch { return null; }
}

// ─── Adapter implementation ────────────────────────────────────────────────────

export class ManualAdapter implements PlatformAdapter {
  readonly platformId  = "manual";
  readonly displayName = "Manual Entry";
  readonly status      = "working" as const;

  getAccessMode()              { return "leagueId" as const; }
  canFetchPubliclyByLeagueId() { return false; }
  requiresExternalAuth()       { return false; }
  requiresSessionCookies()     { return false; }

  private form: ManualLeagueForm = defaultManualForm();

  setForm(f: ManualLeagueForm): void { this.form = f; }

  fetchLeagueSettings(): Promise<LeagueSettings> {
    return Promise.resolve(formToNormalizedData(this.form).leagueSettings);
  }
  fetchLeagueRosters(): Promise<NormalizedRoster[]>                            { return Promise.resolve([]); }
  fetchLeaguePicks(): Promise<NormalizedDraftPick[]>                            { return Promise.resolve([]); }
  fetchPlayers(): Promise<Record<string, NormalizedPlayer>>                    { return Promise.resolve({}); }
  normalizeLeagueData(): Promise<NormalizedLeagueData> {
    return Promise.resolve(formToNormalizedData(this.form));
  }
}

export const manualAdapter = new ManualAdapter();
