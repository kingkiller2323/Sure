/**
 * espn.ts — ESPN Fantasy platform adapter.
 *
 * STATUS: SCAFFOLDED — public leagues via leagueId;
 *                       private leagues via session cookies.
 *
 * ESPN Fantasy API (unofficial):
 *   Public:  https://fantasy.espn.com/apis/v3/games/ffl/seasons/{year}/segments/0/leagues/{leagueId}
 *   Private: Same URL + cookies: espn_s2 + SWID headers.
 *
 * Private league access:
 *   User provides espn_s2 and SWID cookies from their browser session.
 *   These are passed as headers in the adapter — never stored in the app.
 *   The app has zero account system; this is purely platform auth.
 *
 * TODO: Implement ESPN response normalisation.
 */

import type { PlatformAdapter }     from "../../interfaces/platformAdapter";
import type { NormalizedLeagueData, LeagueSettings, NormalizedRoster, NormalizedDraftPick, NormalizedPlayer } from "../../types/NormalizedLeagueData";

const NOT_IMPLEMENTED = () =>
  Promise.reject(new Error("ESPN adapter is scaffolded — not yet implemented"));

export interface EspnSessionCredentials {
  espn_s2: string;
  SWID:    string;
}

export class EspnAdapter implements PlatformAdapter {
  readonly platformId  = "espn";
  readonly displayName = "ESPN Fantasy";
  readonly status      = "planned" as const;

  private creds?: EspnSessionCredentials;

  getAccessMode() {
    return (this.creds ? "session" : "leagueId") as "leagueId" | "session";
  }
  canFetchPubliclyByLeagueId() { return true; }
  requiresExternalAuth()       { return false; }
  requiresSessionCookies()     { return true; }   // needed for private leagues

  /** Call before normalizeLeagueData to enable private league access */
  setSessionCredentials(creds: EspnSessionCredentials): void {
    this.creds = creds;
  }

  /** Build the ESPN API URL for a league */
  private apiUrl(leagueId: string, year = new Date().getFullYear()): string {
    return `https://fantasy.espn.com/apis/v3/games/ffl/seasons/${year}/segments/0/leagues/${leagueId}`;
  }

  /** Build headers — adds session cookies when provided */
  private headers(): Record<string, string> {
    const h: Record<string, string> = { "Content-Type": "application/json" };
    if (this.creds) {
      h["Cookie"] = `espn_s2=${this.creds.espn_s2}; SWID=${this.creds.SWID}`;
    }
    return h;
  }

  fetchLeagueSettings(_id: string, _token?: string): Promise<LeagueSettings>           { return NOT_IMPLEMENTED(); }
  fetchLeagueRosters(_id: string, _token?: string): Promise<NormalizedRoster[]>         { return NOT_IMPLEMENTED(); }
  fetchLeaguePicks(_id: string, _token?: string): Promise<NormalizedDraftPick[]>         { return NOT_IMPLEMENTED(); }
  fetchPlayers(_id: string, _token?: string): Promise<Record<string, NormalizedPlayer>> { return NOT_IMPLEMENTED(); }
  normalizeLeagueData(_id: string, _token?: string): Promise<NormalizedLeagueData>       { return NOT_IMPLEMENTED(); }
}

export const espnAdapter = new EspnAdapter();
