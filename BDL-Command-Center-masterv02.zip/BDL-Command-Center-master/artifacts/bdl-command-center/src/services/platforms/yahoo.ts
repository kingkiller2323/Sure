/**
 * yahoo.ts — Yahoo Fantasy platform adapter.
 *
 * STATUS: SCAFFOLDED — OAuth flow is isolated here.
 * The UI never touches Yahoo-specific logic.
 *
 * Yahoo requires OAuth 2.0.  When implemented:
 *   1. User clicks "Connect Yahoo" in the UI.
 *   2. UI calls adapter.initiateOAuth() → gets redirect URL.
 *   3. After redirect back, UI calls adapter.handleOAuthCallback(code).
 *   4. Adapter exchanges code for token internally.
 *   5. All subsequent calls use the stored token — user never sees it.
 *
 * The app itself never stores accounts, credentials, or billing data.
 * Yahoo auth tokens are stored only in sessionStorage, scoped to the tab.
 *
 * TODO: Implement Yahoo Fantasy Public API calls.
 *   Base: https://fantasysports.yahooapis.com/fantasy/v2/
 *   Docs: https://developer.yahoo.com/fantasysports/guide/
 */

import type { PlatformAdapter }     from "../../interfaces/platformAdapter";
import type { NormalizedLeagueData, LeagueSettings, NormalizedRoster, NormalizedDraftPick, NormalizedPlayer } from "../../types/NormalizedLeagueData";

const NOT_IMPLEMENTED = () =>
  Promise.reject(new Error("Yahoo adapter is scaffolded — not yet implemented"));

export class YahooAdapter implements PlatformAdapter {
  readonly platformId  = "yahoo";
  readonly displayName = "Yahoo Fantasy";
  readonly status      = "planned" as const;

  getAccessMode()              { return "oauth" as const; }
  canFetchPubliclyByLeagueId() { return false; }
  requiresExternalAuth()       { return true; }
  requiresSessionCookies()     { return false; }

  /**
   * Returns the Yahoo OAuth authorization URL.
   * Client ID must be provided via environment (no hardcoded secrets).
   */
  getOAuthUrl(clientId: string, redirectUri: string): string {
    const params = new URLSearchParams({
      client_id:     clientId,
      redirect_uri:  redirectUri,
      response_type: "code",
      scope:         "fspt-r",
    });
    return `https://api.login.yahoo.com/oauth2/request_auth?${params}`;
  }

  /**
   * Exchange an OAuth code for a token.
   * TODO: This should call a backend endpoint that holds the client_secret.
   * The secret must NEVER be in frontend code.
   */
  async handleOAuthCallback(_code: string): Promise<string> {
    throw new Error(
      "Yahoo OAuth exchange must be completed via a backend endpoint " +
      "that holds the client_secret. Implement /api/yahoo/oauth/token."
    );
  }

  fetchLeagueSettings(_id: string, _token?: string): Promise<LeagueSettings>           { return NOT_IMPLEMENTED(); }
  fetchLeagueRosters(_id: string, _token?: string): Promise<NormalizedRoster[]>         { return NOT_IMPLEMENTED(); }
  fetchLeaguePicks(_id: string, _token?: string): Promise<NormalizedDraftPick[]>         { return NOT_IMPLEMENTED(); }
  fetchPlayers(_id: string, _token?: string): Promise<Record<string, NormalizedPlayer>> { return NOT_IMPLEMENTED(); }
  normalizeLeagueData(_id: string, _token?: string): Promise<NormalizedLeagueData>       { return NOT_IMPLEMENTED(); }
}

export const yahooAdapter = new YahooAdapter();
