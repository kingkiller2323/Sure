/**
 * sleeper.ts — Sleeper platform adapter.
 *
 * STATUS: WORKING — leagueId only, no auth required.
 *
 * All Sleeper API knowledge lives here.
 * Zero platform-specific logic may exist in the UI or analytics layers.
 */

import type { PlatformAdapter }      from "../../interfaces/platformAdapter";
import type { NormalizedLeagueData, NormalizedPlayer, NormalizedRoster, NormalizedDraftPick, LeagueSettings, RosterSettings, ScoringSettings } from "../../types/NormalizedLeagueData";
import { normalizePosition }         from "../../utils/normalize";

const SLEEPER_BASE  = "https://api.sleeper.app/v1";
const CORS_PROXY    = "https://corsproxy.io/?";

// ─── Raw Sleeper types ────────────────────────────────────────────────────────

export interface SleeperLeague {
  league_id:    string;
  name:         string;
  season:       string;
  status:       string;
  total_rosters: number;
  settings: {
    type:          number;
    playoff_teams: number;
    taxi_slots:    number;
    reserve_slots: number;
    num_teams:     number;
  };
  scoring_settings: Record<string, number>;
  roster_positions: string[];
}

export interface SleeperUser {
  user_id:      string;
  username:     string;
  display_name: string;
  metadata?:    { team_name?: string };
}

export interface SleeperRoster {
  roster_id:  number;
  owner_id:   string;
  players:    string[];
  starters:   string[];
  taxi?:      string[];
  reserve?:   string[];
  settings?: {
    wins:          number;
    losses:        number;
    ties?:         number;
    fpts:          number;
    fpts_decimal:  number;
  };
}

export interface SleeperMatchup {
  roster_id:  number;
  matchup_id: number;
  points:     number;
  starters:   string[];
}

export interface SleeperTransaction {
  type:     "trade" | "waiver" | "free_agent";
  created:  number;
  adds?:    Record<string, number>;
  drops?:   Record<string, number>;
}

export interface SleeperNflState {
  week:        number;
  season:      string;
  season_type: string;
}

export interface SleeperPlayer {
  first_name:        string;
  last_name:         string;
  position:          string;
  fantasy_positions?: string[];
  team?:             string;
  age?:              number;
  injury_status?:    string;
  status?:           string;
}

// ─── Internal fetch ───────────────────────────────────────────────────────────

async function sleeperFetch<T>(path: string): Promise<T> {
  const url = `${SLEEPER_BASE}${path}`;
  try {
    const res = await fetch(url);
    if (res.ok) return res.json() as Promise<T>;
  } catch { /* fall through to proxy */ }
  const proxy = await fetch(`${CORS_PROXY}${encodeURIComponent(url)}`);
  if (!proxy.ok) throw new Error(`Sleeper ${path} → HTTP ${proxy.status}`);
  return proxy.json() as Promise<T>;
}

// ─── Normalisation helpers ────────────────────────────────────────────────────

function primaryPos(p: SleeperPlayer): string {
  return normalizePosition(p.fantasy_positions?.[0] ?? p.position ?? "");
}

function rosterPositions(league: SleeperLeague): string[] {
  return league.roster_positions ?? [];
}

function deriveRosterSettings(league: SleeperLeague): RosterSettings {
  const positions = rosterPositions(league);
  const starterCounts: Partial<Record<string, number>> = {};
  let benchSlots = 0;

  for (const pos of positions) {
    if (pos === "BN") { benchSlots++; continue; }
    starterCounts[pos] = (starterCounts[pos] ?? 0) + 1;
  }

  const flexPositions = positions.includes("FLEX")
    ? ["RB", "WR", "TE"] : [];
  const sfPositions   = positions.includes("SUPER_FLEX")
    ? ["QB", "RB", "WR", "TE"] : [];

  return {
    starterCounts,
    benchSlots,
    taxiSlots:          league.settings?.taxi_slots ?? 0,
    irSlots:            league.settings?.reserve_slots ?? 0,
    flexPositions,
    superflexPositions: sfPositions,
  };
}

function deriveScoringSettings(league: SleeperLeague): ScoringSettings {
  const sc = league.scoring_settings ?? {};
  const positions = rosterPositions(league);

  const superflex = positions.filter(p => p === "SUPER_FLEX").length > 0
                 || positions.filter(p => p === "QB").length >= 2;
  const tePremium = (sc["rec_te"] ?? 0) > 0.5;
  const idpEnabled = positions.some(p => ["DL","LB","DB","IDP_FLEX"].includes(p));
  const ppr        = sc["rec"] ?? 0;

  const idpScoring = idpEnabled ? {
    tacklePoints:  sc["tackle_solo"] ?? sc["tkl_solo"] ?? 1,
    sackPoints:    sc["sack"] ?? 2,
    intPoints:     sc["int"] ?? 2,
    passDefPoints: sc["pass_defended"] ?? sc["pd"] ?? 1,
    tdPoints:      sc["def_td"] ?? sc["idp_def_td"] ?? 6,
  } : undefined;

  return {
    superflex,
    tePremium,
    idpEnabled,
    ppr,
    rawScoring: sc,
    idpScoring,
  };
}

// ─── Adapter implementation ───────────────────────────────────────────────────

export class SleeperAdapter implements PlatformAdapter {
  readonly platformId   = "sleeper";
  readonly displayName  = "Sleeper";
  readonly status       = "working" as const;

  getAccessMode()              { return "leagueId" as const; }
  canFetchPubliclyByLeagueId() { return true; }
  requiresExternalAuth()       { return false; }
  requiresSessionCookies()     { return false; }

  async fetchLeagueSettings(leagueId: string): Promise<LeagueSettings> {
    const [league, rosters] = await Promise.all([
      sleeperFetch<SleeperLeague>(`/league/${leagueId}`),
      sleeperFetch<SleeperRoster[]>(`/league/${leagueId}/rosters`),
    ]);
    const rs = deriveRosterSettings(league);
    const ss = deriveScoringSettings(league);
    return {
      leagueId,
      platformId:  "sleeper",
      name:        league.name,
      season:      league.season,
      leagueSize:  rosters.length || league.total_rosters,
      playoffTeams: league.settings?.playoff_teams ?? 6,
      type:         league.settings?.type === 2 ? "dynasty"
                  : league.settings?.type === 1 ? "keeper" : "redraft",
      rosterSettings:  rs,
      scoringSettings: ss,
    };
  }

  async fetchLeagueRosters(leagueId: string): Promise<NormalizedRoster[]> {
    const [users, rosters] = await Promise.all([
      sleeperFetch<SleeperUser[]>(`/league/${leagueId}/users`),
      sleeperFetch<SleeperRoster[]>(`/league/${leagueId}/rosters`),
    ]);
    const userMap = new Map(users.map(u => [u.user_id, u]));

    return rosters.map(r => {
      const u      = userMap.get(r.owner_id);
      const teamName = u?.metadata?.team_name ?? u?.display_name ?? `Team ${r.roster_id}`;
      const ownerName = u?.display_name ?? "";
      return {
        rosterId:   r.roster_id,
        teamName,
        ownerName,
        ownerId:    r.owner_id,
        wins:       r.settings?.wins   ?? 0,
        losses:     r.settings?.losses ?? 0,
        ties:       r.settings?.ties   ?? 0,
        pointsFor:  (r.settings?.fpts ?? 0) + (r.settings?.fpts_decimal ?? 0) / 100,
        playerIds:  r.players  ?? [],
        starterIds: r.starters ?? [],
        taxiIds:    r.taxi     ?? [],
        irIds:      r.reserve  ?? [],
      };
    });
  }

  async fetchLeaguePicks(leagueId: string): Promise<NormalizedDraftPick[]> {
    // Sleeper traded picks endpoint
    type SleeperPick = {
      season: string;
      round:  number;
      roster_id: number;
      previous_owner_id: number;
      owner_id: number;
    };
    try {
      const raw = await sleeperFetch<SleeperPick[]>(`/league/${leagueId}/traded_picks`);
      return (raw ?? []).map(p => {
        const slot  = p.roster_id % 4 === 1 ? "early" : p.roster_id % 4 === 3 ? "late" : "mid";
        return {
          pickKey:          `${p.season}_${p.round}_${slot}`,
          year:             Number(p.season),
          round:            p.round,
          bucket:           slot as "early" | "mid" | "late",
          ownerRosterId:    p.owner_id,
          originalRosterId: p.previous_owner_id,
          season:           p.season,
        };
      });
    } catch {
      return [];
    }
  }

  async fetchPlayers(_leagueId: string): Promise<Record<string, NormalizedPlayer>> {
    const raw = await sleeperFetch<Record<string, SleeperPlayer>>("/players/nfl");
    const result: Record<string, NormalizedPlayer> = {};
    for (const [id, p] of Object.entries(raw)) {
      const pos = primaryPos(p);
      if (!pos || !["QB","RB","WR","TE","DL","LB","DB","K","DEF"].includes(pos)) continue;
      result[`sleeper:${id}`] = {
        playerId:     `sleeper:${id}`,
        name:         `${p.first_name} ${p.last_name}`.trim(),
        firstName:    p.first_name,
        lastName:     p.last_name,
        position:     pos,
        team:         p.team ?? "FA",
        age:          p.age ?? 0,
        injuryStatus: p.injury_status,
        status:       p.status,
      };
    }
    return result;
  }

  async normalizeLeagueData(leagueId: string): Promise<NormalizedLeagueData> {
    const [settings, rosters, picks, players] = await Promise.all([
      this.fetchLeagueSettings(leagueId),
      this.fetchLeagueRosters(leagueId),
      this.fetchLeaguePicks(leagueId),
      this.fetchPlayers(leagueId),
    ]);
    return {
      leagueSettings:  settings,
      rosterSettings:  settings.rosterSettings,
      scoringSettings: settings.scoringSettings,
      teams:   rosters,
      rosters,
      draftPicks: picks,
      players,
      fetchedAt: new Date().toISOString(),
    };
  }
}

// ─── Convenience raw-API exports (used by App.tsx directly) ──────────────────

export const fetchLeague       = (id: string) => sleeperFetch<SleeperLeague>(`/league/${id}`);
export const fetchUsers        = (id: string) => sleeperFetch<SleeperUser[]>(`/league/${id}/users`);
export const fetchRosters      = (id: string) => sleeperFetch<SleeperRoster[]>(`/league/${id}/rosters`);
export const fetchMatchups     = (id: string, week: number) => sleeperFetch<SleeperMatchup[]>(`/league/${id}/matchups/${week}`);
export const fetchTransactions = (id: string, week = 1) => sleeperFetch<SleeperTransaction[]>(`/league/${id}/transactions/${week}`);
export const fetchNflState     = () => sleeperFetch<SleeperNflState>("/state/nfl");
export const fetchAllPlayers   = () => sleeperFetch<Record<string, SleeperPlayer>>("/players/nfl");

export function sleeperTeamName(roster: SleeperRoster, users: SleeperUser[]): string {
  const u = users.find(u => u.user_id === roster.owner_id);
  return u?.metadata?.team_name ?? u?.display_name ?? `Team ${roster.roster_id}`;
}

export function sleeperPrimaryPosition(p: SleeperPlayer): string {
  return normalizePosition(p.fantasy_positions?.[0] ?? p.position ?? "");
}

export function sleeperFormatContext(league: SleeperLeague, rosters: SleeperRoster[]) {
  const rs  = deriveRosterSettings(league);
  const ss  = deriveScoringSettings(league);
  const raw = (ss.rawScoring ?? {}) as Record<string, number>;
  return {
    superflex:          ss.superflex,
    tePremium:          ss.tePremium,
    idpEnabled:         ss.idpEnabled,
    leagueSize:         rosters.length,
    starterCounts:      rs.starterCounts,
    ppr:                ss.ppr,
    passTdPoints:       raw["pass_td"] ?? 4,
    benchSlots:         rs.benchSlots,
    flexPositions:      rs.flexPositions,
    superflexPositions: rs.superflexPositions,
    idpScoring:         ss.idpScoring,
  };
}

export const sleeperAdapter = new SleeperAdapter();
