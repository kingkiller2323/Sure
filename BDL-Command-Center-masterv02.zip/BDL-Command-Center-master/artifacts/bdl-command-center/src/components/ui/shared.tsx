/**
 * shared.tsx — Shared UI primitives extracted from App.tsx
 *
 * These components are used across multiple features.
 * No behavior changes from original App.tsx implementation.
 */

import React from "react";
import { POS_COLORS } from "../../utils/positions";
import type { ProviderStatus } from "../../services/consensus";

export function PosTag({ pos, small = false }: { pos: string; small?: boolean }) {
  return (
    <span
      style={{
        fontSize: small ? "9px" : "10px",
        fontWeight: "700",
        padding: small ? "1px 4px" : "2px 6px",
        borderRadius: "3px",
        background: `${POS_COLORS[pos] || "#6b7280"}22`,
        color: POS_COLORS[pos] || "#6b7280",
        letterSpacing: "0.04em",
        display: "inline-block",
        textAlign: "center",
        flexShrink: 0,
      }}
    >
      {pos}
    </span>
  );
}

export function InjuryBadge({ status }: { status?: string }) {
  if (!status || status === "Active") return null;
  const map: Record<string, { c: string; l: string }> = {
    Injured_Reserve: { c: "#ef4444", l: "IR" },
    Questionable: { c: "#f59e0b", l: "Q" },
    Doubtful: { c: "#f97316", l: "D" },
    Out: { c: "#ef4444", l: "OUT" },
    PUP: { c: "#8b5cf6", l: "PUP" },
  };
  const { c, l } = map[status] || { c: "#6b7280", l: status.slice(0, 3) };
  return (
    <span
      style={{
        fontSize: "8px",
        padding: "1px 4px",
        borderRadius: "3px",
        background: `${c}25`,
        color: c,
        fontWeight: "700",
        marginLeft: "4px",
      }}
    >
      {l}
    </span>
  );
}

export function Card({
  children,
  style = {},
}: {
  children: React.ReactNode;
  style?: React.CSSProperties;
}) {
  return (
    <div
      style={{
        background: "rgba(255,255,255,0.02)",
        border: "1px solid rgba(255,255,255,0.06)",
        borderRadius: "10px",
        padding: "12px",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

export function SectionHeader({
  label,
  count,
  color = "#8b5cf6",
}: {
  label: string;
  count?: string | number;
  color?: string;
}) {
  return (
    <div
      style={{
        fontSize: "10px",
        color,
        letterSpacing: "0.1em",
        fontWeight: "700",
        marginBottom: "6px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}
    >
      <span>{label}</span>
      {count !== undefined && <span style={{ color: "#4b5563" }}>{count}</span>}
    </div>
  );
}

/** Shows a banner when no external providers are loaded */
export function ProviderBanner({ statuses }: { statuses: ProviderStatus[] }) {
  const loaded = statuses.filter((s) => s.loaded);
  if (loaded.length > 0) return null;
  return (
    <div
      style={{
        margin: "8px 12px 0",
        padding: "8px 10px",
        borderRadius: "7px",
        background: "rgba(245,158,11,0.08)",
        border: "1px solid rgba(245,158,11,0.2)",
        fontSize: "10px",
        color: "#f59e0b",
        lineHeight: "1.6",
      }}
    >
      ⚠️ No external data sources connected — using formula-based values. Connect
      providers in <code>src/config/dataSources.ts</code> for market values.
    </div>
  );
}

export function FallbackTag({ show }: { show: boolean }) {
  if (!show) return null;
  return (
    <span
      style={{
        fontSize: "8px",
        color: "#4b5563",
        marginLeft: "4px",
        fontStyle: "italic",
      }}
    >
      ~
    </span>
  );
}
