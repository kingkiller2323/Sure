/**
 * dataSources.ts
 *
 * Single source of truth for all external data endpoints, file paths,
 * and provider configuration. Swap any URL/path here to change data sources.
 *
 * HOW TO CONNECT REAL SOURCES:
 * 1. Set the `url` field on the relevant provider to your actual endpoint.
 * 2. If the source requires auth, add a `headers` or `token` field here.
 * 3. The provider wrapper will pick it up automatically.
 *
 * Until real sources are connected, each provider returns empty data and
 * logs which source is missing so you know exactly what to plug in.
 */

export interface ProviderConfig {
  enabled: boolean;
  url: string;
  description: string;
  format: "json" | "csv" | "rss";
  headers?: Record<string, string>;
}

export interface DataSourceConfig {
  /** Offensive + general dynasty market values (KeepTradeCut-style) */
  ktcMarketValues: ProviderConfig;
  /** IDP-specific trade values (IDP Trade Calculator-style) */
  idpMarketValues: ProviderConfig;
  /** Consensus dynasty rankings (FantasyPros-style) */
  fantasyProsDynasty: ProviderConfig;
  /** Consensus rookie rankings (FantasyPros-style) */
  fantasyProsRookies: ProviderConfig;
  /** Player metadata (age, team, position, injury status) */
  playerMetadata: ProviderConfig;
  /** Optional: ADP / projections database */
  projections: ProviderConfig;
}

const DATA_SOURCES: DataSourceConfig = {
  ktcMarketValues: {
    enabled: false,
    url: "",
    description: "KeepTradeCut dynasty player market values (JSON export). " +
      "Set url to your KTC JSON feed or a scraped export. " +
      "Expected shape: Array<{ playerName, position, team, age, value, sfValue }>",
    format: "json",
  },
  idpMarketValues: {
    enabled: false,
    url: "",
    description: "IDP Trade Calculator market values (JSON export). " +
      "Set url to your IDP source feed. " +
      "Expected shape: Array<{ playerName, position, team, age, value }>",
    format: "json",
  },
  fantasyProsDynasty: {
    enabled: false,
    url: "",
    description: "FantasyPros Dynasty ECR consensus rankings (JSON export). " +
      "Set url to your FP export or a scraped JSON file. " +
      "Expected shape: Array<{ playerName, position, team, rank, tier }>",
    format: "json",
  },
  fantasyProsRookies: {
    enabled: false,
    url: "",
    description: "FantasyPros Dynasty Rookie ECR rankings (JSON export). " +
      "Set url to your FP rookie export. " +
      "Expected shape: Array<{ playerName, position, school, classYear, rank, tier }>",
    format: "json",
  },
  playerMetadata: {
    enabled: false,
    url: "",
    description: "Player metadata database (name, team, age, position). " +
      "This is optional; Sleeper's /players/nfl endpoint fills this role when using Sleeper import. " +
      "For manual leagues, set this url to a supplemental metadata JSON.",
    format: "json",
  },
  projections: {
    enabled: false,
    url: "",
    description: "Optional season projections / ADP feed. Not yet implemented.",
    format: "json",
  },
};

export default DATA_SOURCES;

/** Sleeper API base — not an external data source but centralised here for reference */
export const SLEEPER_BASE = "https://api.sleeper.app/v1";
export const CORS_PROXY   = "https://corsproxy.io/?";

/** Current dynasty class year for the rookie board */
export const CURRENT_ROOKIE_CLASS = 2026;
