const { useState, useEffect, useCallback, useRef } = React;

// ── Constants ──────────────────────────────────────────────────────────────────
const SLEEPER_BASE = "https://api.sleeper.app/v1";
const CORS_PROXY   = "https://corsproxy.io/?";
const APP_VERSION  = "1.0.0";

const POS_COLORS = {
  QB:"#ef4444", RB:"#22c55e", WR:"#3b82f6", TE:"#f59e0b",
  DL:"#8b5cf6", LB:"#ec4899", DB:"#06b6d4", K:"#f97316",
  DEF:"#64748b", PICK:"#94a3b8", FLEX:"#a78bfa", IDP:"#818cf8"
};
const TIER_LABELS = {1:"Elite",2:"Starter",3:"Depth",4:"Fringe"};

// 2026 Rookie Rankings (dynasty)
const ROOKIE_RANKINGS = [
  { rank:1,  name:"Jeremiyah Love",    pos:"RB", school:"Notre Dame",   age:21, value:8900, note:"Elite vision, 3-down back" },
  { rank:2,  name:"Arvell Reese",      pos:"LB", school:"Michigan",     age:22, value:8600, note:"Parsons comp, 4.46 speed" },
  { rank:3,  name:"Sonny Styles",      pos:"LB", school:"Ohio State",   age:22, value:8200, note:"4.46, 43.5\" vert, freak athlete" },
  { rank:4,  name:"Cam Skattebo",      pos:"RB", school:"Arizona State",age:23, value:7800, note:"Workhorse, outstanding contact balance" },
  { rank:5,  name:"Carnell Tate",      pos:"WR", school:"Ohio State",   age:21, value:7400, note:"Route runner, reliable hands" },
  { rank:6,  name:"Rueben Bain Jr",    pos:"DL", school:"Miami",        age:22, value:7800, note:"B/R #1 EDGE, elite motor" },
  { rank:7,  name:"KC Concepcion",     pos:"WR", school:"Florida",      age:21, value:6800, note:"4.38 speed, contested catch ability" },
  { rank:8,  name:"Caleb Downs",       pos:"DB", school:"Ohio State",   age:22, value:7200, note:"Polamalu comp — monitor knee" },
  { rank:9,  name:"David Bailey",      pos:"DL", school:"Georgia",      age:22, value:6400, note:"Best pressure rate in nation" },
  { rank:10, name:"TreVeyon Henderson",pos:"RB", school:"Ohio State",   age:23, value:6800, note:"Explosive, great receiving ability" },
  { rank:11, name:"Shedeur Sanders",   pos:"QB", school:"Colorado",     age:23, value:4600, note:"Accuracy specialist, pocket presence" },
  { rank:12, name:"Cam Ward",          pos:"QB", school:"Miami",        age:23, value:4200, note:"Athletic, strong arm" },
  { rank:13, name:"R Mason Thomas",    pos:"DL", school:"Georgia",      age:23, value:4200, note:"2nd round NFL talent, late value" },
  { rank:14, name:"Lorenzo Styles Jr", pos:"WR", school:"Ohio State",   age:22, value:2800, note:"4.27 forty, dart throw" },
  { rank:15, name:"Ollie Gordon",      pos:"RB", school:"Oklahoma State",age:22,value:4200, note:"Physical runner, volume dependent" },
  { rank:16, name:"Cam Skattebo",      pos:"RB", school:"Arizona State",age:23, value:6400, note:"Workhorse" },
  { rank:17, name:"Jack Bech",         pos:"WR", school:"TCU",          age:22, value:2600, note:"Slot receiver, RAC ability" },
  { rank:18, name:"Luther Burden",     pos:"WR", school:"Missouri",     age:22, value:7200, note:"YAC monster, alpha traits" },
  { rank:19, name:"Jaylen Pickett",    pos:"DB", school:"Penn State",   age:22, value:3200, note:"Instincts, football IQ" },
  { rank:20, name:"Dont'e Thornton",   pos:"WR", school:"Tennessee",    age:23, value:3400, note:"4.28 speed, deep threat" },
];

// ── Sleeper API ────────────────────────────────────────────────────────────────
const api = async (path) => {
  const url = `${SLEEPER_BASE}${path}`;
  try {
    const res = await fetch(url);
    if (res.ok) return res.json();
  } catch(e) {}
  // fallback to CORS proxy
  const res = await fetch(`${CORS_PROXY}${encodeURIComponent(url)}`);
  if (!res.ok) throw new Error(`Sleeper API error on ${path}`);
  return res.json();
};

// ── News Feeds ─────────────────────────────────────────────────────────────────
const NEWS_FEEDS = [
  { name:"Rotowire",    url:"https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fwww.rotowire.com%2Frss%2Fnews.php",                        color:"#22c55e" },
  { name:"ESPN NFL",    url:"https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fwww.espn.com%2Fespn%2Frss%2Fnfl%2Fnews",                   color:"#ef4444" },
  { name:"Yahoo Sports",url:"https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fsports.yahoo.com%2Fnfl%2Frss.xml",                         color:"#8b5cf6" },
  { name:"NFL.com",     url:"https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fwww.nfl.com%2Frss%2Frsslanding%3FsearchString%3Dnews",     color:"#3b82f6" },
];

// ── Utility Components ─────────────────────────────────────────────────────────
function PosTag({ pos, small }) {
  return (
    <span style={{
      fontSize: small ? "9px" : "10px", fontWeight:"700",
      padding: small ? "1px 4px" : "2px 6px", borderRadius:"3px",
      background:`${POS_COLORS[pos]||"#6b7280"}22`,
      color: POS_COLORS[pos]||"#6b7280",
      letterSpacing:"0.04em", display:"inline-block", textAlign:"center"
    }}>{pos}</span>
  );
}

function InjuryBadge({ status }) {
  if (!status || status === "Active") return null;
  const map = { Injured_Reserve:{c:"#ef4444",l:"IR"}, Questionable:{c:"#f59e0b",l:"Q"},
    Doubtful:{c:"#f97316",l:"D"}, Out:{c:"#ef4444",l:"OUT"}, PUP:{c:"#8b5cf6",l:"PUP"} };
  const { c, l } = map[status] || { c:"#6b7280", l:status.slice(0,3) };
  return <span style={{ fontSize:"8px", padding:"1px 4px", borderRadius:"3px",
    background:`${c}25`, color:c, fontWeight:"700", marginLeft:"4px" }}>{l}</span>;
}

function Card({ children, style={} }) {
  return <div style={{ background:"rgba(255,255,255,0.02)", border:"1px solid rgba(255,255,255,0.06)",
    borderRadius:"10px", padding:"12px", ...style }}>{children}</div>;
}

function SectionHeader({ label, count, color="#8b5cf6" }) {
  return (
    <div style={{ fontSize:"10px", color, letterSpacing:"0.1em", fontWeight:"700",
      marginBottom:"6px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
      <span>{label}</span>
      {count !== undefined && <span style={{ color:"#4b5563" }}>{count}</span>}
    </div>
  );
}

// ── VORP Value Model ───────────────────────────────────────────────────────────
function calcPlayerValue(player, leagueSettings) {
  if (!player) return 1000;
  const pos = player.fantasy_positions?.[0] || player.position;
  const age = player.age || 25;
  const scoring = leagueSettings?.scoring_settings || {};

  // Base values tuned per position importance in typical dynasty
  const bases = { QB:6200, RB:5800, WR:5800, TE:5200, DL:5200, LB:5000, DB:4600, K:1800, DEF:1500 };

  // Scoring bonuses
  let bonus = 0;
  if (pos === "TE" && (scoring.rec_te || 0) > 0.5) bonus += 600; // TE premium
  if (pos === "QB" && leagueSettings?.roster_positions?.filter(p => p==="QB").length > 1) bonus += 800; // SF
  if (["DL","LB","DB"].includes(pos)) {
    const sackVal = (scoring.sack || 0) * 200;
    const tackleVal = (scoring.tkl_solo || 0) * 100;
    bonus += sackVal + tackleVal;
  }

  let base = (bases[pos] || 2000) + bonus;

  // Dynasty age curve
  if (age <= 21) base *= 1.40;
  else if (age <= 22) base *= 1.28;
  else if (age <= 23) base *= 1.15;
  else if (age <= 25) base *= 1.00;
  else if (age <= 27) base *= 0.88;
  else if (age <= 29) base *= 0.72;
  else if (age <= 31) base *= 0.55;
  else base *= 0.35;

  return Math.round(base);
}

// ── League Entry Screen ────────────────────────────────────────────────────────
function LeagueEntryScreen({ onLoad }) {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [recentLeagues, setRecentLeagues] = useState(() => {
    try { return JSON.parse(localStorage.getItem("recent_leagues") || "[]"); } catch { return []; }
  });

  const tryLoad = async (id) => {
    const leagueId = id.trim().replace(/\s/g,"");
    if (!leagueId) { setErr("Please enter a league ID"); return; }
    setLoading(true); setErr("");
    try {
      const league = await api(`/league/${leagueId}`);
      if (!league || !league.league_id) throw new Error("League not found");
      // Save to recent
      const updated = [{ id: leagueId, name: league.name, platform:"Sleeper" },
        ...recentLeagues.filter(l => l.id !== leagueId)].slice(0, 5);
      try { localStorage.setItem("recent_leagues", JSON.stringify(updated)); } catch {}
      setRecentLeagues(updated);
      onLoad(leagueId, league);
    } catch(e) {
      setErr("Couldn't find that league. Check the ID and try again.");
    }
    setLoading(false);
  };

  return (
    <div style={{ minHeight:"100vh", background:"#08080f", display:"flex",
      flexDirection:"column", fontFamily:"'DM Mono','Courier New',monospace" }}>

      {/* Header */}
      <div style={{ background:"linear-gradient(135deg,#0f0f1a,#150a2a)",
        borderBottom:"1px solid rgba(139,92,246,0.25)", padding:"24px 20px 20px" }}>
        <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"8px" }}>
          <div style={{ width:"36px", height:"36px", borderRadius:"9px",
            background:"linear-gradient(135deg,#8b5cf6,#3b82f6)",
            display:"flex", alignItems:"center", justifyContent:"center", fontSize:"18px" }}>👑</div>
          <div>
            <div style={{ fontSize:"18px", fontWeight:"700", color:"#fff", letterSpacing:"0.05em" }}>
              Dynasty Command
            </div>
            <div style={{ fontSize:"10px", color:"#4b5563", letterSpacing:"0.1em" }}>
              THE FANTASY FOOTBALL COMMAND CENTER
            </div>
          </div>
        </div>
        <div style={{ fontSize:"12px", color:"#6b7280", lineHeight:"1.6", marginTop:"8px" }}>
          Connect your Sleeper league for live rosters, trade analysis, news, and more.
        </div>
      </div>

      <div style={{ flex:1, overflowY:"auto", padding:"20px" }}>

        {/* Sleeper Import */}
        <Card style={{ marginBottom:"16px", border:"1px solid rgba(139,92,246,0.25)" }}>
          <div style={{ display:"flex", alignItems:"center", gap:"8px", marginBottom:"12px" }}>
            <div style={{ width:"28px", height:"28px", borderRadius:"6px",
              background:"rgba(139,92,246,0.15)", display:"flex",
              alignItems:"center", justifyContent:"center", fontSize:"14px" }}>💤</div>
            <div>
              <div style={{ fontSize:"13px", color:"#fff", fontWeight:"600" }}>Sleeper</div>
              <div style={{ fontSize:"10px", color:"#4b5563" }}>Paste your league ID below</div>
            </div>
          </div>

          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && tryLoad(input)}
            placeholder="e.g. 1313709679045541888"
            style={{ width:"100%", padding:"10px 12px",
              background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)",
              borderRadius:"8px", color:"#e2e8f0", fontSize:"14px",
              fontFamily:"inherit", boxSizing:"border-box", outline:"none",
              marginBottom:"8px" }}
          />

          <div style={{ fontSize:"10px", color:"#4b5563", marginBottom:"12px", lineHeight:"1.6" }}>
            📍 Find your league ID: Sleeper app → Your league → Settings → scroll to bottom
          </div>

          {err && (
            <div style={{ fontSize:"11px", color:"#ef4444", marginBottom:"10px",
              padding:"8px 10px", background:"rgba(239,68,68,0.08)",
              borderRadius:"6px", border:"1px solid rgba(239,68,68,0.2)" }}>{err}</div>
          )}

          <button onClick={() => tryLoad(input)} disabled={loading} style={{
            width:"100%", padding:"12px",
            background: loading ? "rgba(139,92,246,0.1)" : "linear-gradient(135deg,#8b5cf6,#6366f1)",
            border:"none", borderRadius:"8px",
            color: loading ? "#6b7280" : "#fff",
            fontSize:"13px", cursor: loading ? "default" : "pointer",
            fontFamily:"inherit", fontWeight:"600", letterSpacing:"0.04em"
          }}>
            {loading ? "Connecting to Sleeper..." : "Connect League →"}
          </button>
        </Card>

        {/* Recent Leagues */}
        {recentLeagues.length > 0 && (
          <div style={{ marginBottom:"16px" }}>
            <SectionHeader label="RECENT LEAGUES" />
            {recentLeagues.map(l => (
              <div key={l.id} onClick={() => tryLoad(l.id)} style={{
                padding:"10px 12px", borderRadius:"8px", cursor:"pointer",
                background:"rgba(255,255,255,0.02)", border:"1px solid rgba(255,255,255,0.06)",
                marginBottom:"4px", display:"flex", justifyContent:"space-between",
                alignItems:"center"
              }}>
                <div>
                  <div style={{ fontSize:"12px", color:"#e2e8f0" }}>{l.name}</div>
                  <div style={{ fontSize:"10px", color:"#4b5563" }}>{l.platform} · {l.id}</div>
                </div>
                <span style={{ color:"#8b5cf6", fontSize:"16px" }}>→</span>
              </div>
            ))}
          </div>
        )}

        {/* Coming Soon */}
        <Card>
          <SectionHeader label="MORE PLATFORMS COMING SOON" color="#4b5563" />
          {[
            { name:"ESPN Fantasy",  icon:"🏈", status:"Q2 2026" },
            { name:"Yahoo Fantasy", icon:"🟣", status:"Q2 2026" },
            { name:"NFL.com",       icon:"🏟️", status:"Q3 2026" },
            { name:"CBS Sports",    icon:"📺", status:"Q3 2026" },
            { name:"Fantrax",       icon:"⚡", status:"Q4 2026" },
            { name:"MFL",           icon:"🔢", status:"Q4 2026" },
          ].map(p => (
            <div key={p.name} style={{ display:"flex", justifyContent:"space-between",
              alignItems:"center", padding:"7px 0",
              borderBottom:"1px solid rgba(255,255,255,0.04)" }}>
              <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
                <span>{p.icon}</span>
                <span style={{ fontSize:"12px", color:"#6b7280" }}>{p.name}</span>
              </div>
              <span style={{ fontSize:"10px", color:"#374151", padding:"2px 6px",
                background:"rgba(255,255,255,0.04)", borderRadius:"4px" }}>{p.status}</span>
            </div>
          ))}
        </Card>

        <div style={{ textAlign:"center", marginTop:"20px", fontSize:"10px", color:"#1f2937" }}>
          Dynasty Command v{APP_VERSION} · Built for serious managers
        </div>
      </div>
    </div>
  );
}

// ── Main App (league loaded) ───────────────────────────────────────────────────
function LeagueApp({ leagueId, initialLeague, onDisconnect }) {
  const [tab, setTab]               = useState("roster");
  const [leagueData, setLeagueData] = useState(initialLeague);
  const [users, setUsers]           = useState([]);
  const [rosters, setRosters]       = useState([]);
  const [players, setPlayers]       = useState({});
  const [transactions, setTrans]    = useState([]);
  const [matchups, setMatchups]     = useState([]);
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [myRosterId, setMyRosterId] = useState(null);
  const [loading, setLoading]       = useState(true);
  const [playersLoading, setPlayersLoading] = useState(true);
  const [news, setNews]             = useState([]);
  const [newsLoading, setNewsLoading] = useState(false);
  const [newsLoaded, setNewsLoaded] = useState(false);
  const [currentWeek, setCurrentWeek] = useState(1);
  // Trade calc
  const [giveSide, setGiveSide]     = useState([]);
  const [getSide, setGetSide]       = useState([]);
  const [tradeSubTab, setTradeSubTab] = useState("search");
  const [addingTo, setAddingTo]     = useState("give");
  const [tradeSearch, setTradeSearch] = useState("");
  const [tradePosFilter, setTradePosFilter] = useState("ALL");
  const [tradeMode, setTradeMode]   = useState("balanced");
  // Free agency
  const [faSearch, setFaSearch]     = useState("");
  const [faPosFilter, setFaPosFilter] = useState("ALL");
  // Draft board
  const [draftNotes, setDraftNotes] = useState({});
  const [draftFilter, setDraftFilter] = useState("ALL");

  // ── Load league data ────────────────────────────────────────────────────────
  useEffect(() => {
    const load = async () => {
      try {
        const [usersData, rostersData] = await Promise.all([
          api(`/league/${leagueId}/users`),
          api(`/league/${leagueId}/rosters`),
        ]);
        setUsers(usersData);
        setRosters(rostersData);
        setSelectedTeam(rostersData[0]?.roster_id);

        // Transactions & matchups
        try { const t = await api(`/league/${leagueId}/transactions/1`); setTrans(t||[]); } catch {}
        try {
          const nflState = await api("/state/nfl");
          const week = nflState?.week || 1;
          setCurrentWeek(week);
          const m = await api(`/league/${leagueId}/matchups/${week}`);
          setMatchups(m||[]);
        } catch {}

        setLoading(false);

        // Load players in background (large file)
        const playersData = await api("/players/nfl");
        setPlayers(playersData);
        setPlayersLoading(false);
      } catch(e) {
        setLoading(false);
        setPlayersLoading(false);
      }
    };
    load();
  }, [leagueId]);

  // ── Load news on tab switch ─────────────────────────────────────────────────
  useEffect(() => {
    if (tab !== "news" || newsLoaded) return;
    const loadNews = async () => {
      setNewsLoading(true);
      const all = [];
      await Promise.allSettled(NEWS_FEEDS.map(async feed => {
        try {
          const res = await fetch(feed.url);
          const data = await res.json();
          (data.items||[]).slice(0,15).forEach(item => {
            all.push({
              title: item.title,
              link: item.link,
              pubDate: item.pubDate,
              description: (item.description||"").replace(/<[^>]+>/g,"").slice(0,200),
              source: feed.name,
              color: feed.color,
            });
          });
        } catch {}
      }));
      all.sort((a,b) => new Date(b.pubDate) - new Date(a.pubDate));
      setNews(all);
      setNewsLoading(false);
      setNewsLoaded(true);
    };
    loadNews();
  }, [tab, newsLoaded]);

  // ── Helpers ─────────────────────────────────────────────────────────────────
  const getUserForRoster = useCallback(r => users.find(u => u.user_id === r.owner_id), [users]);
  const getTeamName = useCallback(r => {
    const u = getUserForRoster(r);
    return u?.metadata?.team_name || u?.display_name || `Team ${r.roster_id}`;
  }, [getUserForRoster]);
  const getPlayer = useCallback(id => players[id] || null, [players]);
  const getPlayerName = useCallback(id => {
    const p = players[id];
    return p ? `${p.first_name} ${p.last_name}` : id;
  }, [players]);
  const getPos = useCallback(id => {
    const p = players[id];
    return p?.fantasy_positions?.[0] || p?.position || "?";
  }, [players]);
  const getValue = useCallback(id => {
    const p = players[id];
    return p ? calcPlayerValue(p, leagueData) : 1000;
  }, [players, leagueData]);

  if (loading) {
    return (
      <div style={{ minHeight:"100vh", background:"#08080f", display:"flex",
        flexDirection:"column", alignItems:"center", justifyContent:"center",
        fontFamily:"'DM Mono',monospace", color:"#8b5cf6", gap:"14px" }}>
        <div style={{ fontSize:"36px" }}>👑</div>
        <div style={{ fontSize:"13px", letterSpacing:"0.1em" }}>LOADING LEAGUE</div>
        <div style={{ fontSize:"11px", color:"#374151" }}>{leagueData?.name}</div>
        <div style={{ width:"180px", height:"3px", background:"rgba(139,92,246,0.15)",
          borderRadius:"2px", overflow:"hidden" }}>
          <div style={{ height:"100%", width:"35%",
            background:"linear-gradient(90deg,#8b5cf6,#3b82f6)", borderRadius:"2px",
            animation:"slide 1.2s ease-in-out infinite" }} />
        </div>
        <style>{`@keyframes slide{0%{transform:translateX(-200%)}100%{transform:translateX(700%)}}`}</style>
      </div>
    );
  }

  // ── All rostered player IDs ─────────────────────────────────────────────────
  const allRosteredIds = new Set(rosters.flatMap(r => [
    ...(r.players||[]), ...(r.taxi||[]), ...(r.reserve||[])
  ]));

  // ── ROSTER TAB ──────────────────────────────────────────────────────────────
  const RosterTab = () => {
    const roster = rosters.find(r => r.roster_id === selectedTeam);
    if (!roster) return null;
    const teamName = getTeamName(roster);
    const user = getUserForRoster(roster);
    const starterIds = (roster.starters||[]).filter(id => id && id !== "0");
    const taxiIds = roster.taxi||[];
    const irIds = roster.reserve||[];
    const benchIds = (roster.players||[]).filter(id =>
      !starterIds.includes(id) && !taxiIds.includes(id) && !irIds.includes(id)
    );
    const wins = roster.settings?.wins||0;
    const losses = roster.settings?.losses||0;
    const pts = ((roster.settings?.fpts||0) + (roster.settings?.fpts_decimal||0)/100).toFixed(1);

    const Row = ({ id, highlight }) => {
      const p = getPlayer(id);
      const name = getPlayerName(id);
      const pos = getPos(id);
      return (
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between",
          padding:"8px 10px", borderRadius:"7px", marginBottom:"3px",
          background: highlight ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.015)",
          border:`1px solid ${highlight ? "rgba(255,255,255,0.07)" : "rgba(255,255,255,0.025)"}`,
          gap:"8px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:"8px", minWidth:0 }}>
            <PosTag pos={pos} small />
            <div style={{ minWidth:0 }}>
              <div style={{ fontSize:"13px", color: highlight ? "#f1f5f9" : "#94a3b8",
                overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                {name}<InjuryBadge status={p?.injury_status} />
              </div>
              <div style={{ fontSize:"10px", color:"#4b5563" }}>
                {p?.team||"FA"}{p?.age ? ` · Age ${p.age}` : ""}
                {playersLoading ? "" : ""}
              </div>
            </div>
          </div>
          <div style={{ fontSize:"11px", color:"#4b5563", flexShrink:0 }}>
            {playersLoading ? "…" : getValue(id).toLocaleString()}
          </div>
        </div>
      );
    };

    return (
      <div style={{ flex:1, overflowY:"auto" }}>
        {/* Team tabs */}
        <div style={{ padding:"8px 10px", borderBottom:"1px solid rgba(255,255,255,0.05)",
          display:"flex", gap:"5px", overflowX:"auto", flexShrink:0 }}>
          {rosters.map(r => {
            const u = getUserForRoster(r);
            const nm = u?.metadata?.team_name || u?.display_name || `T${r.roster_id}`;
            const active = r.roster_id === selectedTeam;
            const isMe = r.roster_id === myRosterId;
            return (
              <button key={r.roster_id} onClick={() => setSelectedTeam(r.roster_id)} style={{
                padding:"5px 10px", borderRadius:"6px", whiteSpace:"nowrap",
                border: active ? "1px solid #8b5cf6" : "1px solid rgba(255,255,255,0.07)",
                background: active ? "rgba(139,92,246,0.2)" : "rgba(255,255,255,0.02)",
                color: active ? "#c4b5fd" : isMe ? "#f59e0b" : "#6b7280",
                fontSize:"10px", cursor:"pointer", fontFamily:"inherit"
              }}>{isMe?"👑 ":""}{nm.length>13?nm.slice(0,13)+"…":nm}</button>
            );
          })}
        </div>

        <div style={{ padding:"12px" }}>
          {/* Team header */}
          <Card style={{ marginBottom:"12px", background:"linear-gradient(135deg,rgba(139,92,246,0.08),rgba(59,130,246,0.04))",
            border:"1px solid rgba(139,92,246,0.2)" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
              <div>
                <div style={{ fontSize:"16px", fontWeight:"700", color:"#fff" }}>{teamName}</div>
                <div style={{ fontSize:"11px", color:"#6b7280", marginTop:"2px" }}>
                  {user?.display_name} · Sleeper
                </div>
              </div>
              <div style={{ textAlign:"right" }}>
                <div style={{ fontSize:"20px", fontWeight:"800", color:"#22c55e" }}>{wins}-{losses}</div>
                <div style={{ fontSize:"10px", color:"#4b5563" }}>{pts} pts</div>
              </div>
            </div>
          </Card>

          {starterIds.length > 0 && <>
            <SectionHeader label="⚡ STARTERS" count={starterIds.length} color="#8b5cf6" />
            {starterIds.map(id => <Row key={id} id={id} highlight />)}
          </>}

          {benchIds.length > 0 && <div style={{ marginTop:"12px" }}>
            <SectionHeader label="📋 BENCH" count={benchIds.length} />
            {benchIds.map(id => <Row key={id} id={id} />)}
          </div>}

          {taxiIds.length > 0 && <div style={{ marginTop:"12px" }}>
            <SectionHeader label="🚕 TAXI SQUAD" count={`${taxiIds.length}/5`} color="#f59e0b" />
            {taxiIds.map(id => <Row key={id} id={id} />)}
          </div>}

          {irIds.length > 0 && <div style={{ marginTop:"12px" }}>
            <SectionHeader label="🏥 INJURED RESERVE" count={irIds.length} color="#ef4444" />
            {irIds.map(id => <Row key={id} id={id} />)}
          </div>}
        </div>
      </div>
    );
  };

  // ── STANDINGS TAB ───────────────────────────────────────────────────────────
  const StandingsTab = () => {
    const sorted = [...rosters].sort((a,b) => {
      const aw = a.settings?.wins||0, bw = b.settings?.wins||0;
      if (bw!==aw) return bw-aw;
      const ap = (a.settings?.fpts||0)+(a.settings?.fpts_decimal||0)/100;
      const bp = (b.settings?.fpts||0)+(b.settings?.fpts_decimal||0)/100;
      return bp-ap;
    });
    const playoffSpots = leagueData?.settings?.playoff_teams || 6;

    return (
      <div style={{ flex:1, overflowY:"auto", padding:"12px" }}>
        <div style={{ fontSize:"10px", color:"#4b5563", letterSpacing:"0.08em", marginBottom:"10px" }}>
          {leagueData?.name} · {leagueData?.season} · Top {playoffSpots} make playoffs
        </div>
        {sorted.map((roster, idx) => {
          const user = getUserForRoster(roster);
          const teamName = getTeamName(roster);
          const wins = roster.settings?.wins||0, losses = roster.settings?.losses||0;
          const pts = ((roster.settings?.fpts||0)+(roster.settings?.fpts_decimal||0)/100).toFixed(1);
          const isMe = roster.roster_id === myRosterId;
          const playoff = idx < playoffSpots;
          const medals = ["🥇","🥈","🥉"];
          return (
            <div key={roster.roster_id} onClick={() => { setSelectedTeam(roster.roster_id); setTab("roster"); }}
              style={{ padding:"11px 13px", borderRadius:"10px", cursor:"pointer",
                background: isMe ? "rgba(139,92,246,0.1)" : "rgba(255,255,255,0.02)",
                border: isMe ? "1px solid rgba(139,92,246,0.3)" : `1px solid ${playoff?"rgba(34,197,94,0.08)":"rgba(255,255,255,0.04)"}`,
                marginBottom:"5px", display:"flex", alignItems:"center", gap:"10px" }}>
              <div style={{ width:"26px", height:"26px", borderRadius:"50%", flexShrink:0,
                background: idx<3 ? "rgba(255,215,0,0.1)" : "rgba(255,255,255,0.04)",
                display:"flex", alignItems:"center", justifyContent:"center",
                fontSize: idx<3?"14px":"11px", color:"#4b5563", fontWeight:"700" }}>
                {idx<3 ? medals[idx] : idx+1}
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:"13px", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap",
                  color: isMe?"#c4b5fd":"#e2e8f0", fontWeight: isMe?"700":"400" }}>
                  {isMe?"👑 ":""}{teamName}
                </div>
                <div style={{ fontSize:"10px", color:"#4b5563" }}>{user?.display_name}</div>
              </div>
              <div style={{ textAlign:"right", flexShrink:0 }}>
                <div style={{ fontSize:"14px", fontWeight:"700", color: playoff?"#22c55e":"#6b7280" }}>
                  {wins}-{losses}
                </div>
                <div style={{ fontSize:"10px", color:"#4b5563" }}>{pts} pts</div>
              </div>
              {playoff && <div style={{ fontSize:"9px", padding:"2px 5px", borderRadius:"3px",
                background:"rgba(34,197,94,0.1)", color:"#22c55e", letterSpacing:"0.05em", flexShrink:0 }}>PO</div>}
            </div>
          );
        })}

        {/* League settings summary */}
        <Card style={{ marginTop:"14px" }}>
          <SectionHeader label="LEAGUE SETTINGS" color="#4b5563" />
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"6px" }}>
            {[
              ["Format", leagueData?.settings?.type === 2 ? "Dynasty" : leagueData?.settings?.type === 1 ? "Keeper" : "Redraft"],
              ["Teams", rosters.length],
              ["Playoff Teams", leagueData?.settings?.playoff_teams || 6],
              ["Season", leagueData?.season],
              ["Taxi Slots", leagueData?.settings?.taxi_slots || 0],
              ["IR Slots", leagueData?.settings?.reserve_slots || 0],
            ].map(([k,v]) => (
              <div key={k} style={{ padding:"7px 9px", background:"rgba(255,255,255,0.02)",
                borderRadius:"6px", border:"1px solid rgba(255,255,255,0.04)" }}>
                <div style={{ fontSize:"9px", color:"#4b5563", letterSpacing:"0.06em" }}>{k}</div>
                <div style={{ fontSize:"12px", color:"#e2e8f0", marginTop:"2px", fontWeight:"600" }}>{v}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    );
  };

  // ── MATCHUPS TAB ────────────────────────────────────────────────────────────
  const MatchupsTab = () => {
    const grouped = {};
    matchups.forEach(m => {
      const key = m.matchup_id;
      if (!grouped[key]) grouped[key] = [];
      grouped[key].push(m);
    });

    return (
      <div style={{ flex:1, overflowY:"auto", padding:"12px" }}>
        <div style={{ fontSize:"10px", color:"#4b5563", letterSpacing:"0.08em", marginBottom:"10px" }}>
          WEEK {currentWeek} MATCHUPS
        </div>
        {Object.values(grouped).length === 0 ? (
          <div style={{ textAlign:"center", color:"#374151", padding:"40px 0" }}>
            <div style={{ fontSize:"32px", marginBottom:"8px" }}>📅</div>
            <div style={{ fontSize:"13px" }}>No matchup data available</div>
            <div style={{ fontSize:"11px", color:"#374151", marginTop:"6px" }}>Season may not have started yet</div>
          </div>
        ) : Object.values(grouped).map((pair, i) => {
          if (pair.length < 2) return null;
          const [a, b] = pair;
          const rA = rosters.find(r => r.roster_id === a.roster_id);
          const rB = rosters.find(r => r.roster_id === b.roster_id);
          const nameA = rA ? getTeamName(rA) : `Team ${a.roster_id}`;
          const nameB = rB ? getTeamName(rB) : `Team ${b.roster_id}`;
          const ptsA = a.points || 0;
          const ptsB = b.points || 0;
          const winner = ptsA > ptsB ? "a" : ptsB > ptsA ? "b" : null;
          return (
            <Card key={i} style={{ marginBottom:"8px" }}>
              <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
                <div style={{ flex:1, textAlign:"right" }}>
                  <div style={{ fontSize:"13px", color: winner==="a"?"#22c55e":"#e2e8f0",
                    fontWeight: winner==="a"?"700":"400", overflow:"hidden",
                    textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{nameA}</div>
                  <div style={{ fontSize:"18px", fontWeight:"800",
                    color: winner==="a"?"#22c55e":"#e2e8f0" }}>{ptsA.toFixed(1)}</div>
                </div>
                <div style={{ fontSize:"11px", color:"#4b5563", padding:"0 6px",
                  letterSpacing:"0.06em", flexShrink:0 }}>VS</div>
                <div style={{ flex:1, textAlign:"left" }}>
                  <div style={{ fontSize:"13px", color: winner==="b"?"#22c55e":"#e2e8f0",
                    fontWeight: winner==="b"?"700":"400", overflow:"hidden",
                    textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{nameB}</div>
                  <div style={{ fontSize:"18px", fontWeight:"800",
                    color: winner==="b"?"#22c55e":"#e2e8f0" }}>{ptsB.toFixed(1)}</div>
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    );
  };

  // ── FREE AGENCY TAB ─────────────────────────────────────────────────────────
  const FreeAgencyTab = () => {
    const POSITIONS_FA = ["ALL","QB","RB","WR","TE","DL","LB","DB","K"];

    // Build FA pool from players not rostered
    const faPlayers = Object.entries(players)
      .filter(([id, p]) => {
        if (allRosteredIds.has(id)) return false;
        const pos = p.fantasy_positions?.[0] || p.position;
        if (!pos || pos === "DEF" || pos === "K" || !["QB","RB","WR","TE","DL","LB","DB","K"].includes(pos)) return false;
        if (faPosFilter !== "ALL" && pos !== faPosFilter) return false;
        if (faSearch && !`${p.first_name} ${p.last_name}`.toLowerCase().includes(faSearch.toLowerCase())) return false;
        return true;
      })
      .map(([id, p]) => ({ id, p, pos: p.fantasy_positions?.[0]||p.position, value: calcPlayerValue(p, leagueData) }))
      .sort((a,b) => b.value - a.value)
      .slice(0, 100);

    return (
      <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
        <div style={{ padding:"8px 12px", borderBottom:"1px solid rgba(255,255,255,0.05)", flexShrink:0 }}>
          <input value={faSearch} onChange={e => setFaSearch(e.target.value)}
            placeholder="Search free agents..."
            style={{ width:"100%", padding:"8px 12px",
              background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.1)",
              borderRadius:"7px", color:"#e2e8f0", fontSize:"14px",
              fontFamily:"inherit", boxSizing:"border-box", outline:"none" }} />
        </div>
        <div style={{ padding:"6px 12px", display:"flex", gap:"5px",
          overflowX:"auto", borderBottom:"1px solid rgba(255,255,255,0.04)", flexShrink:0 }}>
          {POSITIONS_FA.map(pos => (
            <button key={pos} onClick={() => setFaPosFilter(pos)} style={{
              padding:"3px 9px", borderRadius:"4px", whiteSpace:"nowrap",
              border: faPosFilter===pos ? `1px solid ${POS_COLORS[pos]||"#8b5cf6"}` : "1px solid rgba(255,255,255,0.07)",
              background: faPosFilter===pos ? `${POS_COLORS[pos]||"#8b5cf6"}18` : "transparent",
              color: faPosFilter===pos ? POS_COLORS[pos]||"#c4b5fd" : "#4b5563",
              fontSize:"10px", cursor:"pointer", fontFamily:"inherit"
            }}>{pos}</button>
          ))}
        </div>
        <div style={{ flex:1, overflowY:"auto", padding:"8px 12px" }}>
          {playersLoading ? (
            <div style={{ textAlign:"center", color:"#374151", padding:"40px 0", fontSize:"12px" }}>
              Loading player pool...
            </div>
          ) : faPlayers.length === 0 ? (
            <div style={{ textAlign:"center", color:"#374151", padding:"40px 0" }}>
              <div style={{ fontSize:"32px", marginBottom:"8px" }}>🔍</div>
              <div style={{ fontSize:"13px" }}>No free agents found</div>
            </div>
          ) : faPlayers.map(({ id, p, pos, value }) => (
            <div key={id} style={{ padding:"9px 10px", borderRadius:"7px", marginBottom:"3px",
              background:"rgba(255,255,255,0.02)", border:"1px solid rgba(255,255,255,0.04)",
              display:"flex", justifyContent:"space-between", alignItems:"center", gap:"8px" }}>
              <div style={{ display:"flex", alignItems:"center", gap:"8px", minWidth:0 }}>
                <PosTag pos={pos} small />
                <div style={{ minWidth:0 }}>
                  <div style={{ fontSize:"13px", color:"#e2e8f0", overflow:"hidden",
                    textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                    {p.first_name} {p.last_name}
                    <InjuryBadge status={p.injury_status} />
                  </div>
                  <div style={{ fontSize:"10px", color:"#4b5563" }}>
                    {p.team||"FA"}{p.age ? ` · Age ${p.age}` : ""}
                    {p.status === "Active" ? "" : p.status ? ` · ${p.status}` : ""}
                  </div>
                </div>
              </div>
              <div style={{ textAlign:"right", flexShrink:0 }}>
                <div style={{ fontSize:"12px", fontWeight:"700", color:"#8b5cf6" }}>
                  {value.toLocaleString()}
                </div>
                <div style={{ fontSize:"9px", color:"#374151" }}>
                  {value > 7000 ? "Elite" : value > 4500 ? "Starter" : value > 2500 ? "Depth" : "Fringe"}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // ── TRADE CALCULATOR TAB ────────────────────────────────────────────────────
  const PICK_VALUES_LOCAL = {
    "2026 1.01":9200,"2026 1.02":8800,"2026 1.03":8400,"2026 1.04":8000,
    "2026 1.05":7600,"2026 1.06":7200,"2026 1.07":6800,"2026 1.08":6400,
    "2026 1.09":6000,"2026 1.10":5600,
    "2026 2nd Early":4200,"2026 2nd Mid":3600,"2026 2nd Late":3000,
    "2026 3rd Early":2400,"2026 3rd Mid":2000,"2026 3rd Late":1600,
    "2026 4th":1200,"2026 5th":900,
    "2027 1st Early":8600,"2027 1st Mid":7800,"2027 1st Late":7000,
    "2027 2nd Early":4800,"2027 2nd Mid":4000,"2027 2nd Late":3200,
    "2027 3rd":2200,"2027 4th":1400,
    "2028 1st Early":7200,"2028 1st Mid":6400,"2028 1st Late":5600,
    "2028 2nd":3600,"2028 3rd":2000,
  };

  const TradeCalcTab = () => {
    const POSITIONS_TC = ["ALL","QB","RB","WR","TE","DL","LB","DB","PICK"];

    const playerPool = [...allRosteredIds].map(id => {
      const p = getPlayer(id);
      if (!p) return null;
      const pos = p.fantasy_positions?.[0]||p.position||"?";
      const value = getValue(id);
      const roster = rosters.find(r => (r.players||[]).includes(id)||(r.taxi||[]).includes(id));
      const owner = roster ? getTeamName(roster) : "FA";
      return { id, name:`${p.first_name} ${p.last_name}`, pos, value,
        age: p.age||0, team: p.team||"FA", owner,
        tier: value>8000?1:value>5000?2:value>2500?3:4 };
    }).filter(Boolean).sort((a,b) => b.value-a.value);

    const picks = Object.entries(PICK_VALUES_LOCAL).map(([name,value]) => ({
      id:name, name, pos:"PICK", value, age:0, team:"PICK", owner:"–",
      tier:value>7000?1:value>4000?2:value>2000?3:4
    }));

    const fullPool = [...playerPool, ...picks];
    const selected = new Set([...giveSide, ...getSide]);

    const filtered = fullPool.filter(p => {
      const ms = p.name.toLowerCase().includes(tradeSearch.toLowerCase());
      const mp = tradePosFilter==="ALL"||p.pos===tradePosFilter;
      return ms && mp && !selected.has(p.id);
    });

    function modeAdj(v, age, pos) {
      if (tradeMode==="balanced") return v;
      const young=age>0&&age<=23, vet=age>=28, pick=pos==="PICK";
      if (tradeMode==="contender") {
        if(vet) return Math.round(v*1.12);
        if(pick) return Math.round(v*0.85);
        if(young) return Math.round(v*0.92);
      }
      if (tradeMode==="rebuilder") {
        if(young||pick) return Math.round(v*1.15);
        if(vet) return Math.round(v*0.85);
      }
      return v;
    }

    const getAdjVal = id => {
      const p = fullPool.find(x=>x.id===id);
      return p ? modeAdj(p.value, p.age, p.pos) : 0;
    };

    const giveTotal = giveSide.reduce((s,id)=>s+getAdjVal(id),0);
    const getTotal  = getSide.reduce((s,id)=>s+getAdjVal(id),0);
    const totalBoth = giveTotal+getTotal;
    const pct = totalBoth>0 ? Math.round((getTotal/totalBoth)*100) : 50;
    const barW = totalBoth>0 ? Math.round((giveTotal/totalBoth)*100) : 50;

    const verdict = (() => {
      if(pct>=48&&pct<=52) return {l:"EVEN TRADE",c:"#22c55e",e:"⚖️"};
      if(pct>=44&&pct<48)  return {l:"SLIGHT OVERPAY",c:"#f59e0b",e:"😐"};
      if(pct>52&&pct<=56)  return {l:"SLIGHT WIN",c:"#86efac",e:"👍"};
      if(pct>=38&&pct<44)  return {l:"OVERPAYING",c:"#f97316",e:"⚠️"};
      if(pct>56&&pct<=62)  return {l:"GOOD WIN",c:"#4ade80",e:"✅"};
      if(pct<38)           return {l:"MAJOR OVERPAY",c:"#ef4444",e:"🚨"};
      return               {l:"STRONG WIN",c:"#16a34a",e:"🔥"};
    })();

    const SideList = ({ side }) => {
      const isGive = side==="give";
      const list = isGive?giveSide:getSide;
      const total = isGive?giveTotal:getTotal;
      const color = isGive?"#ef4444":"#22c55e";
      const remove = id => isGive ? setGiveSide(p=>p.filter(x=>x!==id)) : setGetSide(p=>p.filter(x=>x!==id));

      return (
        <div style={{ marginBottom:"12px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"6px" }}>
            <div style={{ fontSize:"10px", color, letterSpacing:"0.1em", fontWeight:"700" }}>
              {isGive?"📤 YOU GIVE":"📥 YOU GET"}
            </div>
            <div style={{ fontSize:"15px", fontWeight:"800", color }}>{total.toLocaleString()}</div>
          </div>
          {list.length===0 ? (
            <div style={{ padding:"14px", borderRadius:"8px", textAlign:"center",
              border:`1px dashed ${color}30`, color:"#374151", fontSize:"12px" }}>
              {isGive?"Add players giving up":"Add players receiving"}
            </div>
          ) : list.map(id=>{
            const p=fullPool.find(x=>x.id===id);
            if(!p) return null;
            return (
              <div key={id} style={{ padding:"8px 10px", borderRadius:"7px",
                background:`${color}08`, border:`1px solid ${color}20`,
                marginBottom:"4px", display:"flex", justifyContent:"space-between",
                alignItems:"center", gap:"8px" }}>
                <div style={{ display:"flex", alignItems:"center", gap:"7px", minWidth:0 }}>
                  <PosTag pos={p.pos} small />
                  <div style={{ minWidth:0 }}>
                    <div style={{ fontSize:"12px", color:"#e2e8f0", overflow:"hidden",
                      textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{p.name}</div>
                    <div style={{ fontSize:"9px", color:"#4b5563" }}>{p.owner}</div>
                  </div>
                </div>
                <div style={{ display:"flex", alignItems:"center", gap:"8px", flexShrink:0 }}>
                  <span style={{ fontSize:"12px", fontWeight:"700", color }}>
                    {modeAdj(p.value,p.age,p.pos).toLocaleString()}
                  </span>
                  <button onClick={()=>remove(id)} style={{
                    background:`${color}20`, border:`1px solid ${color}35`,
                    color, borderRadius:"4px", width:"22px", height:"22px",
                    cursor:"pointer", fontSize:"14px", fontFamily:"inherit",
                    display:"flex", alignItems:"center", justifyContent:"center"
                  }}>×</button>
                </div>
              </div>
            );
          })}
        </div>
      );
    };

    return (
      <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
        {/* Sub tabs */}
        <div style={{ display:"flex", borderBottom:"1px solid rgba(255,255,255,0.06)", flexShrink:0 }}>
          {["search","build","result"].map(t=>(
            <button key={t} onClick={()=>setTradeSubTab(t)} style={{
              flex:1, padding:"10px 4px",
              background:tradeSubTab===t?"rgba(255,255,255,0.03)":"transparent",
              border:"none", borderBottom:tradeSubTab===t?"2px solid #8b5cf6":"2px solid transparent",
              color:tradeSubTab===t?"#c4b5fd":"#4b5563",
              fontSize:"11px", cursor:"pointer", fontFamily:"inherit",
              letterSpacing:"0.06em", textTransform:"uppercase"
            }}>{t==="search"?"🔍 Search":t==="build"?"⚖️ Build":"📊 Result"}</button>
          ))}
        </div>

        {tradeSubTab==="search" && (
          <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
            <div style={{ display:"flex", flexShrink:0, borderBottom:"1px solid rgba(255,255,255,0.05)" }}>
              {["give","get"].map(side=>(
                <button key={side} onClick={()=>setAddingTo(side)} style={{
                  flex:1, padding:"9px",
                  background:addingTo===side
                    ?side==="give"?"rgba(239,68,68,0.1)":"rgba(34,197,94,0.1)"
                    :"transparent",
                  border:"none",
                  borderBottom:addingTo===side?`2px solid ${side==="give"?"#ef4444":"#22c55e"}`:"2px solid transparent",
                  color:addingTo===side?side==="give"?"#fca5a5":"#86efac":"#4b5563",
                  fontSize:"10px", cursor:"pointer", fontFamily:"inherit",
                  letterSpacing:"0.08em", textTransform:"uppercase"
                }}>{side==="give"?"📤 Adding to GIVE":"📥 Adding to GET"}</button>
              ))}
            </div>
            <div style={{ padding:"8px 12px", flexShrink:0 }}>
              <input value={tradeSearch} onChange={e=>setTradeSearch(e.target.value)}
                placeholder="Search players & picks..."
                style={{ width:"100%", padding:"8px 12px",
                  background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.1)",
                  borderRadius:"7px", color:"#e2e8f0", fontSize:"14px",
                  fontFamily:"inherit", boxSizing:"border-box", outline:"none" }} />
            </div>
            <div style={{ padding:"0 12px 6px", display:"flex", gap:"5px", overflowX:"auto", flexShrink:0 }}>
              {POSITIONS_TC.map(pos=>(
                <button key={pos} onClick={()=>setTradePosFilter(pos)} style={{
                  padding:"3px 9px", borderRadius:"4px", whiteSpace:"nowrap",
                  border: tradePosFilter===pos?`1px solid ${POS_COLORS[pos]||"#8b5cf6"}`:"1px solid rgba(255,255,255,0.07)",
                  background: tradePosFilter===pos?`${POS_COLORS[pos]||"#8b5cf6"}18`:"transparent",
                  color: tradePosFilter===pos?POS_COLORS[pos]||"#c4b5fd":"#4b5563",
                  fontSize:"10px", cursor:"pointer", fontFamily:"inherit"
                }}>{pos}</button>
              ))}
            </div>
            <div style={{ flex:1, overflowY:"auto", padding:"0 12px 12px" }}>
              {playersLoading && <div style={{ textAlign:"center", color:"#374151", padding:"20px 0", fontSize:"11px" }}>
                Loading player pool...
              </div>}
              {filtered.slice(0,80).map(player=>(
                <div key={player.id} onClick={()=>{
                  if(addingTo==="give") setGiveSide(p=>[...p,player.id]);
                  else setGetSide(p=>[...p,player.id]);
                }} style={{ padding:"8px 10px", borderRadius:"7px", cursor:"pointer",
                  display:"flex", justifyContent:"space-between", alignItems:"center",
                  marginBottom:"3px", background:"rgba(255,255,255,0.02)",
                  border:"1px solid rgba(255,255,255,0.04)", gap:"8px",
                  WebkitTapHighlightColor:"transparent" }}>
                  <div style={{ display:"flex", alignItems:"center", gap:"8px", minWidth:0 }}>
                    <PosTag pos={player.pos} small />
                    <div style={{ minWidth:0 }}>
                      <div style={{ fontSize:"12px", color:"#e2e8f0", overflow:"hidden",
                        textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{player.name}</div>
                      <div style={{ fontSize:"9px", color:"#4b5563" }}>
                        {player.pos!=="PICK"?`${player.team}${player.age?` · Age ${player.age}`:""} · `:""}
                        {player.owner}
                      </div>
                    </div>
                  </div>
                  <div style={{ textAlign:"right", flexShrink:0 }}>
                    <div style={{ fontSize:"12px", fontWeight:"700", color:"#8b5cf6" }}>
                      {modeAdj(player.value,player.age,player.pos).toLocaleString()}
                    </div>
                    <div style={{ fontSize:"9px", color:"#374151" }}>{TIER_LABELS[player.tier]}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tradeSubTab==="build" && (
          <div style={{ flex:1, overflowY:"auto", padding:"12px" }}>
            <div style={{ display:"flex", gap:"6px", marginBottom:"12px", alignItems:"center" }}>
              <span style={{ fontSize:"10px", color:"#4b5563" }}>MODE:</span>
              {["contender","balanced","rebuilder"].map(m=>(
                <button key={m} onClick={()=>setTradeMode(m)} style={{
                  padding:"4px 10px", borderRadius:"5px",
                  border:tradeMode===m?"1px solid #8b5cf6":"1px solid rgba(255,255,255,0.08)",
                  background:tradeMode===m?"rgba(139,92,246,0.2)":"transparent",
                  color:tradeMode===m?"#c4b5fd":"#4b5563",
                  fontSize:"10px", cursor:"pointer", fontFamily:"inherit",
                  textTransform:"uppercase", letterSpacing:"0.06em"
                }}>{m}</button>
              ))}
            </div>
            <SideList side="give" />
            <SideList side="get" />
            <button onClick={()=>{setGiveSide([]);setGetSide([]);}} style={{
              width:"100%", padding:"10px",
              background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.07)",
              borderRadius:"7px", color:"#4b5563", fontSize:"11px",
              cursor:"pointer", fontFamily:"inherit"
            }}>CLEAR TRADE</button>
          </div>
        )}

        {tradeSubTab==="result" && (
          <div style={{ flex:1, overflowY:"auto", padding:"12px" }}>
            {giveSide.length===0&&getSide.length===0 ? (
              <div style={{ textAlign:"center", color:"#374151", padding:"40px 0" }}>
                <div style={{ fontSize:"40px", marginBottom:"10px" }}>⚖️</div>
                <div style={{ fontSize:"13px" }}>Build a trade first</div>
              </div>
            ) : (
              <>
                <div style={{ background:`${verdict.c}12`, border:`1px solid ${verdict.c}30`,
                  borderRadius:"14px", padding:"20px", textAlign:"center", marginBottom:"14px" }}>
                  <div style={{ fontSize:"36px", marginBottom:"6px" }}>{verdict.e}</div>
                  <div style={{ fontSize:"28px", fontWeight:"800", color:verdict.c }}>{pct}%</div>
                  <div style={{ fontSize:"12px", color:verdict.c, fontWeight:"700",
                    letterSpacing:"0.1em", marginTop:"4px" }}>{verdict.l}</div>
                  <div style={{ fontSize:"10px", color:"#4b5563", marginTop:"2px" }}>value received</div>
                </div>
                <div style={{ marginBottom:"14px" }}>
                  <div style={{ height:"8px", background:"rgba(255,255,255,0.05)",
                    borderRadius:"4px", overflow:"hidden", display:"flex" }}>
                    <div style={{ width:`${barW}%`, background:"linear-gradient(90deg,#ef4444,#f97316)", transition:"width 0.4s" }} />
                    <div style={{ width:`${100-barW}%`, background:"linear-gradient(90deg,#16a34a,#22c55e)", transition:"width 0.4s" }} />
                  </div>
                  <div style={{ display:"flex", justifyContent:"space-between", marginTop:"5px", fontSize:"11px" }}>
                    <span style={{ color:"#ef4444" }}>GIVE: {giveTotal.toLocaleString()}</span>
                    <span style={{ color:"#22c55e" }}>GET: {getTotal.toLocaleString()}</span>
                  </div>
                </div>
                {giveTotal>0&&getTotal>0&&(
                  <Card style={{ marginBottom:"12px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <span style={{ fontSize:"11px", color:"#6b7280", letterSpacing:"0.05em" }}>DIFFERENCE</span>
                    <span style={{ fontSize:"16px", fontWeight:"700",
                      color:getTotal>=giveTotal?"#22c55e":"#ef4444" }}>
                      {getTotal>=giveTotal?"+":""}{(getTotal-giveTotal).toLocaleString()}
                    </span>
                  </Card>
                )}
                <div style={{ fontSize:"10px", color:"#4b5563", textAlign:"center", marginTop:"8px" }}>
                  Values calibrated using VORP for {rosters.length}-team league
                </div>
              </>
            )}
          </div>
        )}
      </div>
    );
  };

  // ── DRAFT BOARD TAB ─────────────────────────────────────────────────────────
  const DraftBoardTab = () => {
    const positions = ["ALL","QB","RB","WR","DL","LB","DB"];
    const filtered = ROOKIE_RANKINGS.filter(p =>
      draftFilter==="ALL" || p.pos===draftFilter
    );

    return (
      <div style={{ flex:1, overflowY:"auto" }}>
        <div style={{ padding:"8px 12px", borderBottom:"1px solid rgba(255,255,255,0.05)",
          display:"flex", gap:"5px", overflowX:"auto", flexShrink:0 }}>
          {positions.map(pos=>(
            <button key={pos} onClick={()=>setDraftFilter(pos)} style={{
              padding:"3px 9px", borderRadius:"4px", whiteSpace:"nowrap",
              border: draftFilter===pos?`1px solid ${POS_COLORS[pos]||"#8b5cf6"}`:"1px solid rgba(255,255,255,0.07)",
              background: draftFilter===pos?`${POS_COLORS[pos]||"#8b5cf6"}18`:"transparent",
              color: draftFilter===pos?POS_COLORS[pos]||"#c4b5fd":"#4b5563",
              fontSize:"10px", cursor:"pointer", fontFamily:"inherit"
            }}>{pos}</button>
          ))}
        </div>
        <div style={{ padding:"10px 12px" }}>
          <div style={{ fontSize:"10px", color:"#4b5563", letterSpacing:"0.08em", marginBottom:"10px" }}>
            2026 DYNASTY ROOKIE RANKINGS
          </div>
          {filtered.map(player=>{
            const hasNote = draftNotes[player.rank];
            return (
              <div key={player.rank} style={{ padding:"10px 12px", borderRadius:"8px",
                background:"rgba(255,255,255,0.02)", border:"1px solid rgba(255,255,255,0.05)",
                marginBottom:"5px" }}>
                <div style={{ display:"flex", alignItems:"center", gap:"10px" }}>
                  <div style={{ width:"26px", height:"26px", borderRadius:"50%", flexShrink:0,
                    background: player.rank<=5?"rgba(139,92,246,0.2)":player.rank<=10?"rgba(59,130,246,0.15)":"rgba(255,255,255,0.05)",
                    display:"flex", alignItems:"center", justifyContent:"center",
                    fontSize:"11px", fontWeight:"700",
                    color: player.rank<=5?"#c4b5fd":player.rank<=10?"#93c5fd":"#4b5563" }}>
                    {player.rank}
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:"6px", marginBottom:"2px" }}>
                      <PosTag pos={player.pos} small />
                      <span style={{ fontSize:"13px", color:"#e2e8f0", overflow:"hidden",
                        textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{player.name}</span>
                    </div>
                    <div style={{ fontSize:"10px", color:"#4b5563" }}>
                      {player.school} · Age {player.age}
                    </div>
                    <div style={{ fontSize:"10px", color:"#6b7280", marginTop:"2px", fontStyle:"italic" }}>
                      {player.note}
                    </div>
                    {hasNote && (
                      <div style={{ fontSize:"10px", color:"#f59e0b", marginTop:"4px",
                        padding:"4px 8px", background:"rgba(245,158,11,0.08)",
                        borderRadius:"4px", border:"1px solid rgba(245,158,11,0.15)" }}>
                        📝 {hasNote}
                      </div>
                    )}
                  </div>
                  <div style={{ textAlign:"right", flexShrink:0 }}>
                    <div style={{ fontSize:"12px", fontWeight:"700", color:"#8b5cf6" }}>
                      {player.value.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // ── NEWS TAB ────────────────────────────────────────────────────────────────
  const NewsTab = () => {
    const [newsFilter, setNewsFilter] = useState("All");
    const sources = ["All", ...NEWS_FEEDS.map(f=>f.name)];
    const filtered = newsFilter==="All" ? news : news.filter(n=>n.source===newsFilter);

    return (
      <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
        <div style={{ padding:"6px 12px", display:"flex", gap:"6px",
          overflowX:"auto", borderBottom:"1px solid rgba(255,255,255,0.05)", flexShrink:0 }}>
          {sources.map(s=>{
            const feed=NEWS_FEEDS.find(f=>f.name===s);
            const color=feed?.color||"#6b7280";
            const active=newsFilter===s;
            return (
              <button key={s} onClick={()=>setNewsFilter(s)} style={{
                padding:"4px 10px", borderRadius:"5px", whiteSpace:"nowrap",
                border:active?`1px solid ${color}`:"1px solid rgba(255,255,255,0.08)",
                background:active?`${color}20`:"transparent",
                color:active?color:"#4b5563",
                fontSize:"10px", cursor:"pointer", fontFamily:"inherit"
              }}>{s}</button>
            );
          })}
          <button onClick={()=>{setNewsLoaded(false);setNews([]);}} style={{
            padding:"4px 10px", borderRadius:"5px", whiteSpace:"nowrap",
            border:"1px solid rgba(255,255,255,0.08)", background:"transparent",
            color:"#4b5563", fontSize:"10px", cursor:"pointer", fontFamily:"inherit"
          }}>↺</button>
        </div>
        <div style={{ flex:1, overflowY:"auto", padding:"10px 12px" }}>
          {newsLoading ? (
            <div style={{ textAlign:"center", color:"#4b5563", padding:"40px 0", fontSize:"12px" }}>
              Loading news feeds...
            </div>
          ) : filtered.length===0 ? (
            <div style={{ textAlign:"center", color:"#374151", padding:"40px 0" }}>
              <div style={{ fontSize:"32px", marginBottom:"8px" }}>📰</div>
              <div style={{ fontSize:"13px" }}>No news loaded</div>
            </div>
          ) : filtered.map((item,i)=>{
            const feed=NEWS_FEEDS.find(f=>f.name===item.source);
            return (
              <a key={i} href={item.link} target="_blank" rel="noopener noreferrer"
                style={{ display:"block", textDecoration:"none", padding:"11px 12px",
                  borderRadius:"9px", background:"rgba(255,255,255,0.02)",
                  border:`1px solid ${feed?.color||"#6b7280"}18`, marginBottom:"7px" }}>
                <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"5px", gap:"8px" }}>
                  <span style={{ fontSize:"9px", padding:"2px 6px", borderRadius:"3px",
                    background:`${feed?.color||"#6b7280"}20`, color:feed?.color||"#6b7280",
                    letterSpacing:"0.05em", fontWeight:"700", flexShrink:0 }}>{item.source}</span>
                  <span style={{ fontSize:"9px", color:"#4b5563" }}>
                    {item.pubDate?new Date(item.pubDate).toLocaleDateString():""}
                  </span>
                </div>
                <div style={{ fontSize:"13px", color:"#e2e8f0", lineHeight:"1.4", marginBottom:"4px" }}>
                  {item.title}
                </div>
                {item.description&&(
                  <div style={{ fontSize:"11px", color:"#6b7280", lineHeight:"1.4" }}>
                    {item.description.slice(0,150)}…
                  </div>
                )}
              </a>
            );
          })}
        </div>
      </div>
    );
  };

  // ── TRANSACTIONS TAB ────────────────────────────────────────────────────────
  const TransactionsTab = () => {
    const typeIcon={trade:"🔄",waiver:"📋",free_agent:"✍️"};
    const typeColor={trade:"#f59e0b",waiver:"#8b5cf6",free_agent:"#22c55e"};
    return (
      <div style={{ flex:1, overflowY:"auto", padding:"12px" }}>
        {transactions.length===0 ? (
          <div style={{ textAlign:"center", color:"#374151", padding:"40px 0" }}>
            <div style={{ fontSize:"32px", marginBottom:"8px" }}>📭</div>
            <div style={{ fontSize:"13px" }}>No transactions yet</div>
          </div>
        ) : transactions.slice(0,60).map((tx,i)=>{
          const color=typeColor[tx.type]||"#6b7280";
          const icon=typeIcon[tx.type]||"📝";
          const date=tx.created?new Date(tx.created).toLocaleDateString():"";
          const adds=Object.keys(tx.adds||{});
          const drops=Object.keys(tx.drops||{});
          return (
            <div key={i} style={{ padding:"10px 12px", borderRadius:"8px",
              background:"rgba(255,255,255,0.02)", border:`1px solid ${color}18`,
              marginBottom:"5px" }}>
              <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"5px" }}>
                <div style={{ display:"flex", alignItems:"center", gap:"5px" }}>
                  <span>{icon}</span>
                  <span style={{ fontSize:"11px", color, textTransform:"uppercase",
                    letterSpacing:"0.06em", fontWeight:"700" }}>{tx.type?.replace("_"," ")}</span>
                </div>
                <span style={{ fontSize:"10px", color:"#4b5563" }}>{date}</span>
              </div>
              {adds.length>0&&(
                <div style={{ marginBottom:"2px" }}>
                  <span style={{ fontSize:"10px", color:"#22c55e" }}>+ </span>
                  <span style={{ fontSize:"11px", color:"#94a3b8" }}>
                    {adds.map(id=>getPlayerName(id)).join(", ")}
                  </span>
                </div>
              )}
              {drops.length>0&&(
                <div>
                  <span style={{ fontSize:"10px", color:"#ef4444" }}>- </span>
                  <span style={{ fontSize:"11px", color:"#94a3b8" }}>
                    {drops.map(id=>getPlayerName(id)).join(", ")}
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  // ── NAV ──────────────────────────────────────────────────────────────────────
  const NAV = [
    {id:"roster",    icon:"👥", label:"Roster"},
    {id:"standings", icon:"📊", label:"Standings"},
    {id:"trade",     icon:"⚖️", label:"Trade"},
    {id:"fa",        icon:"🔍", label:"FA"},
    {id:"more",      icon:"⋯",  label:"More"},
  ];

  const [showMore, setShowMore] = useState(false);
  const MORE_TABS = [
    {id:"news",   icon:"📰", label:"News"},
    {id:"draft",  icon:"📋", label:"Draft Board"},
    {id:"matchups",icon:"📅",label:"Matchups"},
    {id:"txns",   icon:"🔄", label:"Transactions"},
  ];

  const activeLabel = [...NAV, ...MORE_TABS].find(n=>n.id===tab)?.label || "";

  return (
    <div style={{ minHeight:"100vh", background:"#08080f", color:"#e2e8f0",
      fontFamily:"'DM Mono','Courier New',monospace",
      display:"flex", flexDirection:"column", maxWidth:"600px", margin:"0 auto" }}>

      {/* Header */}
      <div style={{ background:"linear-gradient(135deg,#0f0f1a,#150a2a)",
        borderBottom:"1px solid rgba(139,92,246,0.25)", padding:"11px 14px", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
            <div style={{ width:"26px", height:"26px", borderRadius:"6px",
              background:"linear-gradient(135deg,#8b5cf6,#3b82f6)",
              display:"flex", alignItems:"center", justifyContent:"center", fontSize:"13px" }}>👑</div>
            <div>
              <div style={{ fontSize:"13px", fontWeight:"700", color:"#fff", letterSpacing:"0.04em" }}>
                {leagueData?.name || "Dynasty Command"}
              </div>
              <div style={{ fontSize:"9px", color:"#4b5563", letterSpacing:"0.08em" }}>
                {leagueData?.season} · {rosters.length} teams · {activeLabel}
              </div>
            </div>
          </div>
          <button onClick={onDisconnect} style={{
            padding:"4px 8px", borderRadius:"5px", fontSize:"9px",
            background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)",
            color:"#4b5563", cursor:"pointer", fontFamily:"inherit", letterSpacing:"0.04em"
          }}>← Leagues</button>
        </div>
      </div>

      {/* More menu overlay */}
      {showMore && (
        <div style={{ position:"fixed", bottom:"50px", left:"50%", transform:"translateX(-50%)",
          width:"min(600px,100%)", background:"#0f0f1a",
          borderTop:"1px solid rgba(139,92,246,0.2)", zIndex:100,
          display:"grid", gridTemplateColumns:"1fr 1fr" }}>
          {MORE_TABS.map(item=>(
            <button key={item.id} onClick={()=>{ setTab(item.id); setShowMore(false); }} style={{
              padding:"14px", background:"transparent",
              border:"none", borderBottom:"1px solid rgba(255,255,255,0.05)",
              color: tab===item.id?"#c4b5fd":"#6b7280",
              fontSize:"11px", cursor:"pointer", fontFamily:"inherit",
              display:"flex", alignItems:"center", gap:"8px", letterSpacing:"0.04em"
            }}>
              <span style={{ fontSize:"18px" }}>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </div>
      )}
      {showMore && <div onClick={()=>setShowMore(false)}
        style={{ position:"fixed", inset:0, zIndex:99 }} />}

      {/* Content */}
      <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
        {tab==="roster"    && <RosterTab />}
        {tab==="standings" && <StandingsTab />}
        {tab==="trade"     && <TradeCalcTab />}
        {tab==="fa"        && <FreeAgencyTab />}
        {tab==="news"      && <NewsTab />}
        {tab==="draft"     && <DraftBoardTab />}
        {tab==="matchups"  && <MatchupsTab />}
        {tab==="txns"      && <TransactionsTab />}
      </div>

      {/* Bottom nav */}
      <div style={{ display:"flex", borderTop:"1px solid rgba(255,255,255,0.07)",
        background:"#0a0a14", flexShrink:0 }}>
        {NAV.map(item=>{
          const isMore = item.id==="more";
          const active = isMore ? showMore : tab===item.id;
          return (
            <button key={item.id} onClick={()=>{
              if(isMore){ setShowMore(s=>!s); }
              else { setTab(item.id); setShowMore(false); }
            }} style={{
              flex:1, padding:"10px 4px 8px",
              background: active?"rgba(139,92,246,0.1)":"transparent",
              border:"none",
              borderTop: active?"2px solid #8b5cf6":"2px solid transparent",
              color: active?"#c4b5fd":"#4b5563",
              fontSize:"10px", cursor:"pointer", fontFamily:"inherit",
              display:"flex", flexDirection:"column", alignItems:"center",
              gap:"2px", letterSpacing:"0.04em"
            }}>
              <span style={{ fontSize:"16px", lineHeight:1 }}>{item.icon}</span>
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ── Root ───────────────────────────────────────────────────────────────────────
function App() {
  const [leagueId, setLeagueId]     = useState(null);
  const [leagueData, setLeagueData] = useState(null);

  const handleLoad = (id, data) => {
    setLeagueId(id);
    setLeagueData(data);
  };

  const handleDisconnect = () => {
    setLeagueId(null);
    setLeagueData(null);
  };

  if (!leagueId) return <LeagueEntryScreen onLoad={handleLoad} />;
  return <LeagueApp leagueId={leagueId} initialLeague={leagueData} onDisconnect={handleDisconnect} />;
}

ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(App));
