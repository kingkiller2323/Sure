const { useState, useEffect, useCallback } = React;

// ── Constants ─────────────────────────────────────────────────────────────────
const LEAGUE_ID = "1313709679045541888";
const SLEEPER_BASE = "https://api.sleeper.app/v1";
const MY_USERNAME = "Vincantiy";

const POS_COLORS = {
  QB: "#ef4444", RB: "#22c55e", WR: "#3b82f6", TE: "#f59e0b",
  DL: "#8b5cf6", LB: "#ec4899", DB: "#06b6d4", K: "#f97316",
  DEF: "#64748b", PICK: "#94a3b8", FLEX: "#a78bfa", IDP: "#818cf8"
};

const STARTER_SLOTS = ["QB","RB","RB","RB","WR","WR","WR","WR","TE","FLEX","FLEX","K","DEF","DL","DL","DL","DL","LB","LB","LB","DB","DB","IDP","IDP"];

const POSITION_ORDER = { QB:0, RB:1, WR:2, TE:3, K:4, DEF:5, DL:6, LB:7, DB:8 };

// Manually built pick values for trade calc
const PICK_VALUES = {
  "2026 1.01":9200,"2026 1.02":8800,"2026 1.03":8400,"2026 1.04":8000,
  "2026 1.05":7600,"2026 1.06":7200,"2026 1.07":6800,"2026 1.08":6400,
  "2026 1.09":6000,"2026 1.10":5600,
  "2026 2nd Early":4200,"2026 2nd Mid":3600,"2026 2nd Late":3000,
  "2026 3rd Early":2400,"2026 3rd Mid":2000,"2026 3rd Late":1600,
  "2026 4th":1200,"2026 5th":900,
  "2027 1st Early":8600,"2027 1st Mid":7800,"2027 1st Late":7000,
  "2027 2nd Early":4800,"2027 2nd Mid":4000,"2027 2nd Late":3200,
  "2027 3rd":2200,"2027 4th":1400,
  "2028 1st Early":7200,"2028 1st Mid":6400,"2028 1st Late":5600,
  "2028 2nd":3600,"2028 3rd":2000,
};

// ── Sleeper API helpers ───────────────────────────────────────────────────────
// Uses corsproxy.io to bypass CORS restrictions in embedded environments
const CORS_PROXY = "https://corsproxy.io/?";
const api = async (path) => {
  const url = `${SLEEPER_BASE}${path}`;
  // Try direct first, fall back to proxy
  try {
    const res = await fetch(url);
    if (res.ok) return res.json();
  } catch(e) {}
  const res = await fetch(`${CORS_PROXY}${encodeURIComponent(url)}`);
  if (!res.ok) throw new Error(`API error ${res.status}: ${path}`);
  return res.json();
};

// ── Utility ───────────────────────────────────────────────────────────────────
function PosTag({ pos, small }) {
  const size = small ? "9px" : "10px";
  return (
    <span style={{
      fontSize: size, fontWeight: "700", padding: small ? "1px 4px" : "2px 6px",
      borderRadius: "3px", background: `${POS_COLORS[pos] || "#6b7280"}20`,
      color: POS_COLORS[pos] || "#6b7280", letterSpacing: "0.04em",
      display: "inline-block", textAlign: "center"
    }}>{pos}</span>
  );
}

function statusDot(status) {
  if (!status || status === "Active") return null;
  const colors = { Injured_Reserve: "#ef4444", Questionable: "#f59e0b",
    Doubtful: "#f97316", Out: "#ef4444", PUP: "#8b5cf6", COV: "#06b6d4" };
  const labels = { Injured_Reserve: "IR", Questionable: "Q", Doubtful: "D",
    Out: "OUT", PUP: "PUP", COV: "COV" };
  const color = colors[status] || "#6b7280";
  return (
    <span style={{
      fontSize: "8px", padding: "1px 4px", borderRadius: "3px",
      background: `${color}25`, color, fontWeight: "700", marginLeft: "4px"
    }}>{labels[status] || status}</span>
  );
}

// ── News RSS Feed URLs (CORS-proxied) ─────────────────────────────────────────
const NEWS_FEEDS = [
  { name: "Rotowire",    url: "https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fwww.rotowire.com%2Frss%2Fnews.php", color: "#22c55e" },
  { name: "ESPN NFL",    url: "https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fwww.espn.com%2Fespn%2Frss%2Fnfl%2Fnews", color: "#ef4444" },
  { name: "Yahoo Sports",url: "https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fsports.yahoo.com%2Fnfl%2Frss.xml", color: "#8b5cf6" },
  { name: "NFL.com",     url: "https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fwww.nfl.com%2Frss%2Frsslanding%3FsearchString%3Dnews", color: "#3b82f6" },
];

// ── Main App ──────────────────────────────────────────────────────────────────
function BDLCommandCenter() {
  const [tab, setTab] = useState("roster");
  const [leagueData, setLeagueData] = useState(null);
  const [users, setUsers] = useState([]);
  const [rosters, setRosters] = useState([]);
  const [players, setPlayers] = useState({});
  const [transactions, setTransactions] = useState([]);
  const [matchups, setMatchups] = useState([]);
  const [myRosterId, setMyRosterId] = useState(null);
  const [myUserId, setMyUserId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [news, setNews] = useState([]);
  const [newsLoading, setNewsLoading] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState(null);
  // Trade calc state
  const [giveSide, setGiveSide] = useState([]);
  const [getSide, setGetSide] = useState([]);
  const [tradeTab, setTradeTab] = useState("search");
  const [addingTo, setAddingTo] = useState("give");
  const [tradeSearch, setTradeSearch] = useState("");
  const [tradePosFilter, setTradePosFilter] = useState("ALL");
  const [tradeMode, setTradeMode] = useState("balanced");

  // ── Load Sleeper data ─────────────────────────────────────────────────────
  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        // League info
        const league = await api(`/league/${LEAGUE_ID}`);
        setLeagueData(league);
        // Users
        const usersData = await api(`/league/${LEAGUE_ID}/users`);
        setUsers(usersData);
        // Find my user
        const me = usersData.find(u =>
          u.display_name?.toLowerCase() === MY_USERNAME.toLowerCase() ||
          u.username?.toLowerCase() === MY_USERNAME.toLowerCase()
        );
        if (me) setMyUserId(me.user_id);
        // Rosters
        const rostersData = await api(`/league/${LEAGUE_ID}/rosters`);
        setRosters(rostersData);
        if (me) {
          const myRoster = rostersData.find(r => r.owner_id === me.user_id);
          if (myRoster) setMyRosterId(myRoster.roster_id);
          setSelectedTeam(myRoster?.roster_id || rostersData[0]?.roster_id);
        } else {
          setSelectedTeam(rostersData[0]?.roster_id);
        }
        // Players (large file - load async)
        const playersData = await api("/players/nfl");
        setPlayers(playersData);
        // Transactions
        try {
          const trans = await api(`/league/${LEAGUE_ID}/transactions/1`);
          setTransactions(trans || []);
        } catch(e) { setTransactions([]); }
        // Matchups week 1
        try {
          const m = await api(`/league/${LEAGUE_ID}/matchups/1`);
          setMatchups(m || []);
        } catch(e) { setMatchups([]); }
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };
    load();
  }, []);

  // ── Load News ─────────────────────────────────────────────────────────────
  useEffect(() => {
    if (tab !== "news") return;
    if (news.length > 0) return;
    const loadNews = async () => {
      setNewsLoading(true);
      const all = [];
      for (const feed of NEWS_FEEDS) {
        try {
          const res = await fetch(feed.url);
          const data = await res.json();
          if (data.items) {
            data.items.slice(0, 15).forEach(item => {
              all.push({
                title: item.title,
                link: item.link,
                pubDate: item.pubDate,
                description: item.description?.replace(/<[^>]+>/g, "").slice(0, 180),
                source: feed.name,
                color: feed.color,
              });
            });
          }
        } catch(e) {}
      }
      all.sort((a, b) => new Date(b.pubDate) - new Date(a.pubDate));
      setNews(all);
      setNewsLoading(false);
    };
    loadNews();
  }, [tab]);

  // ── Derived helpers ───────────────────────────────────────────────────────
  const getUserForRoster = useCallback((roster) => {
    return users.find(u => u.user_id === roster.owner_id);
  }, [users]);

  const getTeamName = useCallback((roster) => {
    const user = getUserForRoster(roster);
    return user?.metadata?.team_name || user?.display_name || `Team ${roster.roster_id}`;
  }, [getUserForRoster]);

  const getPlayerInfo = useCallback((playerId) => {
    return players[playerId] || null;
  }, [players]);

  const getPlayerName = useCallback((playerId) => {
    const p = players[playerId];
    if (!p) return playerId;
    return `${p.first_name} ${p.last_name}`;
  }, [players]);

  const getPlayerValue = useCallback((playerId) => {
    const p = players[playerId];
    if (!p) return 1000;
    // Simple value model based on position and age
    const pos = p.fantasy_positions?.[0] || p.position;
    const age = p.age || 25;
    const baseValues = { QB: 6000, RB: 5500, WR: 5500, TE: 5000, DL: 5000, LB: 4800, DB: 4500, K: 2000, DEF: 1500 };
    let base = baseValues[pos] || 2000;
    // Age curve
    if (age <= 22) base *= 1.3;
    else if (age <= 24) base *= 1.15;
    else if (age <= 26) base *= 1.0;
    else if (age <= 28) base *= 0.9;
    else if (age <= 30) base *= 0.75;
    else base *= 0.55;
    return Math.round(base);
  }, [players]);

  // ── LOADING STATE ─────────────────────────────────────────────────────────
  if (loading) {
    return (
      <div style={{
        minHeight: "100vh", background: "#08080f",
        display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center",
        fontFamily: "'DM Mono', monospace", color: "#8b5cf6", gap: "16px"
      }}>
        <div style={{ fontSize: "40px" }}>👑</div>
        <div style={{ fontSize: "14px", letterSpacing: "0.1em" }}>LOADING BDL COMMAND CENTER</div>
        <div style={{ fontSize: "11px", color: "#374151", letterSpacing: "0.08em" }}>
          Connecting to Sleeper...
        </div>
        <div style={{
          width: "200px", height: "3px",
          background: "rgba(139,92,246,0.15)", borderRadius: "2px", overflow: "hidden"
        }}>
          <div style={{
            height: "100%", width: "40%",
            background: "linear-gradient(90deg,#8b5cf6,#3b82f6)",
            borderRadius: "2px",
            animation: "slide 1.2s ease-in-out infinite",
          }} />
        </div>
        <style>{`
          @keyframes slide {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(600%); }
          }
        `}</style>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{
        minHeight: "100vh", background: "#08080f",
        display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center",
        fontFamily: "'DM Mono', monospace", color: "#ef4444", gap: "12px",
        padding: "24px", textAlign: "center"
      }}>
        <div style={{ fontSize: "40px" }}>⚠️</div>
        <div style={{ fontSize: "14px" }}>Failed to connect to Sleeper</div>
        <div style={{ fontSize: "11px", color: "#374151", maxWidth: "300px" }}>{error}</div>
        <button onClick={() => window.location.reload()} style={{
          marginTop: "8px", padding: "10px 20px", borderRadius: "8px",
          background: "rgba(139,92,246,0.2)", border: "1px solid #8b5cf6",
          color: "#c4b5fd", fontSize: "12px", cursor: "pointer",
          fontFamily: "inherit"
        }}>RETRY</button>
      </div>
    );
  }

  // ── ROSTER TAB ────────────────────────────────────────────────────────────
  const RosterTab = () => {
    const roster = rosters.find(r => r.roster_id === selectedTeam);
    if (!roster) return null;
    const user = getUserForRoster(roster);
    const teamName = getTeamName(roster);
    const allPlayerIds = [...(roster.players || [])];
    const starterIds = roster.starters || [];
    const taxiIds = roster.taxi || [];
    const irIds = roster.reserve || [];
    const benchIds = allPlayerIds.filter(id =>
      !starterIds.includes(id) && !taxiIds.includes(id) && !irIds.includes(id)
    );

    const renderPlayerRow = (playerId, isStarter) => {
      const p = getPlayerInfo(playerId);
      const name = getPlayerName(playerId);
      const pos = p?.fantasy_positions?.[0] || p?.position || "?";
      const team = p?.team || "FA";
      const age = p?.age;
      const status = p?.injury_status;
      return (
        <div key={playerId} style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "8px 10px", borderRadius: "7px",
          background: isStarter ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.02)",
          border: `1px solid ${isStarter ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0.03)"}`,
          marginBottom: "3px", gap: "8px"
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", minWidth: 0 }}>
            <PosTag pos={pos} />
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: "13px", color: isStarter ? "#f1f5f9" : "#94a3b8",
                overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {name}
                {statusDot(status)}
              </div>
              <div style={{ fontSize: "10px", color: "#4b5563" }}>
                {team}{age ? ` · Age ${age}` : ""}
              </div>
            </div>
          </div>
          <div style={{ fontSize: "12px", color: "#4b5563", flexShrink: 0 }}>
            {getPlayerValue(playerId).toLocaleString()}
          </div>
        </div>
      );
    };

    const wins = roster.settings?.wins || 0;
    const losses = roster.settings?.losses || 0;
    const pts = ((roster.settings?.fpts || 0) + (roster.settings?.fpts_decimal || 0) / 100).toFixed(1);

    return (
      <div style={{ flex: 1, overflowY: "auto" }}>
        {/* Team selector */}
        <div style={{
          padding: "10px 12px", borderBottom: "1px solid rgba(255,255,255,0.06)",
          display: "flex", gap: "6px", overflowX: "auto", flexShrink: 0
        }}>
          {rosters.map(r => {
            const u = getUserForRoster(r);
            const name = u?.metadata?.team_name || u?.display_name || `T${r.roster_id}`;
            const isMe = r.roster_id === myRosterId;
            const active = r.roster_id === selectedTeam;
            return (
              <button key={r.roster_id} onClick={() => setSelectedTeam(r.roster_id)} style={{
                padding: "5px 10px", borderRadius: "6px", whiteSpace: "nowrap",
                border: active ? "1px solid #8b5cf6" : "1px solid rgba(255,255,255,0.08)",
                background: active ? "rgba(139,92,246,0.2)" : "rgba(255,255,255,0.03)",
                color: active ? "#c4b5fd" : isMe ? "#f59e0b" : "#6b7280",
                fontSize: "10px", cursor: "pointer", fontFamily: "inherit",
              }}>{isMe ? "👑 " : ""}{name.length > 12 ? name.slice(0,12)+"…" : name}</button>
            );
          })}
        </div>

        <div style={{ padding: "12px" }}>
          {/* Team header */}
          <div style={{
            background: "linear-gradient(135deg, rgba(139,92,246,0.1), rgba(59,130,246,0.05))",
            border: "1px solid rgba(139,92,246,0.2)",
            borderRadius: "12px", padding: "14px", marginBottom: "14px"
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <div style={{ fontSize: "16px", fontWeight: "700", color: "#fff" }}>{teamName}</div>
                <div style={{ fontSize: "11px", color: "#6b7280", marginTop: "2px" }}>
                  {user?.display_name} · Roster #{roster.roster_id}
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: "18px", fontWeight: "800", color: "#22c55e" }}>{wins}-{losses}</div>
                <div style={{ fontSize: "10px", color: "#4b5563" }}>{pts} pts</div>
              </div>
            </div>
          </div>

          {/* Starters */}
          <div style={{ marginBottom: "14px" }}>
            <div style={{ fontSize: "10px", color: "#8b5cf6", letterSpacing: "0.1em", marginBottom: "6px", fontWeight: "700" }}>
              ⚡ STARTERS ({starterIds.filter(id => id !== "0").length}/{STARTER_SLOTS.length})
            </div>
            {starterIds.filter(id => id && id !== "0").map(id => renderPlayerRow(id, true))}
            {/* Empty slots */}
            {starterIds.filter(id => id === "0").map((_, i) => (
              <div key={`empty-${i}`} style={{
                padding: "7px 10px", borderRadius: "7px",
                border: "1px dashed rgba(255,255,255,0.06)",
                marginBottom: "3px", fontSize: "11px", color: "#1f2937"
              }}>EMPTY SLOT</div>
            ))}
          </div>

          {/* Bench */}
          {benchIds.length > 0 && (
            <div style={{ marginBottom: "14px" }}>
              <div style={{ fontSize: "10px", color: "#6b7280", letterSpacing: "0.1em", marginBottom: "6px", fontWeight: "700" }}>
                📋 BENCH ({benchIds.length})
              </div>
              {benchIds.map(id => renderPlayerRow(id, false))}
            </div>
          )}

          {/* Taxi */}
          {taxiIds.length > 0 && (
            <div style={{ marginBottom: "14px" }}>
              <div style={{ fontSize: "10px", color: "#f59e0b", letterSpacing: "0.1em", marginBottom: "6px", fontWeight: "700" }}>
                🚕 TAXI ({taxiIds.length}/5)
              </div>
              {taxiIds.map(id => renderPlayerRow(id, false))}
            </div>
          )}

          {/* IR */}
          {irIds.length > 0 && (
            <div style={{ marginBottom: "14px" }}>
              <div style={{ fontSize: "10px", color: "#ef4444", letterSpacing: "0.1em", marginBottom: "6px", fontWeight: "700" }}>
                🏥 INJURED RESERVE ({irIds.length})
              </div>
              {irIds.map(id => renderPlayerRow(id, false))}
            </div>
          )}
        </div>
      </div>
    );
  };

  // ── STANDINGS TAB ─────────────────────────────────────────────────────────
  const StandingsTab = () => {
    const sorted = [...rosters].sort((a, b) => {
      const aw = a.settings?.wins || 0;
      const bw = b.settings?.wins || 0;
      if (bw !== aw) return bw - aw;
      const ap = (a.settings?.fpts || 0) + (a.settings?.fpts_decimal || 0) / 100;
      const bp = (b.settings?.fpts || 0) + (b.settings?.fpts_decimal || 0) / 100;
      return bp - ap;
    });

    return (
      <div style={{ flex: 1, overflowY: "auto", padding: "12px" }}>
        <div style={{ fontSize: "10px", color: "#4b5563", letterSpacing: "0.1em", marginBottom: "10px" }}>
          {leagueData?.name} · Season {leagueData?.season}
        </div>
        {sorted.map((roster, idx) => {
          const user = getUserForRoster(roster);
          const teamName = getTeamName(roster);
          const wins = roster.settings?.wins || 0;
          const losses = roster.settings?.losses || 0;
          const pts = ((roster.settings?.fpts || 0) + (roster.settings?.fpts_decimal || 0) / 100).toFixed(1);
          const isMe = roster.roster_id === myRosterId;
          const playoff = idx < 6;
          return (
            <div key={roster.roster_id} style={{
              padding: "12px 14px", borderRadius: "10px",
              background: isMe ? "rgba(139,92,246,0.1)" : "rgba(255,255,255,0.02)",
              border: isMe ? "1px solid rgba(139,92,246,0.3)" : `1px solid ${playoff ? "rgba(34,197,94,0.1)" : "rgba(255,255,255,0.04)"}`,
              marginBottom: "6px",
              display: "flex", alignItems: "center", gap: "12px"
            }}>
              <div style={{
                width: "28px", height: "28px", borderRadius: "50%",
                background: idx === 0 ? "rgba(255,215,0,0.15)" : idx === 1 ? "rgba(192,192,192,0.15)" : idx === 2 ? "rgba(205,127,50,0.15)" : "rgba(255,255,255,0.05)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: idx < 3 ? "14px" : "12px",
                color: idx === 0 ? "#ffd700" : idx === 1 ? "#c0c0c0" : idx === 2 ? "#cd7f32" : "#4b5563",
                fontWeight: "700", flexShrink: 0
              }}>
                {idx < 3 ? ["🥇","🥈","🥉"][idx] : idx+1}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: "13px", color: isMe ? "#c4b5fd" : "#e2e8f0",
                  overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontWeight: isMe ? "700" : "400" }}>
                  {isMe ? "👑 " : ""}{teamName}
                </div>
                <div style={{ fontSize: "10px", color: "#4b5563" }}>{user?.display_name}</div>
              </div>
              <div style={{ textAlign: "right", flexShrink: 0 }}>
                <div style={{ fontSize: "14px", fontWeight: "700",
                  color: playoff ? "#22c55e" : "#6b7280" }}>{wins}-{losses}</div>
                <div style={{ fontSize: "10px", color: "#4b5563" }}>{pts} pts</div>
              </div>
              {playoff && (
                <div style={{
                  fontSize: "9px", padding: "2px 6px", borderRadius: "3px",
                  background: "rgba(34,197,94,0.1)", color: "#22c55e",
                  letterSpacing: "0.05em", flexShrink: 0
                }}>PLAYOFF</div>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  // ── TRANSACTIONS TAB ──────────────────────────────────────────────────────
  const TransactionsTab = () => {
    const typeIcon = { trade: "🔄", waiver: "📋", free_agent: "✍️" };
    const typeColor = { trade: "#f59e0b", waiver: "#8b5cf6", free_agent: "#22c55e" };

    return (
      <div style={{ flex: 1, overflowY: "auto", padding: "12px" }}>
        {transactions.length === 0 ? (
          <div style={{ textAlign: "center", color: "#374151", padding: "40px 0" }}>
            <div style={{ fontSize: "32px", marginBottom: "8px" }}>📭</div>
            <div style={{ fontSize: "13px" }}>No transactions yet</div>
          </div>
        ) : transactions.slice(0, 50).map((tx, i) => {
          const color = typeColor[tx.type] || "#6b7280";
          const icon = typeIcon[tx.type] || "📝";
          const date = tx.created ? new Date(tx.created).toLocaleDateString() : "";
          const adds = Object.keys(tx.adds || {});
          const drops = Object.keys(tx.drops || {});
          return (
            <div key={i} style={{
              padding: "10px 12px", borderRadius: "8px",
              background: "rgba(255,255,255,0.02)",
              border: `1px solid ${color}20`,
              marginBottom: "6px"
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                  <span>{icon}</span>
                  <span style={{ fontSize: "11px", color, textTransform: "uppercase", letterSpacing: "0.06em", fontWeight: "700" }}>
                    {tx.type?.replace("_"," ")}
                  </span>
                </div>
                <span style={{ fontSize: "10px", color: "#4b5563" }}>{date}</span>
              </div>
              {adds.length > 0 && (
                <div style={{ marginBottom: "3px" }}>
                  <span style={{ fontSize: "10px", color: "#22c55e" }}>+ </span>
                  <span style={{ fontSize: "11px", color: "#94a3b8" }}>
                    {adds.map(id => getPlayerName(id)).join(", ")}
                  </span>
                </div>
              )}
              {drops.length > 0 && (
                <div>
                  <span style={{ fontSize: "10px", color: "#ef4444" }}>- </span>
                  <span style={{ fontSize: "11px", color: "#94a3b8" }}>
                    {drops.map(id => getPlayerName(id)).join(", ")}
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  // ── NEWS TAB ──────────────────────────────────────────────────────────────
  const NewsTab = () => {
    const [newsFilter, setNewsFilter] = useState("All");
    const sources = ["All", ...NEWS_FEEDS.map(f => f.name)];
    const filtered = newsFilter === "All" ? news : news.filter(n => n.source === newsFilter);

    return (
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div style={{
          padding: "8px 12px", display: "flex", gap: "6px",
          overflowX: "auto", borderBottom: "1px solid rgba(255,255,255,0.05)", flexShrink: 0
        }}>
          {sources.map(s => {
            const feed = NEWS_FEEDS.find(f => f.name === s);
            const color = feed?.color || "#6b7280";
            const active = newsFilter === s;
            return (
              <button key={s} onClick={() => setNewsFilter(s)} style={{
                padding: "4px 10px", borderRadius: "5px", whiteSpace: "nowrap",
                border: active ? `1px solid ${color}` : "1px solid rgba(255,255,255,0.08)",
                background: active ? `${color}20` : "transparent",
                color: active ? color : "#4b5563",
                fontSize: "10px", cursor: "pointer", fontFamily: "inherit"
              }}>{s}</button>
            );
          })}
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: "12px" }}>
          {newsLoading ? (
            <div style={{ textAlign: "center", color: "#4b5563", padding: "40px 0", fontSize: "13px" }}>
              Loading news feeds...
            </div>
          ) : filtered.length === 0 ? (
            <div style={{ textAlign: "center", color: "#374151", padding: "40px 0" }}>
              <div style={{ fontSize: "32px", marginBottom: "8px" }}>📰</div>
              <div style={{ fontSize: "13px" }}>No news loaded</div>
            </div>
          ) : filtered.map((item, i) => {
            const feed = NEWS_FEEDS.find(f => f.name === item.source);
            return (
              <a key={i} href={item.link} target="_blank" rel="noopener noreferrer" style={{
                display: "block", textDecoration: "none",
                padding: "12px", borderRadius: "10px",
                background: "rgba(255,255,255,0.02)",
                border: `1px solid ${feed?.color || "#6b7280"}18`,
                marginBottom: "8px"
              }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "5px", gap: "8px" }}>
                  <span style={{
                    fontSize: "9px", padding: "2px 6px", borderRadius: "3px",
                    background: `${feed?.color || "#6b7280"}20`,
                    color: feed?.color || "#6b7280",
                    letterSpacing: "0.05em", fontWeight: "700", flexShrink: 0
                  }}>{item.source}</span>
                  <span style={{ fontSize: "9px", color: "#4b5563" }}>
                    {item.pubDate ? new Date(item.pubDate).toLocaleDateString() : ""}
                  </span>
                </div>
                <div style={{ fontSize: "13px", color: "#e2e8f0", lineHeight: "1.4", marginBottom: "5px" }}>
                  {item.title}
                </div>
                {item.description && (
                  <div style={{ fontSize: "11px", color: "#6b7280", lineHeight: "1.4" }}>
                    {item.description.slice(0, 140)}…
                  </div>
                )}
              </a>
            );
          })}
        </div>
      </div>
    );
  };

  // ── TRADE CALCULATOR TAB ──────────────────────────────────────────────────
  const TradeCalcTab = () => {
    // Build player pool from all rostered players
    const allRosteredIds = rosters.flatMap(r => [
      ...(r.players || []),
      ...(r.taxi || []),
    ]);
    const uniqueIds = [...new Set(allRosteredIds)];
    const playerPool = uniqueIds
      .map(id => {
        const p = getPlayerInfo(id);
        if (!p) return null;
        const name = `${p.first_name} ${p.last_name}`;
        const pos = p.fantasy_positions?.[0] || p.position || "?";
        const value = getPlayerValue(id);
        const roster = rosters.find(r => (r.players||[]).includes(id) || (r.taxi||[]).includes(id));
        const owner = roster ? getTeamName(roster) : "FA";
        return { id, name, pos, value, age: p.age || 0, team: p.team || "FA", owner, tier: value > 8000 ? 1 : value > 5500 ? 2 : value > 3000 ? 3 : 4 };
      })
      .filter(Boolean)
      .sort((a, b) => b.value - a.value);

    // Add picks
    const picks = Object.entries(PICK_VALUES).map(([name, value]) => ({
      id: name, name, pos: "PICK", value, age: 0, team: "PICK", owner: "–", tier: value > 7000 ? 1 : value > 4000 ? 2 : value > 2000 ? 3 : 4
    }));

    const fullPool = [...playerPool, ...picks];
    const selected = new Set([...giveSide, ...getSide]);
    const POSITIONS_TC = ["ALL","QB","RB","WR","TE","DL","LB","DB","PICK"];

    const filtered = fullPool.filter(p => {
      const matchSearch = p.name.toLowerCase().includes(tradeSearch.toLowerCase());
      const matchPos = tradePosFilter === "ALL" || p.pos === tradePosFilter;
      return matchSearch && matchPos && !selected.has(p.id);
    });

    function modeAdj(player) {
      if (tradeMode === "balanced") return player.value;
      const young = player.age > 0 && player.age <= 23;
      const vet = player.age >= 28;
      const pick = player.pos === "PICK";
      if (tradeMode === "contender") {
        if (vet) return Math.round(player.value * 1.12);
        if (pick) return Math.round(player.value * 0.85);
        if (young) return Math.round(player.value * 0.92);
      }
      if (tradeMode === "rebuilder") {
        if (young || pick) return Math.round(player.value * 1.15);
        if (vet) return Math.round(player.value * 0.85);
      }
      return player.value;
    }

    const getVal = (id) => {
      const p = fullPool.find(x => x.id === id);
      return p ? modeAdj(p) : 0;
    };

    const giveTotal = giveSide.reduce((s, id) => s + getVal(id), 0);
    const getTotal2 = getSide.reduce((s, id) => s + getVal(id), 0);
    const totalBoth = giveTotal + getTotal2;
    const pct = totalBoth > 0 ? Math.round((getTotal2 / totalBoth) * 100) : 50;
    const barWidth = totalBoth > 0 ? Math.round((giveTotal / totalBoth) * 100) : 50;

    function getVerdict2(p) {
      if (p >= 48 && p <= 52) return { label: "EVEN TRADE", color: "#22c55e", emoji: "⚖️" };
      if (p >= 44) return { label: "SLIGHT OVERPAY", color: "#f59e0b", emoji: "😐" };
      if (p > 52 && p <= 56) return { label: "SLIGHT WIN", color: "#86efac", emoji: "👍" };
      if (p >= 38) return { label: "OVERPAYING", color: "#f97316", emoji: "⚠️" };
      if (p > 56 && p <= 62) return { label: "GOOD WIN", color: "#4ade80", emoji: "✅" };
      if (p < 38) return { label: "MAJOR OVERPAY", color: "#ef4444", emoji: "🚨" };
      return { label: "STRONG WIN", color: "#16a34a", emoji: "🔥" };
    }

    const verdict = getVerdict2(pct);

    const addPlayer = (id) => {
      if (addingTo === "give") setGiveSide(p => [...p, id]);
      else setGetSide(p => [...p, id]);
    };

    const getPlayerById = (id) => fullPool.find(x => x.id === id);

    const renderSideList = (side, color) => {
      const list = side === "give" ? giveSide : getSide;
      const onRemove = side === "give"
        ? id => setGiveSide(p => p.filter(x => x !== id))
        : id => setGetSide(p => p.filter(x => x !== id));
      const total = side === "give" ? giveTotal : getTotal2;

      return (
        <div style={{ marginBottom: "12px" }}>
          <div style={{
            display: "flex", justifyContent: "space-between", alignItems: "center",
            marginBottom: "6px"
          }}>
            <div style={{ fontSize: "10px", color, letterSpacing: "0.1em", fontWeight: "700" }}>
              {side === "give" ? "📤 YOU GIVE" : "📥 YOU GET"}
            </div>
            <div style={{ fontSize: "14px", fontWeight: "700", color }}>{total.toLocaleString()}</div>
          </div>
          {list.length === 0 ? (
            <div style={{
              padding: "16px", borderRadius: "8px", textAlign: "center",
              border: `1px dashed ${color}30`, color: "#374151", fontSize: "12px"
            }}>
              {side === "give" ? "Add players to give" : "Add players to receive"}
            </div>
          ) : list.map(id => {
            const p = getPlayerById(id);
            if (!p) return null;
            return (
              <div key={id} style={{
                padding: "8px 10px", borderRadius: "7px",
                background: `${color}08`, border: `1px solid ${color}20`,
                marginBottom: "4px", display: "flex",
                justifyContent: "space-between", alignItems: "center", gap: "8px"
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: "7px", minWidth: 0 }}>
                  <PosTag pos={p.pos} small />
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: "12px", color: "#e2e8f0", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.name}</div>
                    <div style={{ fontSize: "9px", color: "#4b5563" }}>{p.owner}</div>
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: "8px", flexShrink: 0 }}>
                  <span style={{ fontSize: "12px", fontWeight: "700", color }}>{modeAdj(p).toLocaleString()}</span>
                  <button onClick={() => onRemove(id)} style={{
                    background: `${color}20`, border: `1px solid ${color}35`,
                    color, borderRadius: "4px", width: "22px", height: "22px",
                    cursor: "pointer", fontSize: "14px", fontFamily: "inherit",
                    display: "flex", alignItems: "center", justifyContent: "center"
                  }}>×</button>
                </div>
              </div>
            );
          })}
        </div>
      );
    };

    return (
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {/* Sub tabs */}
        <div style={{ display: "flex", borderBottom: "1px solid rgba(255,255,255,0.06)", flexShrink: 0 }}>
          {["search","trade","result"].map(t => (
            <button key={t} onClick={() => setTradeTab(t)} style={{
              flex: 1, padding: "10px 4px",
              background: tradeTab === t ? "rgba(255,255,255,0.04)" : "transparent",
              border: "none",
              borderBottom: tradeTab === t ? "2px solid #8b5cf6" : "2px solid transparent",
              color: tradeTab === t ? "#c4b5fd" : "#4b5563",
              fontSize: "11px", cursor: "pointer", fontFamily: "inherit",
              letterSpacing: "0.06em", textTransform: "uppercase"
            }}>{t === "search" ? "🔍 Search" : t === "trade" ? "⚖️ Build" : "📊 Result"}</button>
          ))}
        </div>

        {tradeTab === "search" && (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
            {/* Adding to toggle */}
            <div style={{ display: "flex", flexShrink: 0, borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
              {["give","get"].map(side => (
                <button key={side} onClick={() => setAddingTo(side)} style={{
                  flex: 1, padding: "8px",
                  background: addingTo === side
                    ? side === "give" ? "rgba(239,68,68,0.1)" : "rgba(34,197,94,0.1)"
                    : "transparent",
                  border: "none",
                  borderBottom: addingTo === side
                    ? `2px solid ${side === "give" ? "#ef4444" : "#22c55e"}`
                    : "2px solid transparent",
                  color: addingTo === side
                    ? side === "give" ? "#fca5a5" : "#86efac" : "#4b5563",
                  fontSize: "10px", cursor: "pointer", fontFamily: "inherit",
                  letterSpacing: "0.08em", textTransform: "uppercase"
                }}>{side === "give" ? "📤 Adding to GIVE" : "📥 Adding to GET"}</button>
              ))}
            </div>
            <div style={{ padding: "8px 12px", flexShrink: 0 }}>
              <input value={tradeSearch} onChange={e => setTradeSearch(e.target.value)}
                placeholder="Search players & picks..."
                style={{
                  width: "100%", padding: "8px 12px",
                  background: "rgba(255,255,255,0.06)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: "7px", color: "#e2e8f0",
                  fontSize: "14px", fontFamily: "inherit",
                  boxSizing: "border-box", outline: "none"
                }} />
            </div>
            <div style={{
              padding: "0 12px 8px", display: "flex", gap: "5px",
              overflowX: "auto", flexShrink: 0
            }}>
              {POSITIONS_TC.map(pos => (
                <button key={pos} onClick={() => setTradePosFilter(pos)} style={{
                  padding: "3px 9px", borderRadius: "4px", whiteSpace: "nowrap",
                  border: tradePosFilter === pos
                    ? `1px solid ${POS_COLORS[pos] || "#8b5cf6"}`
                    : "1px solid rgba(255,255,255,0.07)",
                  background: tradePosFilter === pos
                    ? `${POS_COLORS[pos] || "#8b5cf6"}18` : "transparent",
                  color: tradePosFilter === pos ? POS_COLORS[pos] || "#c4b5fd" : "#4b5563",
                  fontSize: "10px", cursor: "pointer", fontFamily: "inherit"
                }}>{pos}</button>
              ))}
            </div>
            <div style={{ flex: 1, overflowY: "auto", padding: "0 12px 12px" }}>
              {filtered.slice(0, 80).map(player => (
                <div key={player.id} onClick={() => addPlayer(player.id)} style={{
                  padding: "8px 10px", borderRadius: "7px", cursor: "pointer",
                  display: "flex", justifyContent: "space-between", alignItems: "center",
                  marginBottom: "3px", background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.04)", gap: "8px",
                  WebkitTapHighlightColor: "transparent"
                }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", minWidth: 0 }}>
                    <PosTag pos={player.pos} small />
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: "12px", color: "#e2e8f0", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{player.name}</div>
                      <div style={{ fontSize: "9px", color: "#4b5563" }}>
                        {player.team !== "PICK" ? `${player.team}${player.age ? ` · Age ${player.age}` : ""} · ` : ""}{player.owner}
                      </div>
                    </div>
                  </div>
                  <div style={{ textAlign: "right", flexShrink: 0 }}>
                    <div style={{ fontSize: "12px", fontWeight: "700", color: "#8b5cf6" }}>{modeAdj(player).toLocaleString()}</div>
                    <div style={{ fontSize: "9px", color: "#374151" }}>
                      {["Elite","Starter","Depth","Fringe"][player.tier - 1]}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tradeTab === "trade" && (
          <div style={{ flex: 1, overflowY: "auto", padding: "12px" }}>
            {/* Mode selector */}
            <div style={{ display: "flex", gap: "6px", marginBottom: "12px", alignItems: "center" }}>
              <span style={{ fontSize: "10px", color: "#4b5563" }}>MODE:</span>
              {["contender","balanced","rebuilder"].map(m => (
                <button key={m} onClick={() => setTradeMode(m)} style={{
                  padding: "4px 10px", borderRadius: "5px",
                  border: tradeMode === m ? "1px solid #8b5cf6" : "1px solid rgba(255,255,255,0.08)",
                  background: tradeMode === m ? "rgba(139,92,246,0.2)" : "transparent",
                  color: tradeMode === m ? "#c4b5fd" : "#4b5563",
                  fontSize: "10px", cursor: "pointer", fontFamily: "inherit",
                  textTransform: "uppercase", letterSpacing: "0.06em"
                }}>{m}</button>
              ))}
            </div>
            {renderSideList("give", "#ef4444")}
            {renderSideList("get", "#22c55e")}
            <button onClick={() => { setGiveSide([]); setGetSide([]); }} style={{
              width: "100%", padding: "10px",
              background: "rgba(255,255,255,0.03)",
              border: "1px solid rgba(255,255,255,0.07)",
              borderRadius: "7px", color: "#4b5563",
              fontSize: "11px", cursor: "pointer", fontFamily: "inherit"
            }}>CLEAR TRADE</button>
          </div>
        )}

        {tradeTab === "result" && (
          <div style={{ flex: 1, overflowY: "auto", padding: "12px" }}>
            {(giveSide.length === 0 && getSide.length === 0) ? (
              <div style={{ textAlign: "center", color: "#374151", padding: "40px 0" }}>
                <div style={{ fontSize: "40px", marginBottom: "10px" }}>⚖️</div>
                <div style={{ fontSize: "13px" }}>Build a trade first</div>
              </div>
            ) : (
              <>
                <div style={{
                  background: `${verdict.color}12`,
                  border: `1px solid ${verdict.color}30`,
                  borderRadius: "14px", padding: "20px",
                  textAlign: "center", marginBottom: "14px"
                }}>
                  <div style={{ fontSize: "36px", marginBottom: "6px" }}>{verdict.emoji}</div>
                  <div style={{ fontSize: "28px", fontWeight: "800", color: verdict.color }}>{pct}%</div>
                  <div style={{ fontSize: "12px", color: verdict.color, fontWeight: "700", letterSpacing: "0.1em", marginTop: "4px" }}>{verdict.label}</div>
                  <div style={{ fontSize: "10px", color: "#4b5563", marginTop: "2px" }}>value received</div>
                </div>
                <div style={{ marginBottom: "14px" }}>
                  <div style={{ height: "8px", background: "rgba(255,255,255,0.05)", borderRadius: "4px", overflow: "hidden", display: "flex" }}>
                    <div style={{ width: `${barWidth}%`, background: "linear-gradient(90deg,#ef4444,#f97316)", transition: "width 0.4s" }} />
                    <div style={{ width: `${100 - barWidth}%`, background: "linear-gradient(90deg,#16a34a,#22c55e)", transition: "width 0.4s" }} />
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", marginTop: "5px", fontSize: "11px" }}>
                    <span style={{ color: "#ef4444" }}>GIVE: {giveTotal.toLocaleString()}</span>
                    <span style={{ color: "#22c55e" }}>GET: {getTotal2.toLocaleString()}</span>
                  </div>
                </div>
                {giveTotal > 0 && getTotal2 > 0 && (
                  <div style={{
                    background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)",
                    borderRadius: "8px", padding: "10px 14px",
                    display: "flex", justifyContent: "space-between", alignItems: "center",
                    marginBottom: "14px"
                  }}>
                    <span style={{ fontSize: "11px", color: "#6b7280", letterSpacing: "0.05em" }}>DIFFERENCE</span>
                    <span style={{ fontSize: "16px", fontWeight: "700", color: getTotal2 >= giveTotal ? "#22c55e" : "#ef4444" }}>
                      {getTotal2 >= giveTotal ? "+" : ""}{(getTotal2 - giveTotal).toLocaleString()}
                    </span>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
    );
  };

  // ── BOTTOM NAV ────────────────────────────────────────────────────────────
  const NAV = [
    { id: "roster",    icon: "👥", label: "Roster" },
    { id: "standings", icon: "📊", label: "Standings" },
    { id: "trade",     icon: "⚖️", label: "Trade" },
    { id: "news",      icon: "📰", label: "News" },
    { id: "txns",      icon: "🔄", label: "Moves" },
  ];

  // ── RENDER ────────────────────────────────────────────────────────────────
  return (
    <div style={{
      minHeight: "100vh", background: "#08080f", color: "#e2e8f0",
      fontFamily: "'DM Mono', 'Courier New', monospace",
      display: "flex", flexDirection: "column",
      maxWidth: "600px", margin: "0 auto"
    }}>
      {/* Header */}
      <div style={{
        background: "linear-gradient(135deg, #0f0f1a, #150a2a)",
        borderBottom: "1px solid rgba(139,92,246,0.25)",
        padding: "12px 16px", flexShrink: 0
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div style={{
              width: "28px", height: "28px", borderRadius: "7px",
              background: "linear-gradient(135deg,#8b5cf6,#3b82f6)",
              display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px"
            }}>👑</div>
            <div>
              <div style={{ fontSize: "14px", fontWeight: "700", color: "#fff", letterSpacing: "0.05em" }}>
                BDL COMMAND CENTER
              </div>
              <div style={{ fontSize: "9px", color: "#4b5563", letterSpacing: "0.1em" }}>
                {leagueData?.name} · {leagueData?.season} · LIVE
              </div>
            </div>
          </div>
          <div style={{
            fontSize: "9px", padding: "3px 8px", borderRadius: "4px",
            background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)",
            color: "#22c55e", letterSpacing: "0.06em"
          }}>● LIVE</div>
        </div>
      </div>

      {/* Tab content */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {tab === "roster"    && <RosterTab />}
        {tab === "standings" && <StandingsTab />}
        {tab === "trade"     && <TradeCalcTab />}
        {tab === "news"      && <NewsTab />}
        {tab === "txns"      && <TransactionsTab />}
      </div>

      {/* Bottom nav */}
      <div style={{
        display: "flex", borderTop: "1px solid rgba(255,255,255,0.07)",
        background: "#0a0a14", flexShrink: 0
      }}>
        {NAV.map(item => (
          <button key={item.id} onClick={() => setTab(item.id)} style={{
            flex: 1, padding: "10px 4px 8px",
            background: tab === item.id ? "rgba(139,92,246,0.1)" : "transparent",
            border: "none",
            borderTop: tab === item.id ? "2px solid #8b5cf6" : "2px solid transparent",
            color: tab === item.id ? "#c4b5fd" : "#4b5563",
            fontSize: "10px", cursor: "pointer", fontFamily: "inherit",
            display: "flex", flexDirection: "column", alignItems: "center", gap: "2px",
            letterSpacing: "0.04em"
          }}>
            <span style={{ fontSize: "16px", lineHeight: 1 }}>{item.icon}</span>
            <span>{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(BDLCommandCenter));
